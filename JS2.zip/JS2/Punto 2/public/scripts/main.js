(function() {
    // ---------------------------
    // Elementos comunes
    // ---------------------------
    const toggleTema = document.getElementById('toggleTema');
    const themeLink = document.getElementById('theme-link');

    // ---------------------------
    // Modo oscuro / claro (siempre inicia claro)
    // ---------------------------
    function activarTema(oscuro) {
        if (!themeLink) return;
        if (oscuro) {
            themeLink.href = 'context/dark.css';
            if (toggleTema) toggleTema.checked = true;
        } else {
            themeLink.href = 'context/light.css';
            if (toggleTema) toggleTema.checked = false;
        }
    }

    // Siempre inicia en modo claro
    activarTema(false);

    if (toggleTema) {
        toggleTema.addEventListener('change', () => {
            activarTema(toggleTema.checked);
        });
    }

    // ---------------------------
    // Funciones auxiliares (fechas)
    // ---------------------------
    function formatoFecha(iso) {
        if (!iso) return '';
        const [year, month, day] = iso.split('-');
        return `${day}/${month}/${year}`;
    }

    function fechaHoyISO() {
        return new Date().toISOString().slice(0, 10);
    }

    // ==========================================
    // Página: index.html (reporte de consumibles)
    // ==========================================
    if (document.getElementById('btnGuardar')) {
        const btnGuardar = document.getElementById('btnGuardar');
        const inputsNumericos = document.querySelectorAll('.input-numerico');
        const fechaInicio = document.getElementById('fechaInicio');
        const fechaFin = document.getElementById('fechaFin');
        const selectFecha = document.getElementById('selectFecha');
        const btnVerReporte = document.getElementById('btnVerReporte');
        const btnEliminarFecha = document.getElementById('btnEliminarFecha');

        const modalReporte = new bootstrap.Modal(document.getElementById('modalReporte'));
        const modalLabel = document.getElementById('modalReporteLabel');
        const contenidoReporte = document.getElementById('contenidoReporte');

        const STORAGE_KEY = 'reportes_consumibles';

        // Validación numérica (solo números y punto decimal)
        inputsNumericos.forEach(input => {
            input.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9.]/g, '');
                const partes = this.value.split('.');
                if (partes.length > 2) {
                    this.value = partes[0] + '.' + partes.slice(1).join('');
                }
            });
            input.addEventListener('paste', function(e) {
                e.preventDefault();
                const paste = (e.clipboardData || window.clipboardData).getData('text');
                const soloNumeros = paste.replace(/[^0-9.]/g, '');
                this.value += soloNumeros;
                const partes = this.value.split('.');
                if (partes.length > 2) {
                    this.value = partes[0] + '.' + partes.slice(1).join('');
                }
            });
        });

        // localStorage
        function obtenerReportes() {
            const datos = localStorage.getItem(STORAGE_KEY);
            return datos ? JSON.parse(datos) : {};
        }
        function guardarReportes(reportes) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(reportes));
        }

        function actualizarSelector() {
            const reportes = obtenerReportes();
            const claves = Object.keys(reportes).sort().reverse();
            selectFecha.innerHTML = '<option value="">-- Selecciona un reporte --</option>';
            claves.forEach(clave => {
                const reporte = reportes[clave];
                const option = document.createElement('option');
                option.value = clave;
                option.textContent = `${formatoFecha(reporte.start)} - ${formatoFecha(reporte.end)}`;
                selectFecha.appendChild(option);
            });
            btnVerReporte.disabled = true;
            btnEliminarFecha.disabled = true;
        }

        // Guardar reporte
        btnGuardar.addEventListener('click', async () => {
            let start = fechaInicio.value;
            let end = fechaFin.value;
            const hoy = fechaHoyISO();
            if (!start) start = hoy;
            if (!end) end = start;
            if (end < start) {
                alert('La fecha "Hasta" no puede ser anterior a "Desde".');
                return;
            }

            const insumos = {};
            inputsNumericos.forEach(input => {
                const label = document.querySelector(`label[for="${input.id}"]`);
                const nombre = label ? label.textContent : input.id;
                insumos[input.id] = {
                    nombre: nombre,
                    valor: input.value.trim() || '0'
                };
            });

            const reporte = { start, end, insumos };
            const reportes = obtenerReportes();
            const clave = `${start}_${end}`;
            reportes[clave] = reporte;
            guardarReportes(reportes);
            actualizarSelector();

            // Generar texto
            let texto = `REPORTE DE CONSUMIBLES\n`;
            texto += `Desde: ${formatoFecha(start)}  Hasta: ${formatoFecha(end)}\n`;
            texto += `----------------------------------------\n`;
            for (let id in insumos) {
                texto += `${insumos[id].nombre}: ${insumos[id].valor}\n`;
            }

            // Descarga local
            const blob = new Blob([texto], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const nombreArchivo = `reporte_${start}_${end}.txt`;
            a.download = nombreArchivo;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            // Guardar en servidor
            try {
                const respuesta = await fetch('/guardar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ nombreArchivo, contenido: texto })
                });
                const data = await respuesta.json();
                if (respuesta.ok) {
                    console.log('✅', data.mensaje);
                } else {
                    console.error('❌ Error del servidor:', data.error);
                    alert('Descarga local OK, pero no se guardó en el servidor.');
                }
            } catch (error) {
                console.error('❌ No se pudo contactar al servidor:', error);
                alert('Descarga local OK, pero el servidor no está disponible.');
            }
        });

        // Ver reporte en modal
        btnVerReporte.addEventListener('click', () => {
            const clave = selectFecha.value;
            if (!clave) return;
            const reportes = obtenerReportes();
            const reporte = reportes[clave];
            if (!reporte) return;
            modalLabel.textContent = `Reporte: ${formatoFecha(reporte.start)} – ${formatoFecha(reporte.end)}`;
            let html = '<ul class="list-group">';
            for (let id in reporte.insumos) {
                const item = reporte.insumos[id];
                html += `<li class="list-group-item d-flex justify-content-between"><span>${item.nombre}</span><strong>${item.valor}</strong></li>`;
            }
            html += '</ul>';
            contenidoReporte.innerHTML = html;
            modalReporte.show();
        });

        // Eliminar reporte
        btnEliminarFecha.addEventListener('click', () => {
            const clave = selectFecha.value;
            if (!clave) return;
            const reportes = obtenerReportes();
            const reporte = reportes[clave];
            if (confirm(`¿Eliminar el reporte ${formatoFecha(reporte.start)} – ${formatoFecha(reporte.end)}?`)) {
                delete reportes[clave];
                guardarReportes(reportes);
                actualizarSelector();
            }
        });

        selectFecha.addEventListener('change', () => {
            const sel = selectFecha.value !== '';
            btnVerReporte.disabled = !sel;
            btnEliminarFecha.disabled = !sel;
        });

        // Inicializar selector al cargar
        actualizarSelector();
        fechaInicio.value = '';
        fechaFin.value = '';

        // Modo oscuro preserva valores de inputs
        const originalActivarTema = activarTema;
        activarTema = function(oscuro) {
            const valores = Array.from(inputsNumericos).map(input => input.value);
            originalActivarTema(oscuro);
            setTimeout(() => {
                inputsNumericos.forEach((input, i) => { input.value = valores[i]; });
            }, 0);
        };
    }

    // ==========================================
    // Página: filtro.html (filtro de números)
    // ==========================================
    if (document.getElementById('archivoTxt')) {
        const archivoInput = document.getElementById('archivoTxt');
        const panelResultados = document.getElementById('panelResultados');
        const contadorUtiles = document.getElementById('contadorUtiles');
        const contadorNoUtiles = document.getElementById('contadorNoUtiles');
        const porcentajeElem = document.getElementById('porcentaje');
        const totalNumerosElem = document.getElementById('totalNumeros');
        const listaUtiles = document.getElementById('listaUtiles');
        const btnDescargar = document.getElementById('btnDescargar');
        let numerosUtiles = [];

        function esArchivoTxt(archivo) {
            if (!archivo.name.toLowerCase().endsWith('.txt')) return false;
            if (archivo.type && archivo.type !== 'text/plain') return false;
            return true;
        }

        function mismoInicioFin(numero) {
            const str = numero.toString();
            const sinSigno = str.replace('-', '');
            if (sinSigno.length === 0) return false;
            return sinSigno.charAt(0) === sinSigno.charAt(sinSigno.length - 1);
        }

        archivoInput.addEventListener('change', function(e) {
            const archivo = e.target.files[0];
            if (!archivo) return;
            if (!esArchivoTxt(archivo)) {
                alert('El archivo seleccionado no es un .txt válido. Elija un archivo de texto.');
                archivoInput.value = '';
                return;
            }
            const lector = new FileReader();
            lector.onload = function(evento) {
                const lineas = evento.target.result.split(/\r?\n/);
                const todosNumeros = [];
                lineas.forEach(linea => {
                    const partes = linea.split(':');
                    if (partes.length >= 2) {
                        const valorStr = partes[1].trim();
                        const num = parseFloat(valorStr);
                        if (!isNaN(num)) todosNumeros.push(num);
                    }
                });
                const utiles = todosNumeros.filter(n => mismoInicioFin(n));
                const noUtiles = todosNumeros.length - utiles.length;
                const porcentaje = todosNumeros.length > 0 ? ((utiles.length / todosNumeros.length)*100).toFixed(2) : 0;
                utiles.sort((a,b) => a-b);
                numerosUtiles = utiles;

                contadorUtiles.textContent = utiles.length;
                contadorNoUtiles.textContent = noUtiles;
                porcentajeElem.textContent = porcentaje + '%';
                totalNumerosElem.textContent = todosNumeros.length;

                listaUtiles.innerHTML = '';
                utiles.forEach(num => {
                    const li = document.createElement('li');
                    li.className = 'list-group-item';
                    li.textContent = num;
                    listaUtiles.appendChild(li);
                });
                panelResultados.style.display = 'block';
            };
            lector.readAsText(archivo);
        });

        btnDescargar.addEventListener('click', async () => {
            if (numerosUtiles.length === 0) {
                alert('No hay números útiles para descargar.');
                return;
            }
            const contenido = numerosUtiles.join('\n');
            const nombreArchivo = 'numeros_utiles.txt';

            const blob = new Blob([contenido], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = nombreArchivo;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            try {
                const respuesta = await fetch('/guardar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ nombreArchivo, contenido })
                });
                const data = await respuesta.json();
                if (respuesta.ok) {
                    console.log('✅', data.mensaje);
                } else {
                    console.error('❌ Error del servidor:', data.error);
                    alert('Descarga local OK, pero no se guardó en el servidor.');
                }
            } catch (error) {
                console.error('❌ No se pudo contactar al servidor:', error);
                alert('Descarga local OK, pero el servidor no está disponible.');
            }
        });
    }
})();