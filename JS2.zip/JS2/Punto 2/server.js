const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Función para obtener un nombre de archivo único en respaldo/
function obtenerNombreUnico(rutaBase, extension) {
    let contador = 0;
    let nuevoNombre = rutaBase + extension;
    while (fs.existsSync(nuevoNombre)) {
        contador++;
        nuevoNombre = `${rutaBase}_${contador}${extension}`;
    }
    return nuevoNombre;
}

app.post("/guardar", (req, res) => {
    const { nombreArchivo, contenido } = req.body;

    if (!nombreArchivo || !contenido) {
        return res.status(400).json({ error: "Faltan datos" });
    }

    // Crear carpeta respaldo si no existe
    const dirRespaldo = path.join(__dirname, "respaldo");
    if (!fs.existsSync(dirRespaldo)) {
        fs.mkdirSync(dirRespaldo);
    }

    // Separar nombre y extensión
    const ext = path.extname(nombreArchivo);          // .txt
    const nombreSinExt = path.basename(nombreArchivo, ext); // base sin .txt
    const rutaBase = path.join(dirRespaldo, nombreSinExt);

    // Obtener ruta definitiva sin sobreescribir
    const rutaFinal = obtenerNombreUnico(rutaBase, ext);

    fs.writeFile(rutaFinal, contenido, "utf8", (err) => {
        if (err) {
            console.error("Error al guardar:", err);
            return res.status(500).json({ error: "Error al guardar el archivo" });
        }
        const nombreFinal = path.basename(rutaFinal);
        res.json({ mensaje: `Archivo guardado en respaldo/${nombreFinal}` });
    });
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});