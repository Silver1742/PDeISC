const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// Carpeta donde se guardarán los reportes
const respaldoDir = path.join(__dirname, "respaldo");
if (!fs.existsSync(respaldoDir)) {
  fs.mkdirSync(respaldoDir, { recursive: true });
}

/**
 * Obtiene un nombre de archivo único dentro de la carpeta respaldo.
 * Si "nombre.txt" ya existe, prueba con "nombre (1).txt", "nombre (2).txt", etc.
 */
function obtenerNombreUnico(nombreBase) {
  const ext = path.extname(nombreBase);
  const baseSinExt = path.basename(nombreBase, ext);
  let nombreFinal = nombreBase;
  let contador = 1;

  while (fs.existsSync(path.join(respaldoDir, nombreFinal))) {
    nombreFinal = `${baseSinExt} (${contador})${ext}`;
    contador++;
  }

  return nombreFinal;
}

// Endpoint para guardar reportes
app.post("/guardar-reporte", (req, res) => {
  const { filename, content } = req.body;

  if (!filename || !content) {
    return res.status(400).json({ error: "Faltan datos (filename o content)" });
  }

  // Sanitizar nombre base y obtener nombre único
  const nombreSeguro = path.basename(filename);
  const nombreUnico = obtenerNombreUnico(nombreSeguro);
  const filePath = path.join(respaldoDir, nombreUnico);

  fs.writeFile(filePath, content, "utf8", (err) => {
    if (err) {
      console.error("Error al guardar el archivo:", err);
      return res.status(500).json({ error: "No se pudo guardar el reporte" });
    }
    console.log(`Reporte guardado como: ${nombreUnico}`);
    res.json({ success: true, path: filePath, filename: nombreUnico });
  });
});

// Iniciar servidor
app.listen(3000, function () {
  console.log("Servidor corriendo correctamente, ingrese a http://localhost:3000");
});