// ---------------------------
// Elementos DOM
// ---------------------------
const toggleTema = document.getElementById("toggleTema");
const themeLink = document.getElementById("theme-link");
const btnGuardar = document.getElementById("btnGuardar");
const inputsNumericos = document.querySelectorAll(".input-numerico");

const fechaInicio = document.getElementById("fechaInicio");
const fechaFin = document.getElementById("fechaFin");

const selectFecha = document.getElementById("selectFecha");
const btnVerReporte = document.getElementById("btnVerReporte");
const btnEliminarFecha = document.getElementById("btnEliminarFecha");

const modalReporte = new bootstrap.Modal(document.getElementById("modalReporte"));
const modalLabel = document.getElementById("modalReporteLabel");
const contenidoReporte = document.getElementById("contenidoReporte");

const STORAGE_KEY = "reportes_consumibles";

// ---------------------------
// Validación numérica (solo números y punto decimal)
// ---------------------------
inputsNumericos.forEach((input) => {
  input.addEventListener("input", function () {
    this.value = this.value.replace(/[^0-9.]/g, "");
    const partes = this.value.split(".");
    if (partes.length > 2) {
      this.value = partes[0] + "." + partes.slice(1).join("");
    }
  });

  input.addEventListener("paste", function (e) {
    e.preventDefault();
    const paste = (e.clipboardData || window.clipboardData).getData("text");
    const soloNumeros = paste.replace(/[^0-9.]/g, "");
    this.value += soloNumeros;
    const partes = this.value.split(".");
    if (partes.length > 2) {
      this.value = partes[0] + "." + partes.slice(1).join("");
    }
  });
});

// ---------------------------
// Formateo de fechas
// ---------------------------
function formatoFecha(iso) {
  if (!iso) return "";
  const [year, month, day] = iso.split("-");
  return `${day}/${month}/${year}`;
}

function fechaHoyISO() {
  return new Date().toISOString().slice(0, 10);
}

// ---------------------------
// localStorage
// ---------------------------
function obtenerReportes() {
  const datos = localStorage.getItem(STORAGE_KEY);
  return datos ? JSON.parse(datos) : {};
}

function guardarReportes(reportes) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reportes));
}

// ---------------------------
// Actualizar el selector de reportes guardados
// ---------------------------
function actualizarSelector() {
  const reportes = obtenerReportes();
  const claves = Object.keys(reportes).sort().reverse();

  selectFecha.innerHTML = '<option value="">-- Selecciona un reporte --</option>';
  claves.forEach((clave) => {
    const reporte = reportes[clave];
    const option = document.createElement("option");
    option.value = clave;
    option.textContent = `${formatoFecha(reporte.start)} - ${formatoFecha(reporte.end)}`;
    selectFecha.appendChild(option);
  });

  btnVerReporte.disabled = true;
  btnEliminarFecha.disabled = true;
}

// ---------------------------
// Enviar reporte al servidor (nueva función)
// ---------------------------
async function guardarEnServidor(filename, content) {
  try {
    const response = await fetch("/guardar-reporte", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, content }),
    });

    const result = await response.json();
    if (!response.ok) {
      console.error("Error del servidor:", result.error);
      alert("No se pudo guardar el reporte en el servidor.");
    } else {
      console.log("Reporte guardado en el servidor:", result.path);
    }
  } catch (error) {
    console.error("Error de conexión:", error);
    alert("Error al conectar con el servidor. ¿Está funcionando?");
  }
}

// ---------------------------
// Guardar reporte (descarga local + envío al servidor)
// ---------------------------
btnGuardar.addEventListener("click", () => {
  let start = fechaInicio.value;
  let end = fechaFin.value;
  const hoy = fechaHoyISO();

  if (!start) start = hoy;
  if (!end) end = start;

  if (end < start) {
    alert('La fecha "Hasta" no puede ser anterior a "Desde".');
    return;
  }

  const insumos = {};
  inputsNumericos.forEach((input) => {
    const label = document.querySelector(`label[for="${input.id}"]`);
    const nombre = label ? label.textContent : input.id;
    insumos[input.id] = {
      nombre: nombre,
      valor: input.value.trim() || "0",
    };
  });

  const reporte = { start, end, insumos };
  const reportes = obtenerReportes();
  const clave = `${start}_${end}`;
  reportes[clave] = reporte;
  guardarReportes(reportes);
  actualizarSelector();

  // Contenido del archivo .txt
  let texto = `REPORTE DE CONSUMIBLES\n`;
  texto += `Desde: ${formatoFecha(start)}  Hasta: ${formatoFecha(end)}\n`;
  texto += `----------------------------------------\n`;
  for (let id in insumos) {
    texto += `${insumos[id].nombre}: ${insumos[id].valor}\n`;
  }

  const nombreArchivo = `reporte_${start}_${end}.txt`;

  // Descargar en el navegador
  const blob = new Blob([texto], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nombreArchivo;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  // Guardar en el servidor
  guardarEnServidor(nombreArchivo, texto);
});

// ---------------------------
// Ver reporte en modal
// ---------------------------
btnVerReporte.addEventListener("click", () => {
  const clave = selectFecha.value;
  if (!clave) return;

  const reportes = obtenerReportes();
  const reporte = reportes[clave];
  if (!reporte) return;

  modalLabel.textContent = `Reporte: ${formatoFecha(reporte.start)} – ${formatoFecha(reporte.end)}`;

  let html = '<ul class="list-group">';
  for (let id in reporte.insumos) {
    const item = reporte.insumos[id];
    html += `
      <li class="list-group-item d-flex justify-content-between">
        <span>${item.nombre}</span>
        <strong>${item.valor}</strong>
      </li>
    `;
  }
  html += "</ul>";
  contenidoReporte.innerHTML = html;

  modalReporte.show();
});

// ---------------------------
// Eliminar reporte
// ---------------------------
btnEliminarFecha.addEventListener("click", () => {
  const clave = selectFecha.value;
  if (!clave) return;

  const reportes = obtenerReportes();
  const reporte = reportes[clave];
  if (confirm(`¿Eliminar el reporte ${formatoFecha(reporte.start)} – ${formatoFecha(reporte.end)}?`)) {
    delete reportes[clave];
    guardarReportes(reportes);
    actualizarSelector();
  }
});

// Habilitar/deshabilitar botones según selección
selectFecha.addEventListener("change", () => {
  const seleccionada = selectFecha.value !== "";
  btnVerReporte.disabled = !seleccionada;
  btnEliminarFecha.disabled = !seleccionada;
});

// ---------------------------
// Modo oscuro / claro (siempre inicia claro)
// ---------------------------
function activarTema(oscuro) {
  const valores = Array.from(inputsNumericos).map((input) => input.value);
  if (oscuro) {
    themeLink.href = "context/dark.css";
    toggleTema.checked = true;
  } else {
    themeLink.href = "context/light.css";
    toggleTema.checked = false;
  }
  setTimeout(() => {
    inputsNumericos.forEach((input, i) => {
      input.value = valores[i];
    });
  }, 0);
}

document.addEventListener("DOMContentLoaded", () => {
  fechaInicio.value = "";
  fechaFin.value = "";
  activarTema(false);
  actualizarSelector();
});

toggleTema.addEventListener("change", () => {
  activarTema(toggleTema.checked);
});