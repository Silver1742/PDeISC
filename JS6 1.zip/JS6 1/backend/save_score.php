<?php
require_once 'config.php';

// Solo aceptar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
    exit;
}

// Obtener datos del cuerpo de la petición
$input = json_decode(file_get_contents('php://input'), true);

$nombre = isset($input['nombre']) ? trim($input['nombre']) : '';
$puntos = isset($input['puntos']) ? intval($input['puntos']) : 0;
$tiempo = isset($input['tiempo']) ? intval($input['tiempo']) : 0;

// Validar datos
if (empty($nombre)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'El nombre es requerido'
    ]);
    exit;
}

if (strlen($nombre) > 50) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'El nombre no puede exceder 50 caracteres'
    ]);
    exit;
}

if ($puntos < 0) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Los puntos no pueden ser negativos'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO score (nombre, puntos, tiempo) VALUES (:nombre, :puntos, :tiempo)");
    $stmt->execute([
        ':nombre' => $nombre,
        ':puntos' => $puntos,
        ':tiempo' => $tiempo
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Score guardado exitosamente',
        'id' => $pdo->lastInsertId()
    ]);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error al guardar: ' . $e->getMessage()
    ]);
}
?>