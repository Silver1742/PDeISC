<?php
require_once 'config.php';

// Solo aceptar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
    exit;
}

// Obtener datos del cuerpo de la petición
$input = json_decode(file_get_contents('php://input'), true);

// Parámetros de ordenamiento y búsqueda
$orderBy = isset($input['orderBy']) ? $input['orderBy'] : 'puntos';
$orderDir = isset($input['orderDir']) ? $input['orderDir'] : 'DESC';
$search = isset($input['search']) ? $input['search'] : '';

// Validar campos permitidos para ordenamiento
$allowedSortFields = ['id', 'nombre', 'puntos', 'tiempo', 'fecha'];
$allowedDirections = ['ASC', 'DESC'];

if (!in_array($orderBy, $allowedSortFields)) {
    $orderBy = 'puntos';
}

if (!in_array($orderDir, $allowedDirections)) {
    $orderDir = 'DESC';
}

try {
    // Construir la consulta SQL
    $sql = "SELECT id, nombre, puntos, tiempo, fecha FROM score";
    $params = [];
    
    // Agregar búsqueda si existe
    if (!empty($search)) {
        $sql .= " WHERE nombre LIKE :search1 OR CAST(puntos AS CHAR) LIKE :search2 OR CAST(tiempo AS CHAR) LIKE :search3";
        $params[':search1'] = "%$search%";
        $params[':search2'] = "%$search%";
        $params[':search3'] = "%$search%";
    }
    
    // Agregar ordenamiento
    $sql .= " ORDER BY $orderBy $orderDir";
    
    // Limitar a 100 resultados máximo
    $sql .= " LIMIT 100";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $scores = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'scores' => $scores,
        'total' => count($scores),
        'orderBy' => $orderBy,
        'orderDir' => $orderDir,
        'search' => $search
    ]);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error al obtener scores: ' . $e->getMessage()
    ]);
}
?>