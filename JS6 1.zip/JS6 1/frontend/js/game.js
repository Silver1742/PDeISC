// Clase principal del juego
class AhorcadoGame {
    constructor() {
        this.words = [];
        this.currentWord = '';
        this.guessedLetters = new Set();
        this.wrongLetters = new Set();
        this.maxLives = 6;
        this.lives = this.maxLives;
        this.points = 0;
        this.timer = 0;
        this.timerInterval = null;
        this.playerName = '';
        this.gameActive = false;
        this.keyboardEnabled = true;
        
        // Propiedades para manejo de scores
        this.currentScores = [];
        this.currentOrderBy = 'puntos';
        this.currentOrderDir = 'DESC';
        this.currentSearch = '';
        this.currentPage = 1;
        this.itemsPerPage = 10;
        this.searchTimeout = null;
        
        this.initializeElements();
        this.fetchWords();
        this.setupEventListeners();
        this.setupKeyboardListener();
    }
    
    initializeElements() {
        // Pantallas
        this.startScreen = document.getElementById('startScreen');
        this.gameScreen = document.getElementById('gameScreen');
        this.endScreen = document.getElementById('endScreen');
        this.scoresScreen = document.getElementById('scoresScreen');
        
        // Elementos de inicio
        this.playerNameInput = document.getElementById('playerName');
        this.startBtn = document.getElementById('startBtn');
        
        // Elementos del juego
        this.wordDisplay = document.getElementById('wordDisplay');
        this.keyboard = document.getElementById('keyboard');
        this.timerDisplay = document.getElementById('timer');
        this.pointsDisplay = document.getElementById('points');
        this.livesDisplay = document.getElementById('lives');
        this.displayName = document.getElementById('displayName');
        this.canvas = document.getElementById('hangmanCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.keyPressed = document.getElementById('keyPressed');
        this.keyPressedChar = document.getElementById('keyPressedChar');
        
        // Elementos de fin
        this.endIcon = document.getElementById('endIcon');
        this.endTitle = document.getElementById('endTitle');
        this.finalWord = document.getElementById('finalWord');
        this.finalPoints = document.getElementById('finalPoints');
        this.finalTime = document.getElementById('finalTime');
        
        // Botones
        this.saveScoreBtn = document.getElementById('saveScoreBtn');
        this.showScoresBtn = document.getElementById('showScoresBtn');
        this.playAgainBtn = document.getElementById('playAgainBtn');
        this.downloadPdfBtn = document.getElementById('downloadPdfBtn');
        this.backToGameBtn = document.getElementById('backToGameBtn');
    }
    
    async fetchWords() {
        try {
            // Intentar obtener palabras de una API
            const response = await fetch('https://api.datamuse.com/words?sp=?????&max=100&v=es');
            const data = await response.json();
            this.words = data.map(item => item.word).filter(word => 
                word.length >= 4 && word.length <= 8 && /^[a-záéíóúñ]+$/.test(word)
            );
            
            if (this.words.length < 10) {
                throw new Error('No hay suficientes palabras');
            }
        } catch (error) {
            console.log('Usando palabras de respaldo');
            // Palabras de respaldo en español
            this.words = [
                'javascript', 'programacion', 'desarrollo', 'computadora', 'tecnologia',
                'algoritmo', 'variable', 'funcion', 'objeto', 'aplicacion', 'internet',
                'base', 'datos', 'servidor', 'cliente', 'python', 'java', 'codigo',
                'sistema', 'software', 'hardware', 'memoria', 'procesador', 'teclado',
                'monitor', 'archivo', 'carpeta', 'ventana', 'usuario', 'conexion',
                'ahorcado', 'palabra', 'letras', 'juego', 'adivinar', 'puntos',
                'html', 'css', 'diseño', 'web', 'frontend', 'backend',
                'framework', 'biblioteca', 'componente', 'modulo', 'paquete'
            ];
        }
    }
    
    setupEventListeners() {
        // Listener para habilitar botón de inicio
        this.playerNameInput.addEventListener('input', () => {
            this.startBtn.disabled = !this.playerNameInput.value.trim();
        });
        
        // Iniciar juego con Enter
        this.playerNameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !this.startBtn.disabled) {
                this.startGame();
            }
        });
        
        // Botones principales que siempre existen en el DOM
        this.startBtn.addEventListener('click', () => this.startGame());
        this.playAgainBtn.addEventListener('click', () => this.resetGame());
        this.showScoresBtn.addEventListener('click', () => this.showScores());
        this.backToGameBtn.addEventListener('click', () => this.backToGame());
        this.saveScoreBtn.addEventListener('click', () => this.saveScore());
        this.downloadPdfBtn.addEventListener('click', () => this.downloadPDF());
        
        // Usar event delegation para todos los elementos dinámicos
        this.setupDynamicEventListeners();
    }
    
    setupDynamicEventListeners() {
        // Remover listeners anteriores si existen
        if (this.dynamicClickHandler) {
            document.removeEventListener('click', this.dynamicClickHandler);
        }
        if (this.dynamicChangeHandler) {
            document.removeEventListener('change', this.dynamicChangeHandler);
        }
        if (this.dynamicInputHandler) {
            document.removeEventListener('input', this.dynamicInputHandler);
        }
        
        // Crear handlers y guardarlos para poder removerlos después
        this.dynamicClickHandler = (e) => {
            // Headers de tabla ordenables
            const sortableHeader = e.target.closest('.sortable');
            if (sortableHeader) {
                const sortField = sortableHeader.getAttribute('data-sort');
                console.log('Header clicked:', sortField);
                
                if (sortField === this.currentOrderBy) {
                    this.currentOrderDir = this.currentOrderDir === 'ASC' ? 'DESC' : 'ASC';
                } else {
                    this.currentOrderBy = sortField;
                    this.currentOrderDir = 'DESC';
                }
                
                console.log('New order:', this.currentOrderBy, this.currentOrderDir);
                this.updateSortSelects();
                this.currentPage = 1;
                this.loadScores();
                return;
            }
            
            // Botón limpiar búsqueda
            if (e.target.closest('#clearSearchBtn')) {
                console.log('Clear search clicked');
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.value = '';
                    this.currentSearch = '';
                    this.currentPage = 1;
                    this.loadScores();
                }
                return;
            }
            
            // Botón actualizar
            if (e.target.closest('#refreshScoresBtn')) {
                console.log('Refresh clicked');
                this.loadScores();
                return;
            }
        };
        
        this.dynamicChangeHandler = (e) => {
            // Select de campo de ordenamiento
            if (e.target.id === 'orderBySelect') {
                console.log('Order by changed:', e.target.value);
                this.currentOrderBy = e.target.value;
                this.currentPage = 1;
                this.loadScores();
                return;
            }
            
            // Select de dirección de ordenamiento
            if (e.target.id === 'orderDirSelect') {
                console.log('Order direction changed:', e.target.value);
                this.currentOrderDir = e.target.value;
                this.currentPage = 1;
                this.loadScores();
                return;
            }
        };
        
        this.dynamicInputHandler = (e) => {
            // Input de búsqueda
            if (e.target.id === 'searchInput') {
                clearTimeout(this.searchTimeout);
                this.searchTimeout = setTimeout(() => {
                    console.log('Search:', e.target.value);
                    this.currentSearch = e.target.value.trim();
                    this.currentPage = 1;
                    this.loadScores();
                }, 500);
                return;
            }
        };
        
        // Agregar los listeners
        document.addEventListener('click', this.dynamicClickHandler);
        document.addEventListener('change', this.dynamicChangeHandler);
        document.addEventListener('input', this.dynamicInputHandler);
    }
    
    updateSortSelects() {
        const orderBySelect = document.getElementById('orderBySelect');
        const orderDirSelect = document.getElementById('orderDirSelect');
        
        if (orderBySelect) {
            orderBySelect.value = this.currentOrderBy;
        }
        
        if (orderDirSelect) {
            orderDirSelect.value = this.currentOrderDir;
        }
        
        // Actualizar clases visuales en los headers
        document.querySelectorAll('.sortable').forEach(header => {
            const sortField = header.getAttribute('data-sort');
            header.classList.remove('active');
            if (sortField === this.currentOrderBy) {
                header.classList.add('active');
            }
        });
    }
    
    setupKeyboardListener() {
        // Listener global para teclado físico
        document.addEventListener('keydown', (e) => {
            // Solo procesar si el juego está activo
            if (!this.gameActive) return;
            
            // Prevenir que se active cuando se escribe en inputs
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || 
                e.target.tagName === 'SELECT') return;
            
            const key = e.key.toLowerCase();
            
            // Verificar si es una letra válida (incluyendo ñ y vocales acentuadas)
            const validKeys = /^[a-zñáéíóú]$/;
            if (validKeys.test(key)) {
                e.preventDefault();
                this.handlePhysicalKeyPress(key);
            }
        });
    }
    
    handlePhysicalKeyPress(letter) {
        // Normalizar letras acentuadas
        const normalizedLetter = this.normalizeLetter(letter);
        
        // Verificar si la letra ya fue adivinada
        if (this.guessedLetters.has(normalizedLetter) || 
            this.wrongLetters.has(normalizedLetter)) {
            this.showKeyFeedback(normalizedLetter, false);
            return;
        }
        
        // Verificar si el teclado está habilitado (anti-spam)
        if (!this.keyboardEnabled) return;
        
        // Deshabilitar temporalmente para evitar entrada rápida
        this.keyboardEnabled = false;
        setTimeout(() => {
            this.keyboardEnabled = true;
        }, 200);
        
        // Procesar la letra
        this.processGuess(normalizedLetter);
        
        // Mostrar feedback visual
        this.showKeyFeedback(normalizedLetter, true);
        
        // Resaltar la tecla en el teclado virtual
        this.highlightVirtualKey(normalizedLetter);
    }
    
    normalizeLetter(letter) {
        // Mapa de letras acentuadas a sus versiones sin acento
        const accentMap = {
            'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u'
        };
        
        return accentMap[letter] || letter;
    }
    
    showKeyFeedback(letter, isValid) {
        // Mostrar indicador de tecla presionada
        if (this.keyPressed) {
            this.keyPressed.classList.remove('d-none');
            this.keyPressed.classList.add('show');
            this.keyPressedChar.textContent = letter.toUpperCase();
            
            if (isValid) {
                this.keyPressed.classList.remove('alert-warning');
                this.keyPressed.classList.add('alert-info');
            } else {
                this.keyPressed.classList.remove('alert-info');
                this.keyPressed.classList.add('alert-warning');
            }
            
            // Ocultar después de 1 segundo
            setTimeout(() => {
                this.keyPressed.classList.add('d-none');
                this.keyPressed.classList.remove('show');
            }, 1000);
        }
    }
    
    highlightVirtualKey(letter) {
        const keys = this.keyboard.children;
        for (let key of keys) {
            if (key.textContent.toLowerCase() === letter) {
                // Agregar clase de presionado
                key.classList.add('pressed');
                setTimeout(() => {
                    key.classList.remove('pressed');
                }, 300);
                break;
            }
        }
    }
    
    startGame() {
        this.playerName = this.playerNameInput.value.trim();
        if (!this.playerName) return;
        
        if (this.words.length === 0) {
            this.showToast('Cargando palabras... Por favor espera un momento.', 'warning');
            return;
        }
        
        // Seleccionar palabra aleatoria
        this.currentWord = this.words[Math.floor(Math.random() * this.words.length)].toLowerCase();
        // Normalizar la palabra (quitar acentos si los tiene)
        this.currentWord = this.normalizeWord(this.currentWord);
        
        this.guessedLetters.clear();
        this.wrongLetters.clear();
        this.lives = this.maxLives;
        this.points = 0;
        this.timer = 0;
        this.gameActive = true;
        this.keyboardEnabled = true;
        
        // Actualizar UI
        this.displayName.textContent = this.playerName;
        this.updateDisplay();
        this.createKeyboard();
        this.drawHangman();
        
        // Cambiar pantalla
        this.showScreen('game');
        
        // Ocultar indicador de tecla
        if (this.keyPressed) {
            this.keyPressed.classList.add('d-none');
        }
        
        // Iniciar timer
        clearInterval(this.timerInterval);
        this.timerInterval = setInterval(() => {
            this.timer++;
            this.timerDisplay.textContent = this.timer;
        }, 1000);
        
        // Dar foco al juego para capturar teclas
        this.focusGame();
    }
    
    normalizeWord(word) {
        // Quitar acentos de la palabra para facilitar el juego
        return word.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }
    
    focusGame() {
        // Crear un elemento invisible para capturar eventos de teclado
        const focusElement = document.createElement('div');
        focusElement.setAttribute('tabindex', '0');
        focusElement.style.position = 'absolute';
        focusElement.style.opacity = '0';
        focusElement.style.height = '0';
        document.body.appendChild(focusElement);
        focusElement.focus();
        
        // Remover después de dar foco
        setTimeout(() => {
            if (document.body.contains(focusElement)) {
                document.body.removeChild(focusElement);
            }
        }, 100);
    }
    
    showScreen(screen) {
        // Ocultar todas las pantallas
        if (this.startScreen) this.startScreen.classList.add('hidden');
        if (this.gameScreen) this.gameScreen.classList.add('hidden');
        if (this.endScreen) this.endScreen.classList.add('hidden');
        if (this.scoresScreen) this.scoresScreen.classList.add('hidden');
        
        // Mostrar la pantalla solicitada
        switch(screen) {
            case 'start':
                if (this.startScreen) this.startScreen.classList.remove('hidden');
                break;
            case 'game':
                if (this.gameScreen) this.gameScreen.classList.remove('hidden');
                break;
            case 'end':
                if (this.endScreen) this.endScreen.classList.remove('hidden');
                break;
            case 'scores':
                if (this.scoresScreen) this.scoresScreen.classList.remove('hidden');
                break;
        }
    }
    
    createKeyboard() {
        this.keyboard.innerHTML = '';
        const letters = 'abcdefghijklmnñopqrstuvwxyz';
        
        for (let letter of letters) {
            const key = document.createElement('button');
            key.className = 'key btn btn-outline-primary';
            key.textContent = letter.toUpperCase();
            key.addEventListener('click', () => {
                if (!this.gameActive || !this.keyboardEnabled) return;
                this.keyboardEnabled = false;
                setTimeout(() => {
                    this.keyboardEnabled = true;
                }, 200);
                this.processGuess(letter);
            });
            this.keyboard.appendChild(key);
        }
    }
    
    processGuess(letter) {
        if (!this.gameActive || 
            this.guessedLetters.has(letter) || 
            this.wrongLetters.has(letter)) {
            return;
        }
        
        if (this.currentWord.includes(letter)) {
            // Letra correcta
            this.guessedLetters.add(letter);
            this.points += 10;
            
            // Marcar tecla como correcta
            const keys = this.keyboard.children;
            for (let key of keys) {
                if (key.textContent.toLowerCase() === letter) {
                    key.classList.remove('btn-outline-primary');
                    key.classList.add('btn-success', 'correct');
                    key.disabled = true;
                }
            }
            
            // Verificar si ganó
            if (this.checkWin()) {
                this.endGame(true);
            }
        } else {
            // Letra incorrecta
            this.wrongLetters.add(letter);
            this.lives--;
            
            // Marcar tecla como incorrecta
            const keys = this.keyboard.children;
            for (let key of keys) {
                if (key.textContent.toLowerCase() === letter) {
                    key.classList.remove('btn-outline-primary');
                    key.classList.add('btn-danger', 'wrong');
                    key.disabled = true;
                }
            }
            
            this.drawHangman();
            
            // Verificar si perdió
            if (this.lives <= 0) {
                this.endGame(false);
            }
        }
        
        this.updateDisplay();
    }
    
    updateDisplay() {
        // Actualizar palabra con animación
        this.wordDisplay.innerHTML = '';
        for (let letter of this.currentWord) {
            const letterBox = document.createElement('div');
            letterBox.className = 'letter-box';
            
            if (this.guessedLetters.has(letter)) {
                letterBox.textContent = letter.toUpperCase();
                letterBox.classList.add('revealed');
            } else {
                letterBox.textContent = '';
            }
            
            this.wordDisplay.appendChild(letterBox);
        }
        
        // Actualizar stats
        this.pointsDisplay.textContent = this.points;
        this.livesDisplay.textContent = this.lives;
    }
    
    drawHangman() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.ctx.strokeStyle = '#0d6efd';
        this.ctx.lineWidth = 3;
        this.ctx.lineCap = 'round';
        
        // Base
        this.ctx.beginPath();
        this.ctx.moveTo(20, 230);
        this.ctx.lineTo(180, 230);
        this.ctx.stroke();
        
        if (this.lives <= 5) {
            // Poste vertical
            this.ctx.beginPath();
            this.ctx.moveTo(50, 230);
            this.ctx.lineTo(50, 30);
            this.ctx.stroke();
        }
        
        if (this.lives <= 4) {
            // Poste horizontal
            this.ctx.beginPath();
            this.ctx.moveTo(50, 30);
            this.ctx.lineTo(140, 30);
            this.ctx.stroke();
        }
        
        if (this.lives <= 3) {
            // Cuerda
            this.ctx.beginPath();
            this.ctx.moveTo(140, 30);
            this.ctx.lineTo(140, 60);
            this.ctx.stroke();
        }
        
        if (this.lives <= 2) {
            // Cabeza
            this.ctx.beginPath();
            this.ctx.arc(140, 80, 20, 0, Math.PI * 2);
            this.ctx.stroke();
        }
        
        if (this.lives <= 1) {
            // Cuerpo
            this.ctx.beginPath();
            this.ctx.moveTo(140, 100);
            this.ctx.lineTo(140, 170);
            this.ctx.stroke();
            
            // Brazos
            this.ctx.beginPath();
            this.ctx.moveTo(140, 130);
            this.ctx.lineTo(110, 150);
            this.ctx.stroke();
            
            this.ctx.beginPath();
            this.ctx.moveTo(140, 130);
            this.ctx.lineTo(170, 150);
            this.ctx.stroke();
        }
        
        if (this.lives <= 0) {
            // Piernas
            this.ctx.beginPath();
            this.ctx.moveTo(140, 170);
            this.ctx.lineTo(120, 210);
            this.ctx.stroke();
            
            this.ctx.beginPath();
            this.ctx.moveTo(140, 170);
            this.ctx.lineTo(160, 210);
            this.ctx.stroke();
            
            // Ojos X
            this.ctx.strokeStyle = '#dc3545';
            this.ctx.lineWidth = 2;
            
            // Ojo izquierdo
            this.ctx.beginPath();
            this.ctx.moveTo(132, 75);
            this.ctx.lineTo(142, 85);
            this.ctx.stroke();
            this.ctx.beginPath();
            this.ctx.moveTo(142, 75);
            this.ctx.lineTo(132, 85);
            this.ctx.stroke();
            
            // Ojo derecho
            this.ctx.beginPath();
            this.ctx.moveTo(148, 75);
            this.ctx.lineTo(158, 85);
            this.ctx.stroke();
            this.ctx.beginPath();
            this.ctx.moveTo(158, 75);
            this.ctx.lineTo(148, 85);
            this.ctx.stroke();
            
            this.ctx.strokeStyle = '#0d6efd';
        }
    }
    
    checkWin() {
        return [...this.currentWord].every(letter => this.guessedLetters.has(letter));
    }
    
    endGame(won) {
        this.gameActive = false;
        clearInterval(this.timerInterval);
        
        // Bonus por tiempo
        if (won) {
            const timeBonus = Math.max(0, 100 - this.timer);
            this.points += timeBonus;
        }
        
        // Mostrar pantalla final
        this.showScreen('end');
        
        if (won) {
            this.endIcon.innerHTML = '<i class="bi bi-emoji-laughing display-1 text-success"></i>';
            this.endTitle.textContent = '¡GANASTE! 🎉';
            this.endTitle.className = 'card-title mb-4 text-success';
        } else {
            this.endIcon.innerHTML = '<i class="bi bi-emoji-frown display-1 text-danger"></i>';
            this.endTitle.textContent = '¡AHORCADO! 💀';
            this.endTitle.className = 'card-title mb-4 text-danger';
        }
        
        this.finalWord.textContent = this.currentWord.toUpperCase();
        this.finalPoints.textContent = this.points;
        this.finalTime.textContent = this.timer;
    }
    
    resetGame() {
        this.startGame();
    }
    
    backToGame() {
        this.showScreen('start');
        this.playerNameInput.value = '';
        this.playerNameInput.focus();
        this.startBtn.disabled = true;
    }
    
    async saveScore() {
        const scoreData = {
            nombre: this.playerName,
            puntos: this.points,
            tiempo: this.timer
        };
        
        try {
            // Mostrar spinner o feedback
            const btn = this.saveScoreBtn;
            const originalText = btn.innerHTML;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...';
            btn.disabled = true;
            
            const response = await fetch('../backend/save_score.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(scoreData)
            });
            
            const result = await response.json();
            
            // Restaurar botón
            btn.innerHTML = originalText;
            btn.disabled = false;
            
            if (result.success) {
                this.showToast('¡Score guardado exitosamente!', 'success');
                // Actualizar tabla de posiciones si está visible
                if (this.scoresScreen && !this.scoresScreen.classList.contains('hidden')) {
                    this.loadScores();
                }
            } else {
                this.showToast('Error al guardar: ' + (result.error || 'Error desconocido'), 'danger');
            }
        } catch (error) {
            console.error('Error:', error);
            this.saveScoreBtn.innerHTML = '<i class="bi bi-save"></i> GUARDAR SCORE';
            this.saveScoreBtn.disabled = false;
            this.showToast('Error de conexión al guardar el score', 'danger');
        }
    }
    
    showToast(message, type = 'info') {
        // Crear contenedor de toast si no existe
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        // Crear toast
        const toastElement = document.createElement('div');
        toastElement.className = `toast align-items-center text-bg-${type} border-0`;
        toastElement.setAttribute('role', 'alert');
        toastElement.setAttribute('aria-live', 'assertive');
        toastElement.setAttribute('aria-atomic', 'true');
        
        const iconMap = {
            'success': 'bi-check-circle-fill',
            'danger': 'bi-x-circle-fill',
            'warning': 'bi-exclamation-triangle-fill',
            'info': 'bi-info-circle-fill'
        };
        
        toastElement.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi ${iconMap[type] || iconMap['info']} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
            </div>
        `;
        
        toastContainer.appendChild(toastElement);
        
        // Inicializar y mostrar toast usando Bootstrap
        const toast = new bootstrap.Toast(toastElement, {
            animation: true,
            autohide: true,
            delay: 3000
        });
        
        toast.show();
        
        // Remover después de ocultar
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
    
    async showScores() {
        this.showScreen('scores');
        // Pequeña espera para asegurar que el DOM esté actualizado
        await new Promise(resolve => setTimeout(resolve, 100));
        this.updateSortSelects();
        this.loadScores();
    }
    
    async loadScores() {
        try {
            console.log('Loading scores with:', {
                orderBy: this.currentOrderBy,
                orderDir: this.currentOrderDir,
                search: this.currentSearch,
                page: this.currentPage
            });
            
            // Mostrar loading
            const scoresBody = document.getElementById('scoresBody');
            if (scoresBody) {
                scoresBody.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-info" role="status">
                                <span class="visually-hidden">Cargando...</span>
                            </div>
                            <p class="mt-2 text-muted">Cargando puntuaciones...</p>
                        </td>
                    </tr>
                `;
            }
            
            // Preparar datos para la petición
            const requestData = {
                orderBy: this.currentOrderBy,
                orderDir: this.currentOrderDir,
                search: this.currentSearch
            };
            
            const response = await fetch('../backend/get_scores.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.currentScores = result.scores || [];
                console.log('Scores loaded:', this.currentScores.length);
                this.displayScores();
                this.updateFilters();
                this.updateSearchResults();
            } else {
                throw new Error(result.error || 'Error desconocido');
            }
        } catch (error) {
            console.error('Error:', error);
            const scoresBody = document.getElementById('scoresBody');
            if (scoresBody) {
                scoresBody.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <i class="bi bi-exclamation-triangle display-4 text-warning"></i>
                            <p class="text-muted mt-2">Error al cargar las puntuaciones</p>
                            <button class="btn btn-outline-warning btn-sm" onclick="game.loadScores()">
                                <i class="bi bi-arrow-clockwise"></i> Reintentar
                            </button>
                        </td>
                    </tr>
                `;
            }
        }
    }
    
    displayScores() {
        const scoresBody = document.getElementById('scoresBody');
        if (!scoresBody) return;
        
        if (this.currentScores.length === 0) {
            scoresBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <p class="text-muted fs-5 mt-3">
                            ${this.currentSearch ? 
                                'No se encontraron resultados para tu búsqueda' : 
                                'No hay puntuaciones registradas aún'}
                        </p>
                        ${this.currentSearch ? `
                            <button class="btn btn-outline-info btn-sm" onclick="document.getElementById('clearSearchBtn').click()">
                                <i class="bi bi-x-circle"></i> Limpiar búsqueda
                            </button>
                        ` : ''}
                    </td>
                </tr>
            `;
            this.updatePagination(0);
            return;
        }
        
        // Calcular paginación
        const totalPages = Math.ceil(this.currentScores.length / this.itemsPerPage);
        const start = (this.currentPage - 1) * this.itemsPerPage;
        const end = Math.min(start + this.itemsPerPage, this.currentScores.length);
        const pageScores = this.currentScores.slice(start, end);
        
        // Renderizar scores
        scoresBody.innerHTML = '';
        
        pageScores.forEach((score, index) => {
            const globalIndex = start + index + 1;
            const row = scoresBody.insertRow();
            
            // Medallas para los primeros 3 cuando está ordenado por puntos descendente
            let positionHtml = globalIndex;
            if (this.currentOrderBy === 'puntos' && this.currentOrderDir === 'DESC') {
                if (globalIndex === 1) positionHtml = '🥇 1';
                else if (globalIndex === 2) positionHtml = '🥈 2';
                else if (globalIndex === 3) positionHtml = '🥉 3';
            }
            
            // Formatear fecha
            const date = new Date(score.fecha);
            const formattedDate = date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            row.innerHTML = `
                <td class="text-center fw-bold">${positionHtml}</td>
                <td>
                    <i class="bi bi-person-circle text-primary"></i>
                    ${this.highlightSearchTerm(score.nombre)}
                </td>
                <td>
                    <span class="badge bg-warning fs-6">${score.puntos}</span>
                </td>
                <td>
                    <i class="bi bi-clock text-info"></i> ${score.tiempo}s
                </td>
                <td>
                    <small class="text-muted">${formattedDate}</small>
                </td>
            `;
            
            // Agregar clase para resaltar si coincide con búsqueda
            if (this.currentSearch) {
                const searchLower = this.currentSearch.toLowerCase();
                if (score.nombre.toLowerCase().includes(searchLower) ||
                    score.puntos.toString().includes(searchLower) ||
                    score.tiempo.toString().includes(searchLower)) {
                    row.classList.add('highlight-row');
                }
            }
            
            // Agregar evento click para seleccionar fila
            row.addEventListener('click', () => {
                document.querySelectorAll('#scoresTable tbody tr').forEach(r => r.classList.remove('selected'));
                row.classList.add('selected');
            });
        });
        
        this.updatePagination(totalPages);
    }
    
    highlightSearchTerm(text) {
        if (!this.currentSearch || !text) return text;
        
        const regex = new RegExp(`(${this.escapeRegExp(this.currentSearch)})`, 'gi');
        return text.replace(regex, '<mark class="bg-info text-dark px-1 rounded">$1</mark>');
    }
    
    escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    updatePagination(totalPages) {
        const showingInfo = document.getElementById('showingInfo');
        const paginationButtons = document.getElementById('paginationButtons');
        
        if (!showingInfo || !paginationButtons) return;
        
        if (this.currentScores.length === 0 || totalPages === 0) {
            showingInfo.textContent = '';
            paginationButtons.innerHTML = '';
            return;
        }
        
        const start = (this.currentPage - 1) * this.itemsPerPage + 1;
        const end = Math.min(start + this.itemsPerPage - 1, this.currentScores.length);
        
        showingInfo.textContent = `Mostrando ${start}-${end} de ${this.currentScores.length} resultados`;
        
        // Crear botones de paginación
        let buttonsHtml = '';
        
        // Botón anterior
        buttonsHtml += `
            <button class="btn btn-outline-info btn-sm" 
                    onclick="game.previousPage()" 
                    ${this.currentPage === 1 ? 'disabled' : ''}>
                <i class="bi bi-chevron-left"></i>
            </button>
        `;
        
        // Números de página
        const maxVisiblePages = 7;
        let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage < maxVisiblePages - 1) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        if (startPage > 1) {
            buttonsHtml += `
                <button class="btn btn-outline-info btn-sm" onclick="game.goToPage(1)">1</button>
                ${startPage > 2 ? '<span class="btn btn-sm disabled">...</span>' : ''}
            `;
        }
        
        for (let i = startPage; i <= endPage; i++) {
            buttonsHtml += `
                <button class="btn btn-sm ${i === this.currentPage ? 'btn-info' : 'btn-outline-info'}" 
                        onclick="game.goToPage(${i})">
                    ${i}
                </button>
            `;
        }
        
        if (endPage < totalPages) {
            buttonsHtml += `
                ${endPage < totalPages - 1 ? '<span class="btn btn-sm disabled">...</span>' : ''}
                <button class="btn btn-outline-info btn-sm" onclick="game.goToPage(${totalPages})">${totalPages}</button>
            `;
        }
        
        // Botón siguiente
        buttonsHtml += `
            <button class="btn btn-outline-info btn-sm" 
                    onclick="game.nextPage()" 
                    ${this.currentPage === totalPages ? 'disabled' : ''}>
                <i class="bi bi-chevron-right"></i>
            </button>
        `;
        
        paginationButtons.innerHTML = buttonsHtml;
    }
    
    nextPage() {
        const totalPages = Math.ceil(this.currentScores.length / this.itemsPerPage);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.displayScores();
        }
    }
    
    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.displayScores();
        }
    }
    
    goToPage(page) {
        const totalPages = Math.ceil(this.currentScores.length / this.itemsPerPage);
        if (page >= 1 && page <= totalPages) {
            this.currentPage = page;
            this.displayScores();
        }
    }
    
    updateFilters() {
        const activeFilters = document.getElementById('activeFilters');
        if (!activeFilters) return;
        
        let filtersHtml = '';
        
        if (this.currentSearch) {
            filtersHtml += `
                <span class="badge bg-info me-2 mb-2">
                    <i class="bi bi-search"></i> 
                    Búsqueda: "${this.escapeHtml(this.currentSearch)}"
                    <button class="btn-close btn-close-white ms-1" 
                            onclick="document.getElementById('clearSearchBtn').click()"
                            style="font-size: 0.5em;"></button>
                </span>
            `;
        }
        
        const orderByNames = {
            'puntos': '🏆 Puntos',
            'nombre': '📝 Nombre',
            'tiempo': '⏱️ Tiempo',
            'fecha': '📅 Fecha',
            'id': '🆔 ID'
        };
        
        filtersHtml += `
            <span class="badge bg-secondary me-2 mb-2">
                <i class="bi bi-sort-${this.currentOrderDir === 'ASC' ? 'up' : 'down'}"></i>
                Orden: ${orderByNames[this.currentOrderBy] || this.currentOrderBy} 
                (${this.currentOrderDir === 'ASC' ? 'Ascendente' : 'Descendente'})
            </span>
        `;
        
        activeFilters.innerHTML = filtersHtml;
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    updateSearchResults() {
        const searchResults = document.getElementById('searchResults');
        const resultsCount = document.getElementById('resultsCount');
        
        if (!searchResults || !resultsCount) return;
        
        if (this.currentSearch) {
            searchResults.classList.remove('d-none');
            resultsCount.textContent = this.currentScores.length;
        } else {
            searchResults.classList.add('d-none');
        }
    }
    
    downloadPDF() {
        try {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Configuración inicial
            doc.setFont('helvetica');
            
            // Título principal
            doc.setFontSize(24);
            doc.setTextColor(13, 202, 240);
            doc.text('Juego del Ahorcado', 105, 20, null, null, 'center');
            
            doc.setFontSize(16);
            doc.setTextColor(108, 117, 125);
            doc.text('Tabla de Posiciones', 105, 30, null, null, 'center');
            
            // Información de filtros aplicados
            let yPos = 45;
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);
            
            if (this.currentSearch) {
                doc.text(`Búsqueda: "${this.currentSearch}"`, 20, yPos);
                yPos += 7;
            }
            
            const orderByNames = {
                'puntos': 'Puntos',
                'nombre': 'Nombre (Alfabético)',
                'tiempo': 'Tiempo',
                'fecha': 'Fecha',
                'id': 'ID'
            };
            
            doc.text(`Ordenado por: ${orderByNames[this.currentOrderBy]} (${this.currentOrderDir === 'ASC' ? 'Ascendente' : 'Descendente'})`, 20, yPos);
            yPos += 7;
            doc.text(`Total de resultados: ${this.currentScores.length}`, 20, yPos);
            yPos += 7;
            doc.text(`Fecha de generación: ${new Date().toLocaleString('es-ES')}`, 20, yPos);
            
            // Información del jugador actual si existe
            if (this.points > 0 && this.playerName) {
                yPos += 12;
                doc.setFontSize(11);
                doc.setTextColor(25, 135, 84);
                doc.text('Tu puntuación actual:', 20, yPos);
                yPos += 7;
                doc.setTextColor(0, 0, 0);
                doc.text(`Jugador: ${this.playerName}`, 25, yPos);
                yPos += 7;
                doc.text(`Puntos: ${this.points}`, 25, yPos);
                yPos += 7;
                doc.text(`Tiempo: ${this.timer}s`, 25, yPos);
            }
            
            // Tabla de posiciones
            yPos += 15;
            
            if (this.currentScores.length > 0) {
                // Headers de la tabla
                const colWidths = [15, 60, 30, 30, 50];
                let xPos = 20;
                
                // Fondo del header
                doc.setFillColor(33, 37, 41);
                doc.rect(xPos - 2, yPos - 5, 180, 8, 'F');
                
                doc.setTextColor(255, 255, 255);
                doc.setFontSize(11);
                doc.setFont(undefined, 'bold');
                
                const headers = ['#', 'Nombre', 'Puntos', 'Tiempo', 'Fecha'];
                headers.forEach((header, i) => {
                    doc.text(header, xPos, yPos);
                    xPos += colWidths[i];
                });
                
                // Datos de la tabla
                yPos += 8;
                doc.setFont(undefined, 'normal');
                
                this.currentScores.forEach((score, index) => {
                    // Nueva página si es necesario
                    if (yPos > 270) {
                        doc.addPage();
                        yPos = 20;
                        
                        // Reimprimir headers en nueva página
                        xPos = 20;
                        doc.setFillColor(33, 37, 41);
                        doc.rect(xPos - 2, yPos - 5, 180, 8, 'F');
                        doc.setTextColor(255, 255, 255);
                        doc.setFont(undefined, 'bold');
                        headers.forEach((header, i) => {
                            doc.text(header, xPos, yPos);
                            xPos += colWidths[i];
                        });
                        yPos += 8;
                        doc.setFont(undefined, 'normal');
                    }
                    
                    xPos = 20;
                    doc.setTextColor(0, 0, 0);
                    
                    // Color alternado para filas
                    if (index % 2 === 0) {
                        doc.setFillColor(248, 249, 250);
                        doc.rect(xPos - 2, yPos - 5, 180, 8, 'F');
                    }
                    
                    // Posición con medallas si está ordenado por puntos descendente
                    let position = (index + 1).toString();
                    if (this.currentOrderBy === 'puntos' && this.currentOrderDir === 'DESC') {
                        if (index === 0) position = '1 (oro)';
                        else if (index === 1) position = '2 (plata)';
                        else if (index === 2) position = '3 (bronce)';
                    }
                    
                    // Fecha formateada
                    const date = new Date(score.fecha);
                    const formattedDate = date.toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                    });
                    
                    const rowData = [
                        position,
                        score.nombre.substring(0, 25),
                        score.puntos.toString(),
                        `${score.tiempo}s`,
                        formattedDate
                    ];
                    
                    rowData.forEach((data, i) => {
                        doc.text(data.toString(), xPos, yPos);
                        xPos += colWidths[i];
                    });
                    
                    yPos += 8;
                });
            } else {
                doc.setFontSize(12);
                doc.setTextColor(108, 117, 125);
                doc.text('No hay puntuaciones para mostrar', 105, yPos, null, null, 'center');
            }
            
            // Pie de página
            const pageCount = doc.internal.getNumberOfPages();
            for (let i = 1; i <= pageCount; i++) {
                doc.setPage(i);
                doc.setFontSize(8);
                doc.setTextColor(150, 150, 150);
                doc.text(
                    `Página ${i} de ${pageCount} | Generado: ${new Date().toLocaleString('es-ES')} | Orden: ${orderByNames[this.currentOrderBy]} ${this.currentOrderDir === 'ASC' ? 'ASC' : 'DESC'}`,
                    105,
                    290,
                    null,
                    null,
                    'center'
                );
            }
            
            // Generar nombre de archivo descriptivo
            const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
            const orderInfo = `${this.currentOrderBy}_${this.currentOrderDir}`;
            const searchInfo = this.currentSearch ? `_busqueda_${this.currentSearch.replace(/[^a-z0-9]/gi, '_')}` : '';
            const filename = `ahorcado_scores_${orderInfo}${searchInfo}_${timestamp}.pdf`;
            
            doc.save(filename);
            this.showToast('PDF descargado exitosamente con los filtros actuales', 'success');
        } catch (error) {
            console.error('Error al generar PDF:', error);
            this.showToast('Error al generar el PDF: ' + error.message, 'danger');
        }
    }
}

// Inicializar el juego cuando se cargue la página
let game;
window.addEventListener('DOMContentLoaded', () => {
    game = new AhorcadoGame();
    // Hacer el juego accesible globalmente para los botones de paginación
    window.game = game;
});