import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Servir archivos estáticos
app.use(express.static(path.join(__dirname)));

// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Redirigir peticiones a la API del backend
app.use(express.json());

app.post('/api/save-score', async (req, res) => {
    try {
        const response = await fetch('http://localhost/backend/save_score.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req.body)
        });
        const data = await response.json();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Error de conexión con backend' });
    }
});

app.post('/api/get-scores', async (req, res) => {
    try {
        const response = await fetch('http://localhost/backend/get_scores.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req.body)
        });
        const data = await response.json();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Error de conexión con backend' });
    }
});

app.listen(PORT, () => {
    console.log(`Frontend corriendo en http://localhost:${PORT}`);
});