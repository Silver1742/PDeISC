const OPERADORES = ['+', '-', '×', '÷'];
const MAX_DIGITOS = 15;
const MAX_TOKENS = 41;

const esOperador = (token) => OPERADORES.includes(token);

// Estado de la calculadora del lado del cliente.
// Guarda la expresión como un VECTOR de tokens: ['12', '+', '3.5', '×', '2']
// Extiende EventTarget para emitir el EVENTO personalizado 'cambio'.
export class Calculadora extends EventTarget {
  #tokens = [];
  #resultado = null;
  #ultimaExpresion = '';
  #error = null;

  // ---------- GETTERS ----------
  get tokens() { return [...this.#tokens]; }
  get expresion() { return this.#tokens.join(' '); }
  get resultado() { return this.#resultado; }
  get ultimaExpresion() { return this.#ultimaExpresion; }
  get error() { return this.#error; }
  get vacia() { return this.#tokens.length === 0; }
  get mostrandoResultado() { return this.#resultado !== null; }
  get #ultimo() { return this.#tokens.at(-1); }

  // Lo que se ve en grande en la pantalla
  get entradaActual() {
    if (this.mostrandoResultado) return String(this.#resultado);
    const ultimo = this.#ultimo;
    if (!ultimo) return '0';
    return esOperador(ultimo) ? this.#tokens.at(-2) : ultimo;
  }

  // Valor numérico de lo que se está mostrando (para la memoria)
  get valorActual() {
    const texto = this.entradaActual ?? '0';
    const valor = Number.parseFloat(texto) / (texto.endsWith('%') ? 100 : 1);
    return Number.isFinite(valor) ? valor : 0;
  }

  // Se puede enviar al servidor si termina en número
  get lista() { return this.#tokens.length >= 3 && !esOperador(this.#ultimo); }

  // ---------- SETTERS ----------
  set resultado(valor) {
    if (typeof valor !== 'number' || !Number.isFinite(valor)) throw new Error('Resultado inválido');
    this.#ultimaExpresion = this.expresion;
    this.#resultado = valor;
    this.#error = null;
    this.#notificar('resultado');
  }

  set error(mensaje) {
    this.#error = mensaje;
    this.#notificar('error');
  }

  // ---------- ACCIONES ----------
  #continuarDesdeResultado(conservar) {
    if (!this.mostrandoResultado) return;
    this.#tokens = conservar ? [String(this.#resultado)] : [];
    this.#resultado = null;
    this.#ultimaExpresion = '';
  }

  digito(d) {
    this.#continuarDesdeResultado(false);
    this.#error = null;
    const ultimo = this.#ultimo;
    if (!ultimo || esOperador(ultimo)) {
      if (this.#tokens.length >= MAX_TOKENS) return;
      this.#tokens.push(d);
    } else if (!ultimo.endsWith('%')) {
      if (ultimo.replace(/[^\d]/g, '').length >= MAX_DIGITOS) return;
      const nuevo = ultimo === '0' ? d : ultimo === '-0' ? `-${d}` : ultimo + d;
      this.#tokens.splice(-1, 1, nuevo);
    }
    this.#notificar('entrada');
  }

  punto() {
    this.#continuarDesdeResultado(false);
    this.#error = null;
    const ultimo = this.#ultimo;
    if (!ultimo || esOperador(ultimo)) this.#tokens.push('0.');
    else if (!ultimo.includes('.') && !ultimo.includes('e') && !ultimo.endsWith('%')) this.#tokens.splice(-1, 1, `${ultimo}.`);
    this.#notificar('entrada');
  }

  operador(simbolo) {
    this.#continuarDesdeResultado(true);
    this.#error = null;
    if (this.vacia) this.#tokens.push('0');
    if (esOperador(this.#ultimo)) {
      this.#tokens.splice(-1, 1, simbolo); // reemplaza el operador anterior
    } else {
      if (this.#tokens.length >= MAX_TOKENS) return;
      if (this.#ultimo.endsWith('.')) this.#tokens.splice(-1, 1, this.#ultimo.slice(0, -1));
      this.#tokens.push(simbolo);
    }
    this.#notificar('entrada');
  }

  signo() {
    this.#continuarDesdeResultado(true);
    const ultimo = this.#ultimo;
    if (!ultimo || esOperador(ultimo)) return;
    this.#tokens.splice(-1, 1, ultimo.startsWith('-') ? ultimo.slice(1) : `-${ultimo}`);
    this.#notificar('entrada');
  }

  porcentaje() {
    this.#continuarDesdeResultado(true);
    const ultimo = this.#ultimo;
    if (!ultimo || esOperador(ultimo) || ultimo.endsWith('%')) return;
    this.#tokens.splice(-1, 1, `${ultimo.replace(/\.$/, '')}%`);
    this.#notificar('entrada');
  }

  // Inserta un número completo (desde la memoria o el historial)
  insertarNumero(valor) {
    this.#continuarDesdeResultado(false);
    this.#error = null;
    const texto = String(valor);
    const ultimo = this.#ultimo;
    if (!ultimo || esOperador(ultimo)) this.#tokens.push(texto);
    else this.#tokens.splice(-1, 1, texto);
    this.#notificar('entrada');
  }

  borrar() {
    if (this.mostrandoResultado) return this.limpiar();
    this.#error = null;
    const ultimo = this.#ultimo;
    if (!ultimo) return;
    const recortado = esOperador(ultimo) ? '' : ultimo.slice(0, -1);
    if (recortado === '' || recortado === '-') this.#tokens.pop();
    else this.#tokens.splice(-1, 1, recortado);
    this.#notificar('entrada');
  }

  limpiar() {
    this.#tokens = [];
    this.#resultado = null;
    this.#ultimaExpresion = '';
    this.#error = null;
    this.#notificar('limpiar');
  }

  #notificar(tipo) {
    this.dispatchEvent(new CustomEvent('cambio', { detail: { tipo, expresion: this.expresion } }));
  }
}
