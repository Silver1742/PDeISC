import { formatoNumero, formatoExpresion, formatoHora } from '../utils/formato.js';

// Cálculo recibido del servidor (cliente): solo GETTERS, es de lectura
export class Calculo {
  #id;
  #expresion;
  #resultado;
  #operadores;
  #fecha;

  constructor({ id, expresion, resultado, operadores = [], fecha }) {
    this.#id = id;
    this.#expresion = expresion;
    this.#resultado = resultado;
    this.#operadores = operadores;
    this.#fecha = fecha;
  }

  static desdeJSON(datos) {
    return new Calculo(datos);
  }

  get id() { return this.#id; }
  get expresion() { return this.#expresion; }
  get resultado() { return this.#resultado; }
  get operadores() { return [...this.#operadores]; }
  get fecha() { return this.#fecha; }

  get expresionFormateada() { return formatoExpresion(this.#expresion); }
  get resultadoFormateado() { return formatoNumero(this.#resultado); }
  get hace() { return formatoHora(this.#fecha); }

  coincideCon(texto) {
    const busqueda = texto.trim().replace(',', '.');
    return this.#expresion.includes(busqueda) || String(this.#resultado).includes(busqueda);
  }
}
