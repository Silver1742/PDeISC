const CLAVE = 'calculadora:memoria';

// Memoria de la calculadora (MC, MR, M+, M−) con GET / SET y persistencia local
export class Memoria extends EventTarget {
  #valor = 0;
  #activa = false;

  constructor() {
    super();
    try {
      const guardado = JSON.parse(localStorage.getItem(CLAVE));
      if (guardado && Number.isFinite(guardado.valor)) {
        this.#valor = guardado.valor;
        this.#activa = guardado.activa;
      }
    } catch { /* sin almacenamiento */ }
  }

  get valor() { return this.#valor; }
  get activa() { return this.#activa; }

  set valor(nuevo) {
    const n = Number(nuevo);
    if (!Number.isFinite(n)) throw new Error('La memoria solo acepta números');
    this.#valor = Number.parseFloat(n.toPrecision(12));
    this.#activa = true;
    this.#guardar();
  }

  sumar(n) { this.valor = this.#valor + n; }
  restar(n) { this.valor = this.#valor - n; }

  limpiar() {
    this.#valor = 0;
    this.#activa = false;
    this.#guardar();
  }

  #guardar() {
    try { localStorage.setItem(CLAVE, JSON.stringify({ valor: this.#valor, activa: this.#activa })); } catch { /* sin almacenamiento */ }
    this.dispatchEvent(new CustomEvent('cambio', { detail: { valor: this.#valor, activa: this.#activa } }));
  }
}
