// El teclado se define como un VECTOR de objetos y se dibuja dinámicamente.
// tipo: numero | operador | accion | igual | memoria
export const TECLAS = [
  { etiqueta: 'MC', accion: 'memoria-limpiar', tipo: 'memoria', titulo: 'Borrar memoria' },
  { etiqueta: 'MR', accion: 'memoria-recuperar', tipo: 'memoria', titulo: 'Recuperar memoria' },
  { etiqueta: 'M+', accion: 'memoria-sumar', tipo: 'memoria', titulo: 'Sumar a memoria' },
  { etiqueta: 'M−', accion: 'memoria-restar', tipo: 'memoria', titulo: 'Restar de memoria' },

  { etiqueta: 'C', accion: 'limpiar', tipo: 'accion', titulo: 'Borrar todo (Esc)', teclas: ['Escape', 'Delete'] },
  { etiqueta: '<i class="bi bi-backspace"></i>', accion: 'borrar', tipo: 'accion', titulo: 'Borrar último (Retroceso)', teclas: ['Backspace'] },
  { etiqueta: '%', accion: 'porcentaje', tipo: 'accion', titulo: 'Porcentaje (%)', teclas: ['%'] },
  { etiqueta: '÷', accion: 'operador', valor: '÷', tipo: 'operador', titulo: 'Dividir (/)', teclas: ['/', ':'] },

  { etiqueta: '7', accion: 'digito', valor: '7', tipo: 'numero', teclas: ['7'] },
  { etiqueta: '8', accion: 'digito', valor: '8', tipo: 'numero', teclas: ['8'] },
  { etiqueta: '9', accion: 'digito', valor: '9', tipo: 'numero', teclas: ['9'] },
  { etiqueta: '×', accion: 'operador', valor: '×', tipo: 'operador', titulo: 'Multiplicar (*)', teclas: ['*', 'x', 'X'] },

  { etiqueta: '4', accion: 'digito', valor: '4', tipo: 'numero', teclas: ['4'] },
  { etiqueta: '5', accion: 'digito', valor: '5', tipo: 'numero', teclas: ['5'] },
  { etiqueta: '6', accion: 'digito', valor: '6', tipo: 'numero', teclas: ['6'] },
  { etiqueta: '−', accion: 'operador', valor: '-', tipo: 'operador', titulo: 'Restar (-)', teclas: ['-'] },

  { etiqueta: '1', accion: 'digito', valor: '1', tipo: 'numero', teclas: ['1'] },
  { etiqueta: '2', accion: 'digito', valor: '2', tipo: 'numero', teclas: ['2'] },
  { etiqueta: '3', accion: 'digito', valor: '3', tipo: 'numero', teclas: ['3'] },
  { etiqueta: '+', accion: 'operador', valor: '+', tipo: 'operador', titulo: 'Sumar (+)', teclas: ['+'] },

  { etiqueta: '±', accion: 'signo', tipo: 'accion', titulo: 'Cambiar signo (F9)', teclas: ['F9'] },
  { etiqueta: '0', accion: 'digito', valor: '0', tipo: 'numero', teclas: ['0'] },
  { etiqueta: ',', accion: 'punto', tipo: 'numero', titulo: 'Decimal (. o ,)', teclas: ['.', ','] },
  { etiqueta: '=', accion: 'igual', tipo: 'igual', titulo: 'Calcular (Enter)', teclas: ['Enter', '='] },
];

// Mapa tecla física → definición de tecla (se arma recorriendo el vector)
export const MAPA_TECLADO = new Map(
  TECLAS.flatMap((tecla) => (tecla.teclas ?? []).map((fisica) => [fisica, tecla])),
);
