// Error que transporta la respuesta de error enviada por el servidor
export class ErrorApi extends Error {
  constructor(mensaje, status = 0, detalles = null) {
    super(mensaje);
    this.name = 'ErrorApi';
    this.status = status;
    this.detalles = detalles;
  }

  get sinConexion() { return this.status === 0; }
}
