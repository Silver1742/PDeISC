import { ErrorApi } from './ErrorApi.js';
import { Calculo } from '../models/Calculo.js';

// Axios se carga globalmente desde el CDN en index.html
const { axios } = window;

const cliente = axios.create({
  baseURL: '/api',
  timeout: 8000,
  headers: { 'Content-Type': 'application/json' },
});

// Interceptor: devuelve directamente el cuerpo y unifica los errores del servidor
cliente.interceptors.response.use(
  (respuesta) => respuesta.data,
  (error) => {
    const datos = error.response?.data;
    const mensaje = datos?.error ?? (error.code === 'ECONNABORTED' ? 'El servidor tardó demasiado en responder' : 'No se pudo conectar con el servidor');
    return Promise.reject(new ErrorApi(mensaje, error.response?.status ?? 0, datos?.detalles));
  },
);

// Operaciones realizadas con AXIOS
export const apiAxios = {
  async historial() {
    const { data } = await cliente.get('/historial');
    return data.map(Calculo.desdeJSON); // array JSON → vector de clases
  },

  eliminarCalculo(id) {
    return cliente.delete(`/historial/${id}`);
  },

  limpiarHistorial() {
    return cliente.delete('/historial');
  },

  async operaciones() {
    const { data } = await cliente.get('/operaciones');
    return data;
  },
};
