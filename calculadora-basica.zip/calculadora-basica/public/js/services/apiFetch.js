import { ErrorApi } from './ErrorApi.js';

const BASE = '/api';

// Envoltorio sobre FETCH que interpreta las respuestas del servidor
async function solicitar(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(`${BASE}${ruta}`, {
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      ...opciones,
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new ErrorApi('No se pudo conectar con el servidor');
  }

  const json = await respuesta.json().catch(() => ({ ok: false, error: 'Respuesta inválida del servidor' }));
  if (!respuesta.ok || !json.ok) throw new ErrorApi(json.error ?? `Error ${respuesta.status}`, respuesta.status, json.detalles);
  return json;
}

// Operaciones realizadas con FETCH
export const apiFetch = {
  // El servidor resuelve la expresión y la guarda en el historial
  calcular(expresion) {
    return solicitar('/calcular', { method: 'POST', body: JSON.stringify({ expresion }) });
  },

  // Vista previa: el servidor calcula pero no guarda. Se puede cancelar con AbortController.
  async previsualizar(expresion, signal) {
    const { data } = await solicitar('/calcular', { method: 'POST', body: JSON.stringify({ expresion, guardar: false }), signal });
    return data;
  },

  async estadisticas() {
    const { data } = await solicitar('/estadisticas');
    return data;
  },

  async salud() {
    const inicio = performance.now();
    const { data } = await solicitar('/salud');
    return { ...data, latencia: Math.round(performance.now() - inicio) };
  },
};
