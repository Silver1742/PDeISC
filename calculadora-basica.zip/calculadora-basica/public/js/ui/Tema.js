const CLAVE = 'calculadora:tema';

// Maneja el modo claro / oscuro de Bootstrap (atributo data-bs-theme)
export class Tema {
  #boton;
  #raiz = document.documentElement;
  #sistema = matchMedia('(prefers-color-scheme: dark)');

  constructor(boton) {
    this.#boton = boton;
    this.#actualizarIcono();

    this.#boton.addEventListener('click', () => this.alternar());

    // Evento: si el usuario no eligió un tema, sigue al del sistema operativo
    this.#sistema.addEventListener('change', (e) => {
      if (!this.#guardado) this.actual = e.matches ? 'dark' : 'light';
    });
  }

  get actual() { return this.#raiz.getAttribute('data-bs-theme'); }
  set actual(tema) {
    if (!['light', 'dark'].includes(tema)) throw new Error(`Tema inválido: ${tema}`);
    this.#raiz.setAttribute('data-bs-theme', tema);
    this.#actualizarIcono();
  }

  get #guardado() {
    try { return localStorage.getItem(CLAVE); } catch { return null; }
  }

  alternar() {
    this.actual = this.actual === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem(CLAVE, this.actual); } catch { /* sin almacenamiento */ }
    this.#boton.classList.remove('girando');
    void this.#boton.offsetWidth; // reinicia la animación
    this.#boton.classList.add('girando');
  }

  #actualizarIcono() {
    const oscuro = this.actual === 'dark';
    this.#boton.innerHTML = `<i class="bi ${oscuro ? 'bi-sun' : 'bi-moon-stars'}"></i>`;
    this.#boton.title = oscuro ? 'Modo claro (T)' : 'Modo oscuro (T)';
  }
}
