import { escaparHTML } from '../utils/formato.js';

const TIPOS = {
  exito: { icono: 'bi-check-circle-fill', color: 'text-success' },
  error: { icono: 'bi-x-circle-fill', color: 'text-danger' },
  info: { icono: 'bi-info-circle-fill', color: 'text-primary' },
  aviso: { icono: 'bi-exclamation-triangle-fill', color: 'text-warning' },
};

const contenedor = document.getElementById('toasts');

// Muestra un toast de Bootstrap (normalmente con el mensaje que devolvió el servidor)
export function notificar(mensaje, tipo = 'info', titulo = null) {
  const { icono, color } = TIPOS[tipo] ?? TIPOS.info;
  const elemento = document.createElement('div');
  elemento.className = 'toast align-items-center';
  elemento.setAttribute('role', tipo === 'error' ? 'alert' : 'status');
  elemento.setAttribute('aria-live', tipo === 'error' ? 'assertive' : 'polite');
  elemento.innerHTML = `
    <div class="d-flex">
      <div class="toast-body d-flex gap-2 align-items-start">
        <i class="bi ${icono} ${color} fs-5"></i>
        <div>
          ${titulo ? `<strong class="d-block">${escaparHTML(titulo)}</strong>` : ''}
          <span>${escaparHTML(mensaje)}</span>
        </div>
      </div>
      <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
    </div>`;
  contenedor.append(elemento);
  elemento.addEventListener('hidden.bs.toast', () => elemento.remove());
  bootstrap.Toast.getOrCreateInstance(elemento, { delay: 3500 }).show();
}
