import { TECLAS } from '../config/teclado.js';
import { escaparHTML as e, formatoNumero, formatoExpresion } from '../utils/formato.js';

const $ = (selector) => document.querySelector(selector);

const vacio = (icono, titulo, texto = '') => `
  <div class="estado-vacio">
    <i class="bi ${icono}"></i>
    <p class="fw-semibold mb-1">${titulo}</p>
    ${texto ? `<p class="small mb-0">${texto}</p>` : ''}
  </div>`;

// ================= TECLADO (se recorre el vector TECLAS) =================
export function renderTeclado() {
  $('#teclado').innerHTML = TECLAS.map((t) => `
    <button type="button" class="tecla tecla-${t.tipo}"
      data-accion="${t.accion}" ${t.valor ? `data-valor="${t.valor}"` : ''}
      ${t.titulo ? `title="${t.titulo}" aria-label="${t.titulo}"` : ''}>${t.etiqueta}</button>`).join('');
}

// Resalta visualmente la tecla presionada con el teclado físico
export function resaltarTecla(tecla) {
  const selector = tecla.valor ? `[data-accion="${tecla.accion}"][data-valor="${tecla.valor}"]` : `[data-accion="${tecla.accion}"]`;
  const boton = document.querySelector(`#teclado ${selector}`);
  if (!boton) return;
  boton.classList.add('presionada');
  setTimeout(() => boton.classList.remove('presionada'), 120);
}

// ================= PANTALLA =================
export function renderPantalla(calculadora, memoria) {
  const principal = $('#pantalla-principal');
  const texto = calculadora.mostrandoResultado
    ? formatoNumero(calculadora.resultado)
    : formatoExpresion(calculadora.entradaActual ?? '0');

  principal.textContent = texto;
  principal.classList.toggle('mediano', texto.length > 10 && texto.length <= 14);
  principal.classList.toggle('chico', texto.length > 14);

  const expresion = calculadora.mostrandoResultado ? `${calculadora.ultimaExpresion} =` : calculadora.expresion;
  $('#pantalla-expresion').innerHTML = expresion ? `<span>${e(formatoExpresion(expresion))}</span>` : '&nbsp;';

  const previa = $('#pantalla-previa');
  previa.classList.toggle('error', Boolean(calculadora.error));
  if (calculadora.error) previa.innerHTML = `<i class="bi bi-exclamation-circle me-1"></i>${e(calculadora.error)}`;
  else if (!calculadora.lista || calculadora.mostrandoResultado) previa.innerHTML = '&nbsp;';

  // Operador activo resaltado en el teclado
  const ultimo = calculadora.tokens.at(-1);
  document.querySelectorAll('.tecla-operador').forEach((b) => b.classList.toggle('activa', !calculadora.mostrandoResultado && b.dataset.valor === ultimo));

  $('#indicador-memoria').hidden = !memoria.activa;
  $('#indicador-memoria').title = `Memoria: ${formatoNumero(memoria.valor)}`;
  document.querySelectorAll('[data-accion="memoria-limpiar"], [data-accion="memoria-recuperar"]').forEach((b) => (b.disabled = !memoria.activa));
}

// Muestra la vista previa que calculó el servidor (o su mensaje de error)
export function renderPrevia(resultado, error = null) {
  const previa = $('#pantalla-previa');
  previa.classList.toggle('error', Boolean(error));
  if (error) previa.innerHTML = `<i class="bi bi-exclamation-circle me-1"></i>${e(error)}`;
  else previa.textContent = resultado === null ? ' ' : `= ${formatoNumero(resultado)}`;
}

export function animarResultado() {
  const principal = $('#pantalla-principal');
  principal.classList.remove('resultado');
  void principal.offsetWidth;
  principal.classList.add('resultado');
}

export function sacudirPantalla() {
  const pantalla = $('#pantalla');
  pantalla.classList.remove('sacudir');
  void pantalla.offsetWidth;
  pantalla.classList.add('sacudir');
}

export function setCalculando(activo) {
  $('#indicador-calculo').hidden = !activo;
  const igual = $('[data-accion="igual"]');
  if (igual) igual.disabled = activo;
}

// ================= HISTORIAL =================
const SIMBOLO_PRINCIPAL = (operadores) => {
  const prioridad = ['÷', '×', '-', '+'];
  return prioridad.find((op) => operadores.includes(op))?.replace('-', '−') ?? '=';
};

export function renderHistorial(calculos, total, idNuevo = null) {
  $('#contador-historial').textContent = total;
  $('#btn-vaciar').disabled = total === 0;
  const lista = $('#lista-historial');

  if (calculos.length === 0) {
    lista.innerHTML = total
      ? `<li>${vacio('bi-search', 'Sin coincidencias', 'Probá con otro número u operación.')}</li>`
      : `<li>${vacio('bi-calculator', 'Todavía no hay cálculos', 'Resolvé una operación y aparecerá acá.')}</li>`;
    return;
  }

  lista.innerHTML = calculos.map((c, i) => `
    <li class="item-historial ${c.id === idNuevo ? 'nuevo' : ''}" data-id="${c.id}" tabindex="0" role="button"
        title="Usar este resultado" style="animation-delay:${Math.min(i, 10) * 25}ms">
      <span class="icono-operacion">${SIMBOLO_PRINCIPAL(c.operadores)}</span>
      <div class="flex-grow-1 min-w-0 text-truncate">
        <div class="expresion text-truncate">${e(c.expresionFormateada)}</div>
        <div class="resultado text-truncate">= ${c.resultadoFormateado}</div>
      </div>
      <small class="text-body-secondary text-nowrap d-none d-sm-inline">${c.hace}</small>
      <div class="acciones d-flex">
        <button type="button" class="btn btn-sm btn-link text-body-secondary" data-accion="copiar" title="Copiar resultado" aria-label="Copiar resultado"><i class="bi bi-copy"></i></button>
        <button type="button" class="btn btn-sm btn-link text-danger" data-accion="eliminar" title="Eliminar" aria-label="Eliminar del historial"><i class="bi bi-x-lg"></i></button>
      </div>
    </li>`).join('');
}

// ================= PASO A PASO (respuesta del servidor) =================
export function renderPasos(calculo) {
  const contenedor = $('#contenido-pasos');
  if (!calculo) {
    contenedor.innerHTML = vacio('bi-diagram-3', 'Resolvé una operación', 'Acá vas a ver cómo el servidor la interpreta y la resuelve paso a paso.');
    return;
  }

  const ficha = (texto) => {
    const esOp = ['+', '-', '×', '÷'].includes(texto);
    return `<span class="ficha ${esOp ? 'op' : ''}">${e(esOp ? texto.replace('-', '−') : texto.replace('.', ','))}</span>`;
  };

  contenedor.innerHTML = `
    <div class="mb-4">
      <p class="subtitulo">1 · Expresión recibida (vector de tokens)</p>
      <div class="fichas">${calculo.expresion.split(' ').map(ficha).join('')}</div>
    </div>
    <div class="mb-4">
      <p class="subtitulo">2 · Notación postfija <span class="text-body-secondary text-lowercase fw-normal">(respeta × ÷ antes que + −)</span></p>
      <div class="fichas">${calculo.postfija.map(ficha).join('')}</div>
    </div>
    <div class="mb-4">
      <p class="subtitulo">3 · Resolución con una pila</p>
      ${calculo.pasos.map((p, i) => `
        <div class="paso" style="animation-delay:${i * 60}ms">
          <span class="numero-paso">${i + 1}</span>
          <span class="flex-grow-1">${formatoNumero(p.a)} ${p.operador.replace('-', '−')} ${formatoNumero(p.b)} = <strong>${formatoNumero(p.resultado)}</strong></span>
          <small class="text-body-secondary d-none d-sm-inline">${e(p.nombre)}</small>
        </div>`).join('')}
    </div>
    <div class="resultado-final d-flex justify-content-between align-items-center">
      <span class="text-body-secondary">Resultado</span>
      <span class="fs-4 fw-bold">${formatoNumero(calculo.resultado)}</span>
    </div>`;
}

// ================= ESTADÍSTICAS =================
export function renderEstadisticas(est) {
  const contenedor = $('#contenido-estadisticas');
  if (est.total === 0) {
    contenedor.innerHTML = vacio('bi-bar-chart-line', 'Sin datos todavía', 'Las estadísticas se calculan en el servidor a partir del historial.');
    return;
  }

  const kpis = [
    { titulo: 'Cálculos', valor: est.total, icono: 'bi-calculator' },
    { titulo: 'Suma de resultados', valor: est.suma, icono: 'bi-plus-slash-minus' },
    { titulo: 'Promedio', valor: Number.parseFloat(est.promedio.toFixed(4)), icono: 'bi-distribute-vertical' },
    { titulo: 'Máximo', valor: est.maximo, icono: 'bi-arrow-up-circle' },
    { titulo: 'Mínimo', valor: est.minimo, icono: 'bi-arrow-down-circle' },
  ];
  const maxUso = Math.max(...est.usoOperaciones.map((o) => o.veces), 1);
  const maxAbs = Math.max(...est.ultimos.map((u) => Math.abs(u.resultado)), 1);
  // Se completa el VECTOR hasta 12 posiciones para que el gráfico tenga tamaño fijo
  const ultimos = [...Array(12 - est.ultimos.length).fill(null), ...est.ultimos];

  contenedor.innerHTML = `
    <div class="row g-2 mb-4">
      ${kpis.map((k, i) => `
        <div class="${i === 0 ? 'col-12 col-sm-4' : 'col-6 col-sm-4'}">
          <div class="kpi">
            <p class="kpi-titulo"><i class="bi ${k.icono} me-1"></i>${k.titulo}</p>
            <p class="kpi-valor" title="${formatoNumero(k.valor)}">${formatoNumero(k.valor)}</p>
          </div>
        </div>`).join('')}
    </div>

    <p class="subtitulo">Uso de cada operación</p>
    <div class="mb-4">
      ${est.usoOperaciones.map((o) => `
        <div class="mb-2">
          <div class="d-flex justify-content-between small mb-1">
            <span><span class="ficha op me-2" style="min-width:1.8rem;padding:.1rem .4rem">${o.simbolo.replace('-', '−')}</span>${o.nombre}</span>
            <span class="text-body-secondary">${o.veces} ${o.veces === 1 ? 'vez' : 'veces'}</span>
          </div>
          <div class="progress" role="progressbar" aria-label="${o.nombre}" aria-valuenow="${o.veces}" aria-valuemin="0" aria-valuemax="${maxUso}">
            <div class="progress-bar" style="width:${(o.veces / maxUso) * 100}%"></div>
          </div>
        </div>`).join('')}
    </div>

    <p class="subtitulo">Últimos resultados</p>
    <div class="grafico" role="img" aria-label="Gráfico de los últimos resultados">
      ${ultimos.map((u, i) => (u === null
        ? '<div class="barra"><div class="relleno vacia"></div></div>'
        : `<div class="barra" title="${e(formatoExpresion(u.expresion))} = ${formatoNumero(u.resultado)}">
             <div class="relleno ${u.resultado < 0 ? 'negativo' : ''}" style="height:${Math.max((Math.abs(u.resultado) / maxAbs) * 100, 3)}%;animation-delay:${i * 30}ms"></div>
           </div>`)).join('')}
    </div>
    <p class="small text-body-secondary mt-2 mb-0"><i class="bi bi-info-circle me-1"></i>Pasá el mouse por una barra para ver el cálculo. En gris, resultados negativos.</p>`;
}
