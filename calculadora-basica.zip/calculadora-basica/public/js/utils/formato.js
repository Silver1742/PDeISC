const numero = new Intl.NumberFormat('es-AR', { maximumFractionDigits: 10 });
const hora = new Intl.DateTimeFormat('es-AR', { hour: '2-digit', minute: '2-digit' });
const relativo = new Intl.RelativeTimeFormat('es', { numeric: 'auto' });

// Formatea un número para mostrar (usa notación científica si es muy grande o muy chico)
export function formatoNumero(valor) {
  if (!Number.isFinite(valor)) return '—';
  const absoluto = Math.abs(valor);
  if (absoluto !== 0 && (absoluto >= 1e15 || absoluto < 1e-9)) return valor.toExponential(6).replace('.', ',');
  return numero.format(valor);
}

// Muestra los símbolos lindos en pantalla (- → −) y la coma decimal
export function formatoExpresion(expresion) {
  return String(expresion)
    .replace(/(^|\s)-(?=\s)/g, '$1−')
    .replace(/\./g, ',');
}

export function formatoHora(iso) {
  const fecha = new Date(iso);
  const minutos = Math.round((fecha - Date.now()) / 60_000);
  if (Math.abs(minutos) < 60) return minutos === 0 ? 'recién' : relativo.format(minutos, 'minute');
  return hora.format(fecha);
}

// Evita inyección de HTML
export function escaparHTML(texto) {
  return String(texto ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

// Retrasa la ejecución hasta que el usuario deja de tipear
export function debounce(funcion, espera = 250) {
  let temporizador;
  const envoltura = (...args) => {
    clearTimeout(temporizador);
    temporizador = setTimeout(() => funcion(...args), espera);
  };
  envoltura.cancelar = () => clearTimeout(temporizador);
  return envoltura;
}
