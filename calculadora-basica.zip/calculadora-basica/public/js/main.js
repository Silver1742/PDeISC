// ===================================================================
//  Calculadora Básica — punto de entrada del cliente (ES Modules)
// ===================================================================
import { Calculadora } from './models/Calculadora.js';
import { Memoria } from './models/Memoria.js';
import { MAPA_TECLADO } from './config/teclado.js';
import { apiFetch } from './services/apiFetch.js';
import { apiAxios } from './services/apiAxios.js';
import { Tema } from './ui/Tema.js';
import { notificar } from './ui/notificaciones.js';
import {
  renderTeclado, resaltarTecla, renderPantalla, renderPrevia, animarResultado, sacudirPantalla,
  setCalculando, renderHistorial, renderPasos, renderEstadisticas,
} from './ui/vistas.js';
import { debounce, formatoNumero } from './utils/formato.js';

const $ = (selector) => document.querySelector(selector);

// La página siempre abre arriba de todo (el navegador no restaura el scroll anterior)
history.scrollRestoration = 'manual';

// ---------- Estado ----------
const calculadora = new Calculadora();
const memoria = new Memoria();
const tema = new Tema($('#btn-tema'));
const modalConfirmar = bootstrap.Modal.getOrCreateInstance('#modal-confirmar');
const modalAyuda = bootstrap.Modal.getOrCreateInstance('#modal-ayuda');

const estado = {
  historial: [],          // vector de instancias de Calculo
  filtro: '',
  idNuevo: null,
  controladorPrevia: null,
};

renderTeclado();

// ===================================================================
//  COMUNICACIÓN CON EL SERVIDOR
// ===================================================================

// Vista previa en vivo: el servidor calcula mientras se escribe (sin guardar)
const pedirPrevia = debounce(async () => {
  estado.controladorPrevia?.abort();
  if (!calculadora.lista || calculadora.mostrandoResultado) return;

  const controlador = new AbortController();
  estado.controladorPrevia = controlador;
  try {
    const data = await apiFetch.previsualizar(calculadora.expresion, controlador.signal);
    renderPrevia(data.resultado);
  } catch (error) {
    if (error.name !== 'AbortError') renderPrevia(null, error.status === 400 ? error.message : null);
  }
}, 250);

function cancelarPrevia() {
  pedirPrevia.cancelar();
  estado.controladorPrevia?.abort();
}

// "=" → el servidor resuelve, guarda en el historial y devuelve los pasos
async function calcular() {
  if (calculadora.mostrandoResultado || calculadora.tokens.length <= 1) return;
  if (!calculadora.lista) {
    calculadora.error = 'Completá la operación antes de calcular';
    sacudirPantalla();
    return;
  }

  cancelarPrevia();
  setCalculando(true);
  try {
    const { data } = await apiFetch.calcular(calculadora.expresion);
    calculadora.resultado = data.resultado; // setter de la clase
    animarResultado();
    renderPasos(data);
    estado.idNuevo = data.id;
    await Promise.all([cargarHistorial(), cargarEstadisticas()]);
  } catch (error) {
    calculadora.error = error.message; // mensaje enviado por el servidor
    sacudirPantalla();
  } finally {
    setCalculando(false);
  }
}

async function cargarHistorial() {
  try {
    estado.historial = await apiAxios.historial();
    mostrarHistorial();
  } catch (error) {
    notificar(error.message, 'error', 'Historial');
  }
}

async function cargarEstadisticas() {
  try {
    renderEstadisticas(await apiFetch.estadisticas());
  } catch (error) {
    notificar(error.message, 'error', 'Estadísticas');
  }
}

function mostrarHistorial() {
  const filtrados = estado.filtro
    ? estado.historial.filter((c) => c.coincideCon(estado.filtro))
    : estado.historial;
  renderHistorial(filtrados, estado.historial.length, estado.idNuevo);
}

async function copiar(valor) {
  try {
    await navigator.clipboard.writeText(String(valor));
    notificar(`${formatoNumero(valor)} copiado al portapapeles`, 'exito');
  } catch {
    notificar('No se pudo copiar al portapapeles', 'aviso');
  }
}

// ===================================================================
//  ACCIONES DE LA CALCULADORA
// ===================================================================
function ejecutar({ accion, valor }) {
  switch (accion) {
    case 'digito': return calculadora.digito(valor);
    case 'punto': return calculadora.punto();
    case 'operador': return calculadora.operador(valor);
    case 'signo': return calculadora.signo();
    case 'porcentaje': return calculadora.porcentaje();
    case 'borrar': return calculadora.borrar();
    case 'limpiar': return calculadora.limpiar();
    case 'igual': return calcular();
    case 'memoria-sumar':
      memoria.sumar(calculadora.valorActual);
      return notificar(`Memoria: ${formatoNumero(memoria.valor)}`, 'info');
    case 'memoria-restar':
      memoria.restar(calculadora.valorActual);
      return notificar(`Memoria: ${formatoNumero(memoria.valor)}`, 'info');
    case 'memoria-recuperar': return calculadora.insertarNumero(memoria.valor);
    case 'memoria-limpiar': return memoria.limpiar();
  }
}

// ===================================================================
//  EVENTOS
// ===================================================================

// Evento personalizado 'cambio' emitido por la clase Calculadora
calculadora.addEventListener('cambio', ({ detail }) => {
  renderPantalla(calculadora, memoria);
  if (detail.tipo === 'entrada') pedirPrevia();
  else if (detail.tipo !== 'error') cancelarPrevia();
});

// Evento personalizado 'cambio' emitido por la clase Memoria
memoria.addEventListener('cambio', () => renderPantalla(calculadora, memoria));

// Click en el teclado en pantalla (delegación de eventos)
$('#teclado').addEventListener('click', (e) => {
  const boton = e.target.closest('.tecla');
  if (boton) ejecutar(boton.dataset);
});

// Teclado físico
document.addEventListener('keydown', (e) => {
  if (e.target.closest('input, textarea, select') || document.querySelector('.modal.show')) return;

  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c' && !getSelection().toString()) {
    e.preventDefault();
    return copiar(calculadora.mostrandoResultado ? calculadora.resultado : calculadora.valorActual);
  }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key.toLowerCase() === 't') return tema.alternar();
  if (e.key === '?') return modalAyuda.show();

  const tecla = MAPA_TECLADO.get(e.key);
  if (!tecla) return;
  e.preventDefault(); // evita, por ejemplo, que Enter "clickee" el botón con foco
  resaltarTecla(tecla);
  ejecutar(tecla);
});

$('#btn-copiar').addEventListener('click', () => {
  copiar(calculadora.mostrandoResultado ? calculadora.resultado : calculadora.valorActual);
});

// ---------- Historial ----------
$('#buscar-historial').addEventListener('input', (e) => {
  estado.filtro = e.target.value;
  mostrarHistorial();
});

async function usarCalculo(id) {
  const calculo = estado.historial.find((c) => c.id === id);
  if (!calculo) return;
  calculadora.insertarNumero(calculo.resultado);
  try {
    renderPasos(await apiFetch.previsualizar(calculo.expresion));
  } catch { /* los pasos son opcionales */ }
}

$('#lista-historial').addEventListener('click', async (e) => {
  const item = e.target.closest('.item-historial');
  if (!item) return;
  const id = Number(item.dataset.id);
  const accion = e.target.closest('[data-accion]')?.dataset.accion;

  if (accion === 'copiar') {
    return copiar(estado.historial.find((c) => c.id === id).resultado);
  }
  if (accion === 'eliminar') {
    try {
      const respuesta = await apiAxios.eliminarCalculo(id);
      notificar(respuesta.mensaje, 'exito');
      await Promise.all([cargarHistorial(), cargarEstadisticas()]);
    } catch (error) {
      notificar(error.message, 'error');
    }
    return;
  }
  usarCalculo(id);
});

$('#lista-historial').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.target.matches('.item-historial')) usarCalculo(Number(e.target.dataset.id));
});

$('#btn-confirmar-vaciar').addEventListener('click', async (e) => {
  const boton = e.currentTarget;
  boton.disabled = true;
  try {
    const respuesta = await apiAxios.limpiarHistorial();
    notificar(respuesta.mensaje, 'exito', 'Historial');
    modalConfirmar.hide();
    renderPasos(null);
    await Promise.all([cargarHistorial(), cargarEstadisticas()]);
  } catch (error) {
    notificar(error.message, 'error');
  } finally {
    boton.disabled = false;
  }
});

// Evento de Bootstrap: refresca las estadísticas al abrir la pestaña
$('#boton-estadisticas').addEventListener('shown.bs.tab', cargarEstadisticas);

// ---------- Alto de la calculadora (evento resize) ----------
// En escritorio la calculadora ocupa el alto de la pantalla menos la barra de navegación
function medirNavbar() {
  document.documentElement.style.setProperty('--alto-navbar', `${$('.app-navbar').offsetHeight}px`);
}
window.addEventListener('resize', medirNavbar);

// ---------- Botón volver arriba (evento scroll) ----------
const botonSubir = $('#btn-subir');

function actualizarBotonSubir() {
  const alFondo = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 8;
  botonSubir.classList.toggle('visible', window.scrollY > 300 || (window.scrollY > 0 && alFondo));
}

window.addEventListener('scroll', actualizarBotonSubir, { passive: true });
window.addEventListener('resize', actualizarBotonSubir);
botonSubir.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
  botonSubir.blur();
});

// ---------- Estado del servidor ----------
async function verificarServidor() {
  const indicador = $('#estado-api');
  try {
    const salud = await apiFetch.salud();
    indicador.className = 'estado-api d-none d-sm-inline-flex en-linea';
    indicador.querySelector('.texto').textContent = `Servidor · ${salud.latencia} ms`;
    indicador.title = `Node ${salud.node} · activo hace ${salud.uptime} s`;
  } catch {
    indicador.className = 'estado-api d-none d-sm-inline-flex fuera-linea';
    indicador.querySelector('.texto').textContent = 'Sin conexión';
    indicador.title = 'No se pudo contactar al servidor';
  }
}

window.addEventListener('online', verificarServidor);
window.addEventListener('offline', verificarServidor);
setInterval(verificarServidor, 20_000);

// ===================================================================
//  INICIO
// ===================================================================
medirNavbar();
actualizarBotonSubir();
renderPantalla(calculadora, memoria);
renderPasos(null);
cargarHistorial();
cargarEstadisticas();
verificarServidor();
