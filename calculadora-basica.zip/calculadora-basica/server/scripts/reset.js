import { rm } from 'node:fs/promises';
import { RUTA_DB } from '../config.js';

await rm(RUTA_DB, { force: true });
console.log('🧹 Historial reiniciado. Se regenerará con cálculos de ejemplo al iniciar el servidor.');
