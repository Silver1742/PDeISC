// Errores HTTP personalizados (herencia de clases)
export class HttpError extends Error {
  constructor(status, mensaje, detalles = null) {
    super(mensaje);
    this.name = 'HttpError';
    this.status = status;
    this.detalles = detalles;
  }
}

export class ErrorValidacion extends HttpError {
  constructor(mensaje, detalles = null) {
    super(400, mensaje, detalles);
    this.name = 'ErrorValidacion';
  }
}

export class ErrorNoEncontrado extends HttpError {
  constructor(mensaje) {
    super(404, mensaje);
    this.name = 'ErrorNoEncontrado';
  }
}
