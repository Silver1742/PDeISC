import { HttpError } from './errores.js';

// Envía una respuesta JSON estandarizada desde el servidor
export function enviarJSON(res, status, cuerpo) {
  const json = JSON.stringify(cuerpo);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(json),
    'Cache-Control': 'no-store',
  });
  res.end(json);
}

// Lee el cuerpo de la petición usando los EVENTOS 'data' / 'end' del stream de Node
export function leerCuerpo(req, limite = 1_000_000) {
  return new Promise((resolve, reject) => {
    let datos = '';

    req.on('data', (chunk) => {
      datos += chunk;
      if (datos.length > limite) {
        reject(new HttpError(413, 'El cuerpo de la petición es demasiado grande'));
        req.destroy();
      }
    });

    req.on('end', () => {
      if (!datos) return resolve({});
      try {
        resolve(JSON.parse(datos));
      } catch {
        reject(new HttpError(400, 'El cuerpo de la petición no es un JSON válido'));
      }
    });

    req.on('error', reject);
  });
}

export function manejarError(res, error) {
  const status = error instanceof HttpError ? error.status : 500;
  if (status === 500) console.error('💥', error);
  if (res.headersSent) return res.end();
  enviarJSON(res, status, {
    ok: false,
    error: status === 500 ? 'Error interno del servidor' : error.message,
    detalles: error.detalles ?? null,
  });
}
