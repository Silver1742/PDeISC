// Router minimalista hecho a mano (sin Express)
export class Router {
  #rutas = [];

  #registrar(metodo, patron, manejador) {
    const claves = [];
    const fuente = patron.replace(/:(\w+)/g, (_, clave) => {
      claves.push(clave);
      return '([^/]+)';
    });
    this.#rutas.push({ metodo, patron, regex: new RegExp(`^${fuente}/?$`), claves, manejador });
    return this;
  }

  get(patron, manejador) { return this.#registrar('GET', patron, manejador); }
  post(patron, manejador) { return this.#registrar('POST', patron, manejador); }
  put(patron, manejador) { return this.#registrar('PUT', patron, manejador); }
  delete(patron, manejador) { return this.#registrar('DELETE', patron, manejador); }

  // Devuelve el manejador y los parámetros de la ruta, o null
  resolver(metodo, ruta) {
    for (const { metodo: m, regex, claves, manejador } of this.#rutas) {
      if (m !== metodo) continue;
      const coincidencia = ruta.match(regex);
      if (!coincidencia) continue;
      const params = Object.fromEntries(claves.map((clave, i) => [clave, decodeURIComponent(coincidencia[i + 1])]));
      return { manejador, params };
    }
    return null;
  }

  get rutas() {
    return this.#rutas.map(({ metodo, patron }) => `${metodo.padEnd(6)} ${patron}`);
  }
}
