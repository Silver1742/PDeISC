import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { PUERTO, CARPETA_PUBLICA, RUTA_DB } from './config.js';
import { Calculadora } from './models/Calculadora.js';
import { Historial } from './models/Historial.js';
import { Router } from './utils/Router.js';
import { registrarRutas } from './routes/api.js';
import { leerCuerpo, manejarError } from './utils/http.js';
import { HttpError } from './utils/errores.js';

const TIPOS_MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

// ---------- Modelos + eventos del servidor ----------
const calculadora = new Calculadora();
const historial = new Historial(RUTA_DB);
historial
  .on('inicializado', (n) => console.log(`🌱 Historial creado con ${n} cálculos de ejemplo`))
  .on('calculo', (c) => console.log(`🧮 ${c.expresion} = ${c.resultado}`))
  .on('eliminado', (c) => console.log(`🗑️  Eliminado: ${c.expresion}`))
  .on('limpiado', (n) => console.log(`🧹 Historial vaciado (${n} cálculos)`));
await historial.cargar(calculadora);

const router = registrarRutas(new Router(), { calculadora, historial });

// ---------- Archivos estáticos ----------
async function servirEstatico(ruta, res) {
  const relativa = ruta === '/' ? 'index.html' : decodeURIComponent(ruta).replace(/^\/+/, '');
  const archivo = path.normalize(path.join(CARPETA_PUBLICA, relativa));
  if (!archivo.startsWith(CARPETA_PUBLICA)) throw new HttpError(403, 'Acceso denegado');

  try {
    const contenido = await readFile(archivo);
    res.writeHead(200, {
      'Content-Type': TIPOS_MIME[path.extname(archivo)] ?? 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(contenido);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404 - Recurso no encontrado');
  }
}

// ---------- Servidor HTTP ----------
const servidor = http.createServer(async (req, res) => {
  const inicio = performance.now();
  const url = new URL(req.url, `http://${req.headers.host ?? 'localhost'}`);

  // Evento 'finish' de la respuesta: log de cada petición a la API
  res.on('finish', () => {
    if (url.pathname.startsWith('/api/')) {
      console.log(`${req.method.padEnd(6)} ${url.pathname} → ${res.statusCode} (${(performance.now() - inicio).toFixed(1)} ms)`);
    }
  });

  try {
    if (!url.pathname.startsWith('/api/')) return await servirEstatico(url.pathname, res);

    const ruta = router.resolver(req.method, url.pathname);
    if (!ruta) throw new HttpError(404, `Ruta no encontrada: ${req.method} ${url.pathname}`);

    const cuerpo = ['POST', 'PUT'].includes(req.method) ? await leerCuerpo(req) : {};
    const query = Object.fromEntries(url.searchParams);
    await ruta.manejador({ req, res, params: ruta.params, query, cuerpo });
  } catch (error) {
    manejarError(res, error);
  }
});

// Evento 'error' del servidor: por ejemplo, el puerto ya está en uso
servidor.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`❌ El puerto ${PUERTO} ya está en uso. Cerrá el otro servidor o usá otro puerto (PORT=3001 npm start).`);
    process.exit(1);
  }
  throw error;
});

servidor.listen(PUERTO, () => {
  console.log(`\n🧮 Calculadora Básica corriendo en http://localhost:${PUERTO}\n`);
  console.log('Rutas de la API:');
  router.rutas.forEach((r) => console.log(`   ${r}`));
  console.log('');
});
