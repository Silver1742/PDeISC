import path from 'node:path';
import { fileURLToPath } from 'node:url';

const raiz = path.dirname(fileURLToPath(import.meta.url));

export const PUERTO = Number(process.env.PORT) || 3000;
export const CARPETA_PUBLICA = path.join(raiz, '..', 'public');
export const RUTA_DB = path.join(raiz, 'data', 'historial.json');
