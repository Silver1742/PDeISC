import { ErrorValidacion } from '../utils/errores.js';

// Un cálculo guardado en el historial (GETTERS y SETTERS con validación)
export class Calculo {
  #id;
  #expresion;
  #resultado;
  #operadores;
  #fecha;

  constructor({ id, expresion, resultado, operadores = [], fecha = new Date().toISOString() }) {
    this.#id = Number(id);
    this.expresion = expresion;
    this.resultado = resultado;
    this.#operadores = [...operadores];
    this.#fecha = fecha;
  }

  get id() { return this.#id; }
  get expresion() { return this.#expresion; }
  get resultado() { return this.#resultado; }
  get operadores() { return [...this.#operadores]; }
  get fecha() { return this.#fecha; }

  set expresion(valor) {
    const texto = String(valor ?? '').trim();
    if (!texto) throw new ErrorValidacion('La expresión del cálculo no puede estar vacía');
    this.#expresion = texto;
  }

  set resultado(valor) {
    if (typeof valor !== 'number' || !Number.isFinite(valor)) throw new ErrorValidacion('El resultado debe ser un número finito');
    this.#resultado = valor;
  }

  toJSON() {
    return {
      id: this.#id,
      expresion: this.#expresion,
      resultado: this.#resultado,
      operadores: this.#operadores,
      fecha: this.#fecha,
    };
  }
}
