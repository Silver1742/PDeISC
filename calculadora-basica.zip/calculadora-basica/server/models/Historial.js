import { EventEmitter } from 'node:events';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { Calculo } from './Calculo.js';
import { OPERACIONES } from './Operacion.js';
import { ErrorNoEncontrado } from '../utils/errores.js';

const LIMITE = 100;
const EJEMPLOS = ['12 + 30', '144 ÷ 12', '7 × 8 - 6', '2.5 × 4 + 10', '200 × 15%', '99 ÷ 3 + 1'];

// Historial: VECTOR DE CLASES (Calculo[]) persistido en un archivo JSON.
// Extiende EventEmitter para emitir EVENTOS del lado del servidor.
export class Historial extends EventEmitter {
  #calculos = [];
  #archivo;

  constructor(archivo) {
    super();
    this.#archivo = archivo;
  }

  get calculos() { return [...this.#calculos].reverse(); } // más recientes primero
  get cantidad() { return this.#calculos.length; }

  async cargar(calculadora) {
    try {
      const datos = JSON.parse(await readFile(this.#archivo, 'utf-8'));
      this.#calculos = datos.map((c) => new Calculo(c));
    } catch {
      // Primera ejecución: se generan cálculos de ejemplo usando la calculadora real
      const hace = Date.now() - EJEMPLOS.length * 60_000;
      this.#calculos = EJEMPLOS.map((expresion, i) => new Calculo({
        ...calculadora.calcular(expresion),
        id: i + 1,
        fecha: new Date(hace + i * 60_000).toISOString(),
      }));
      await this.guardar();
      this.emit('inicializado', this.cantidad);
    }
    return this;
  }

  async guardar() {
    await mkdir(path.dirname(this.#archivo), { recursive: true });
    await writeFile(this.#archivo, JSON.stringify(this.#calculos, null, 2), 'utf-8');
  }

  async agregar(datos) {
    const id = this.#calculos.reduce((max, c) => Math.max(max, c.id), 0) + 1;
    const calculo = new Calculo({ ...datos, id });
    this.#calculos.push(calculo);
    if (this.#calculos.length > LIMITE) this.#calculos.shift(); // descarta el más antiguo
    await this.guardar();
    this.emit('calculo', calculo);
    return calculo;
  }

  async eliminar(id) {
    const calculo = this.#calculos.find((c) => c.id === Number(id));
    if (!calculo) throw new ErrorNoEncontrado(`No existe un cálculo con id ${id}`);
    this.#calculos = this.#calculos.filter((c) => c !== calculo);
    await this.guardar();
    this.emit('eliminado', calculo);
    return calculo;
  }

  async limpiar() {
    const cantidad = this.#calculos.length;
    this.#calculos = [];
    await this.guardar();
    this.emit('limpiado', cantidad);
    return cantidad;
  }

  // Estadísticas con métodos de arrays: map, reduce, filter, Math.max/min con spread
  estadisticas() {
    const resultados = this.#calculos.map((c) => c.resultado);
    const total = resultados.length;
    const suma = resultados.reduce((acc, n) => acc + n, 0);
    const todosLosOperadores = this.#calculos.flatMap((c) => c.operadores);

    return {
      total,
      suma: Number.parseFloat(suma.toPrecision(12)),
      promedio: total ? Number.parseFloat((suma / total).toPrecision(12)) : 0,
      maximo: total ? Math.max(...resultados) : 0,
      minimo: total ? Math.min(...resultados) : 0,
      // VECTOR con el uso de cada operación
      usoOperaciones: OPERACIONES.map((op) => ({
        simbolo: op.simbolo,
        nombre: op.nombre,
        veces: todosLosOperadores.filter((s) => s === op.simbolo).length,
      })),
      // VECTOR con los últimos 12 resultados (para el gráfico)
      ultimos: this.#calculos.slice(-12).map(({ id, expresion, resultado }) => ({ id, expresion, resultado })),
    };
  }
}
