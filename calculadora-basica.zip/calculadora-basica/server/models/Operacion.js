import { ErrorValidacion } from '../utils/errores.js';

// Clase base: cada operación sabe su símbolo, nombre, precedencia y cómo aplicarse
export class Operacion {
  #simbolo;
  #nombre;
  #precedencia;

  constructor(simbolo, nombre, precedencia) {
    this.#simbolo = simbolo;
    this.#nombre = nombre;
    this.#precedencia = precedencia;
  }

  get simbolo() { return this.#simbolo; }
  get nombre() { return this.#nombre; }
  get precedencia() { return this.#precedencia; }

  aplicar() {
    throw new Error(`La operación ${this.#nombre} no implementa aplicar()`);
  }

  toJSON() {
    return { simbolo: this.#simbolo, nombre: this.#nombre, precedencia: this.#precedencia };
  }
}

// Subclases (herencia + polimorfismo)
export class Suma extends Operacion {
  constructor() { super('+', 'Suma', 1); }
  aplicar(a, b) { return a + b; }
}

export class Resta extends Operacion {
  constructor() { super('-', 'Resta', 1); }
  aplicar(a, b) { return a - b; }
}

export class Multiplicacion extends Operacion {
  constructor() { super('×', 'Multiplicación', 2); }
  aplicar(a, b) { return a * b; }
}

export class Division extends Operacion {
  constructor() { super('÷', 'División', 2); }
  aplicar(a, b) {
    if (b === 0) throw new ErrorValidacion('No se puede dividir por cero');
    return a / b;
  }
}

// VECTOR DE CLASES con todas las operaciones disponibles
export const OPERACIONES = [new Suma(), new Resta(), new Multiplicacion(), new Division()];
