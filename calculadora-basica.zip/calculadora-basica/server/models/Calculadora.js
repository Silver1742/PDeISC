import { OPERACIONES } from './Operacion.js';
import { ErrorValidacion } from '../utils/errores.js';

const MAX_LARGO = 200;
const NUMERO = /^-?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?%?/i;

// Redondea para evitar errores de coma flotante (0.1 + 0.2 = 0.3)
const redondear = (n) => Number.parseFloat(n.toPrecision(12));

// Motor de cálculo del lado del servidor. No usa eval(): tokeniza la expresión,
// la convierte a notación postfija (algoritmo shunting-yard) y la resuelve con una pila.
export class Calculadora {
  #operaciones = new Map(OPERACIONES.map((op) => [op.simbolo, op]));

  get operaciones() { return [...this.#operaciones.values()]; }

  #normalizar(expresion) {
    return String(expresion ?? '')
      .replace(/[*xX]/g, '×')
      .replace(/[/:]/g, '÷')
      .replace(/[−–]/g, '-')
      .replace(/,/g, '.')
      .trim();
  }

  // 1) Texto → VECTOR de tokens
  tokenizar(expresion) {
    const texto = this.#normalizar(expresion);
    if (!texto) throw new ErrorValidacion('La expresión está vacía');
    if (texto.length > MAX_LARGO) throw new ErrorValidacion(`La expresión supera los ${MAX_LARGO} caracteres`);

    const tokens = [];
    let i = 0;
    while (i < texto.length) {
      const caracter = texto[i];
      if (caracter === ' ') { i++; continue; }

      const esperaNumero = tokens.length === 0 || tokens.at(-1).tipo === 'operador';

      if (esperaNumero) {
        const coincidencia = texto.slice(i).match(NUMERO);
        if (!coincidencia) {
          const motivo = this.#operaciones.has(caracter) ? `Falta un número antes de "${caracter}"` : `Carácter no válido: "${caracter}"`;
          throw new ErrorValidacion(motivo);
        }
        const literal = coincidencia[0];
        let valor = Number.parseFloat(literal);
        if (literal.endsWith('%')) valor /= 100;
        tokens.push({ tipo: 'numero', valor, texto: literal });
        i += literal.length;
      } else if (this.#operaciones.has(caracter)) {
        tokens.push({ tipo: 'operador', valor: caracter, texto: caracter });
        i++;
      } else {
        throw new ErrorValidacion(`Carácter no válido: "${caracter}"`);
      }
    }

    if (tokens.at(-1).tipo === 'operador') throw new ErrorValidacion('La expresión no puede terminar en un operador');
    return tokens;
  }

  // 2) Infija → postfija respetando la precedencia (× ÷ antes que + -)
  aPostfija(tokens) {
    const salida = [];
    const pila = [];
    for (const token of tokens) {
      if (token.tipo === 'numero') {
        salida.push(token);
        continue;
      }
      const actual = this.#operaciones.get(token.valor);
      while (pila.length && this.#operaciones.get(pila.at(-1).valor).precedencia >= actual.precedencia) {
        salida.push(pila.pop());
      }
      pila.push(token);
    }
    return [...salida, ...pila.reverse()];
  }

  // 3) Resuelve la postfija con una pila y registra cada paso
  resolver(postfija) {
    const pila = [];
    const pasos = [];
    for (const token of postfija) {
      if (token.tipo === 'numero') {
        pila.push(token.valor);
        continue;
      }
      const b = pila.pop();
      const a = pila.pop();
      const operacion = this.#operaciones.get(token.valor);
      const resultado = redondear(operacion.aplicar(a, b));
      if (!Number.isFinite(resultado)) throw new ErrorValidacion('El resultado está fuera de rango');
      pasos.push({ a, operador: operacion.simbolo, nombre: operacion.nombre, b, resultado });
      pila.push(resultado);
    }
    return { resultado: redondear(pila[0]), pasos };
  }

  calcular(expresion) {
    const tokens = this.tokenizar(expresion);
    const postfija = this.aPostfija(tokens);
    const { resultado, pasos } = this.resolver(postfija);
    return {
      expresion: tokens.map((t) => t.texto).join(' '),
      resultado,
      postfija: postfija.map((t) => t.texto),
      pasos,
      operadores: tokens.filter((t) => t.tipo === 'operador').map((t) => t.valor),
    };
  }
}
