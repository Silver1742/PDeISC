import { enviarJSON } from '../utils/http.js';

// Controladores de la API REST: todos los cálculos se resuelven en el servidor
export function registrarRutas(router, { calculadora, historial }) {
  router.get('/api/salud', ({ res }) => {
    enviarJSON(res, 200, {
      ok: true,
      data: {
        estado: 'en línea',
        node: process.version,
        uptime: Math.round(process.uptime()),
        fecha: new Date().toISOString(),
      },
    });
  });

  router.get('/api/operaciones', ({ res }) => {
    enviarJSON(res, 200, { ok: true, data: calculadora.operaciones });
  });

  // POST { expresion, guardar } → resultado, pasos y notación postfija
  router.post('/api/calcular', async ({ res, cuerpo }) => {
    const calculo = calculadora.calcular(cuerpo.expresion);
    if (cuerpo.guardar === false) {
      return enviarJSON(res, 200, { ok: true, data: calculo });
    }
    const guardado = await historial.agregar(calculo);
    enviarJSON(res, 201, {
      ok: true,
      mensaje: `${calculo.expresion} = ${calculo.resultado}`,
      data: { ...calculo, id: guardado.id, fecha: guardado.fecha },
    });
  });

  router.get('/api/historial', ({ res }) => {
    const calculos = historial.calculos;
    enviarJSON(res, 200, { ok: true, total: calculos.length, data: calculos });
  });

  router.delete('/api/historial/:id', async ({ res, params }) => {
    const calculo = await historial.eliminar(params.id);
    enviarJSON(res, 200, { ok: true, mensaje: `Se eliminó "${calculo.expresion}" del historial`, data: calculo });
  });

  router.delete('/api/historial', async ({ res }) => {
    const cantidad = await historial.limpiar();
    enviarJSON(res, 200, { ok: true, mensaje: `Historial vaciado (${cantidad} cálculos eliminados)`, data: { cantidad } });
  });

  router.get('/api/estadisticas', ({ res }) => {
    enviarJSON(res, 200, { ok: true, data: historial.estadisticas() });
  });

  return router;
}
