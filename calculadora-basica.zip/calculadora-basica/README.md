# Calculadora Básica

Calculadora web hecha con **Node.js puro** (sin Express ni dependencias) en el servidor
y **JavaScript puro + Bootstrap 5** en el cliente. Responsive y con modo **claro / oscuro**.

**Todas las cuentas se resuelven en el servidor**: el navegador envía la expresión y el servidor
responde con el resultado, la notación postfija y el paso a paso (o con un error, por ejemplo
"No se puede dividir por cero").

## Cómo ejecutarla

```bash
npm start
```

Abrir <http://localhost:3000>. No hace falta `npm install`: el proyecto no tiene dependencias.

- `npm run dev` → reinicia el servidor al guardar cambios (`node --watch`).
- `npm run reset` → borra el historial; al iniciar se regenera con cálculos de ejemplo.

## Funcionalidades

- Suma, resta, multiplicación y división **respetando la precedencia** (`2 + 3 × 4 = 14`).
- Decimales, porcentaje (`200 × 15% = 30`), cambio de signo, borrar último y borrar todo.
- Memoria: **MC, MR, M+, M−** (se guarda en el navegador).
- **Vista previa en vivo**: mientras escribís, el servidor calcula el resultado sin guardarlo.
- **Historial** guardado en el servidor: buscar, reutilizar un resultado, copiar y eliminar.
- **Paso a paso**: tokens, notación postfija y cada operación que hizo el servidor.
- **Estadísticas**: cantidad, suma, promedio, máximo, mínimo, uso de cada operación y gráfico.
- Teclado físico, modo claro/oscuro, indicador de estado y latencia del servidor.

Atajos: números, `+ - * /`, `.` o `,`, `%`, `F9` (±), `Enter` (=), `Retroceso`, `Esc` (C), `Ctrl+C` (copiar), `T` (tema), `?` (ayuda).

## Dónde se aplica cada tema del cuatrimestre

| Tema | Dónde |
|---|---|
| **Node.js** | `server/server.js`: servidor `http` nativo, archivos estáticos con `fs`, router propio (`server/utils/Router.js`) e historial persistido en JSON. |
| **Respuestas del servidor** | `server/routes/api.js`: API REST con respuestas `{ ok, data, mensaje, error }` y códigos 200/201/400/404/500. El servidor calcula, valida y devuelve los mensajes de error que se muestran en pantalla. |
| **Arrays** | `map`, `filter`, `reduce`, `find`, `flatMap`, `slice`, `splice`, `includes`, `at` en `Calculadora.js`, `Historial.js`, `vistas.js`. |
| **Vectores** | La expresión es un vector de tokens (`['12', '+', '3']`); la postfija y la pila del algoritmo; el vector de uso de operaciones y el de los últimos 12 resultados (gráfico). |
| **Clases + GET / SET** | `Operacion` (y sus subclases `Suma`, `Resta`, `Multiplicacion`, `Division`), `Calculadora`, `Calculo`, `Historial` en el servidor; `Calculadora`, `Memoria`, `Calculo`, `Tema`, `ErrorApi` en el cliente. Usan campos privados `#`, getters calculados y setters que validan. |
| **Vector de clases** | `OPERACIONES = [new Suma(), new Resta(), …]`; `Historial` guarda `Calculo[]`; el cliente convierte el JSON en `Calculo[]` con `data.map(Calculo.desdeJSON)`. |
| **Import / Export** | ES Modules en todo el proyecto (`"type": "module"` en el servidor, `<script type="module">` en el cliente). |
| **Fetch** | `public/js/services/apiFetch.js`: calcular, vista previa (cancelable con `AbortController`), estadísticas y estado del servidor. |
| **Axios** | `public/js/services/apiAxios.js`: instancia con `baseURL`, `timeout` e interceptor de errores; historial, eliminar, vaciar y operaciones. |
| **Eventos** | Cliente: `click` con delegación, `keydown`, `input`, `online`/`offline`, eventos de Bootstrap (`shown.bs.tab`) y **eventos personalizados** `cambio` emitidos por `Calculadora` y `Memoria` (`extends EventTarget`). Servidor: `Historial extends EventEmitter` emite `calculo`, `eliminado`, `limpiado`; streams con `req.on('data')` / `'end'` y `res.on('finish')`. |

## Cómo calcula el servidor (sin `eval`)

1. **Tokeniza** el texto: `"2 + 3 × 4"` → `[2, +, 3, ×, 4]`.
2. Lo pasa a **notación postfija** con el algoritmo *shunting-yard*: `[2, 3, 4, ×, +]`.
3. Lo **resuelve con una pila**: `3 × 4 = 12`, luego `2 + 12 = 14`.

Cada operación es una clase con su propio `aplicar(a, b)`; la división lanza un error si `b` es 0.

## API

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/salud` | Estado del servidor |
| GET | `/api/operaciones` | Operaciones disponibles |
| POST | `/api/calcular` | `{ expresion, guardar? }` → resultado, postfija y pasos |
| GET | `/api/historial` | Cálculos guardados |
| DELETE | `/api/historial/:id` | Eliminar un cálculo |
| DELETE | `/api/historial` | Vaciar el historial |
| GET | `/api/estadisticas` | Estadísticas del historial |

## Estructura

```
server/
  server.js              servidor HTTP + archivos estáticos
  config.js              puerto y rutas
  routes/api.js          controladores de la API
  models/                Operacion (+ subclases), Calculadora, Calculo, Historial
  utils/                 Router, helpers HTTP, errores
public/
  index.html             maquetado con Bootstrap
  css/styles.css         diseño propio + modo oscuro
  js/main.js             controlador y eventos
  js/config/teclado.js   teclado definido como vector de objetos
  js/models/             Calculadora, Memoria, Calculo
  js/services/           apiFetch (fetch), apiAxios (axios)
  js/ui/                 vistas, tema, notificaciones
  js/utils/              formato, debounce
```
