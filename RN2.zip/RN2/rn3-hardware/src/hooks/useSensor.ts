import { useEffect, useEffectEvent, useState } from 'react';

/** Lo que devuelve addListener: alcanza con poder desuscribirse. */
type EventSubscription = { remove: () => void };

/** Lo mínimo que comparten Accelerometer, Gyroscope, Magnetometer, Barometer y LightSensor. */
type SensorLike<T> = {
  isAvailableAsync: () => Promise<boolean>;
  setUpdateInterval: (intervalMs: number) => void;
  addListener: (listener: (event: T) => void) => EventSubscription;
};

export type SensorState<T> = {
  /** null mientras se consulta si el sensor existe. */
  available: boolean | null;
  data: T | null;
};

/**
 * Se suscribe a un sensor de expo-sensors mientras el componente está montado (y `enabled` es true).
 * Siempre se desuscribe al salir: dejar un sensor escuchando gasta batería aunque no se vea.
 * `onReading` corre con cada lectura (para acumular, detectar picos, etc.) sin re-suscribir el sensor.
 */
export function useSensor<T>(sensor: SensorLike<T>, intervalMs = 100, enabled = true, onReading?: (event: T) => void): SensorState<T> {
  const [available, setAvailable] = useState<boolean | null>(null);
  const [data, setData] = useState<T | null>(null);

  const handleReading = useEffectEvent((event: T) => {
    setData(event);
    onReading?.(event);
  });

  useEffect(() => {
    if (!enabled) return;
    let subscription: EventSubscription | undefined;
    let cancelled = false;

    sensor
      .isAvailableAsync()
      .catch(() => false)
      .then((isAvailable) => {
        if (cancelled) return;
        setAvailable(isAvailable);
        if (!isAvailable) return;
        sensor.setUpdateInterval(intervalMs);
        subscription = sensor.addListener(handleReading);
      });

    return () => {
      cancelled = true;
      subscription?.remove();
    };
  }, [sensor, intervalMs, enabled]);

  return { available, data };
}
