import { BatteryState } from 'expo-battery';

import type { BatteryInfo } from './useBattery';

/** En web los hooks de expo-battery fallan (no hay listeners nativos): devolvemos "desconocido". */
export function useBattery(): BatteryInfo {
  return { level: -1, state: BatteryState.UNKNOWN, lowPower: false };
}
