import * as Battery from 'expo-battery';

export type BatteryInfo = { level: number; state: Battery.BatteryState; lowPower: boolean };

/** Nivel (0 a 1, -1 si no se sabe), estado de carga y ahorro de energía. Se actualiza solo. */
export function useBattery(): BatteryInfo {
  return {
    level: Battery.useBatteryLevel(),
    state: Battery.useBatteryState(),
    lowPower: Battery.useLowPowerMode(),
  };
}
