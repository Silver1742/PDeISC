/**
 * Catálogo de herramientas de hardware que muestra la app.
 * Las pantallas solo renderizan esto: agregar una herramienta = una entrada acá + una demo en `src/demos`.
 */
import type { IconName } from '@/components/Icon';

export type Platform = 'android' | 'ios' | 'web';

export type CategoryId = 'vision' | 'ubicacion' | 'movimiento' | 'seguridad' | 'sistema';

export type Category = { id: CategoryId; title: string; icon: IconName };

export type ToolEntry = {
  id: string;
  title: string;
  category: CategoryId;
  icon: IconName;
  /** Paquete de Expo que lo implementa. */
  module: string;
  /** Una línea para la lista. */
  summary: string;
  /** Qué es y cómo funciona por dentro. */
  description: string;
  uses: string[];
  /** Permisos que pide en tiempo de ejecución (vacío = ninguno). */
  permissions: string[];
  platforms: Platform[];
  code: string;
  docs: string;
};

export const CATEGORIES: Category[] = [
  { id: 'vision', title: 'Cámara y visión', icon: { ios: 'camera.fill', android: 'photo_camera', web: 'photo_camera' } },
  { id: 'ubicacion', title: 'Ubicación', icon: { ios: 'location.fill', android: 'location_on', web: 'location_on' } },
  { id: 'movimiento', title: 'Sensores de movimiento', icon: { ios: 'gyroscope', android: 'screen_rotation', web: 'screen_rotation' } },
  { id: 'seguridad', title: 'Seguridad', icon: { ios: 'lock.shield.fill', android: 'security', web: 'security' } },
  { id: 'sistema', title: 'Sistema y dispositivo', icon: { ios: 'iphone', android: 'smartphone', web: 'smartphone' } },
];

const ALL: Platform[] = ['android', 'ios', 'web'];
const MOBILE: Platform[] = ['android', 'ios'];

export const TOOLS: ToolEntry[] = [
  // ───────── Cámara y visión ─────────
  {
    id: 'camara',
    title: 'Cámara',
    category: 'vision',
    icon: { ios: 'camera.fill', android: 'photo_camera', web: 'photo_camera' },
    module: 'expo-camera',
    summary: 'Vista previa en vivo, sacar fotos, cámara frontal/trasera y flash.',
    description:
      'CameraView muestra la imagen del sensor en tiempo real y expone takePictureAsync() para capturar. Se puede elegir la cámara (facing), el modo de flash y el zoom. Las fotos quedan en la caché de la app y se muestran con su URI local.',
    uses: ['Foto de perfil o de un documento', 'Registrar evidencia (reclamos, entregas)', 'Base para filtros o realidad aumentada'],
    permissions: ['CAMERA'],
    platforms: ALL,
    code: `const [permiso, pedirPermiso] = useCameraPermissions();
const ref = useRef<CameraView>(null);

const foto = await ref.current?.takePictureAsync({ quality: 0.7 });

<CameraView ref={ref} style={{ flex: 1 }} facing="back" flash="auto" />`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/camera/',
  },
  {
    id: 'escaner',
    title: 'Lector de códigos',
    category: 'vision',
    icon: { ios: 'qrcode.viewfinder', android: 'qr_code_scanner', web: 'qr_code_scanner' },
    module: 'expo-camera',
    summary: 'Lee QR, EAN-13, Code 128 y otros códigos de barras.',
    description:
      'La misma CameraView decodifica códigos si se le pasa onBarcodeScanned. Con barcodeScannerSettings se limitan los tipos a buscar (más rápido y sin falsos positivos). El evento trae el tipo, el contenido y la posición del código.',
    uses: ['Entradas y credenciales con QR', 'Inventario por código de barras', 'Abrir links o datos de Wi-Fi desde un QR'],
    permissions: ['CAMERA'],
    platforms: ALL,
    code: `<CameraView
  style={{ flex: 1 }}
  barcodeScannerSettings={{ barcodeTypes: ['qr', 'ean13', 'code128'] }}
  onBarcodeScanned={({ type, data }) => console.log(type, data)}
/>`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/camera/#barcodescanningresult',
  },
  {
    id: 'linterna',
    title: 'Linterna',
    category: 'vision',
    icon: { ios: 'flashlight.on.fill', android: 'flashlight_on', web: 'flashlight_on' },
    module: 'expo-camera',
    summary: 'Prende el LED del flash de forma continua.',
    description:
      'No hay un módulo "linterna" aparte: el LED del flash se controla con la prop enableTorch de CameraView, que necesita estar montada (acá con tamaño mínimo). Por eso pide permiso de cámara.',
    uses: ['Linterna dentro de la app', 'Iluminar al escanear códigos en lugares oscuros'],
    permissions: ['CAMERA'],
    platforms: MOBILE,
    code: `const [prendida, setPrendida] = useState(false);

<CameraView style={{ width: 1, height: 1 }} enableTorch={prendida} />`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/camera/#enabletorch',
  },

  // ───────── Ubicación ─────────
  {
    id: 'ubicacion',
    title: 'Ubicación y GPS',
    category: 'ubicacion',
    icon: { ios: 'location.fill', android: 'my_location', web: 'my_location' },
    module: 'expo-location',
    summary: 'Coordenadas, precisión, altitud, velocidad y dirección postal.',
    description:
      'getCurrentPositionAsync() pide una lectura puntual y watchPositionAsync() avisa cada vez que el dispositivo se mueve. El sistema combina GPS, Wi-Fi y antenas según la precisión pedida. reverseGeocodeAsync() traduce las coordenadas a una dirección.',
    uses: ['Delivery y seguimiento de recorridos', 'Check-in por cercanía (geofencing)', 'Completar la dirección automáticamente'],
    permissions: ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION'],
    platforms: ALL,
    code: `const { status } = await Location.requestForegroundPermissionsAsync();
if (status !== 'granted') return;

const sub = await Location.watchPositionAsync(
  { accuracy: Location.Accuracy.High, distanceInterval: 1 },
  (pos) => console.log(pos.coords.latitude, pos.coords.longitude),
);
// sub.remove() al salir`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/location/',
  },
  {
    id: 'brujula',
    title: 'Brújula',
    category: 'ubicacion',
    icon: { ios: 'location.north.circle.fill', android: 'explore', web: 'explore' },
    module: 'expo-sensors · Magnetometer',
    summary: 'Campo magnético en µT convertido a rumbo (N, NE, E…).',
    description:
      'El magnetómetro mide el campo magnético terrestre en los tres ejes. Con el teléfono plano, atan2(y, x) da el ángulo respecto del norte magnético. Si marca valores raros, movelo en forma de 8 para calibrarlo.',
    uses: ['Brújula y orientación en mapas', 'Detector de metales casero', 'Apps de astronomía o realidad aumentada'],
    permissions: [],
    platforms: MOBILE,
    code: `Magnetometer.setUpdateInterval(100);
const sub = Magnetometer.addListener(({ x, y }) => {
  const grados = (Math.atan2(y, x) * 180) / Math.PI;
  setRumbo((90 - grados + 360) % 360);
});`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/magnetometer/',
  },

  // ───────── Movimiento ─────────
  {
    id: 'acelerometro',
    title: 'Acelerómetro',
    category: 'movimiento',
    icon: { ios: 'move.3d', android: 'vibration', web: 'vibration' },
    module: 'expo-sensors · Accelerometer',
    summary: 'Aceleración en X, Y, Z (en g). Nivel de burbuja y detector de sacudidas.',
    description:
      'Mide la aceleración que siente el teléfono en cada eje, incluida la gravedad: quieto y boca arriba marca z ≈ 1 g. Sirve para saber la inclinación y para detectar golpes o sacudidas cuando la magnitud supera cierto umbral.',
    uses: ['Girar la pantalla según la orientación', 'Agitar para deshacer / refrescar', 'Juegos que se controlan inclinando el teléfono'],
    permissions: [],
    platforms: ALL,
    code: `Accelerometer.setUpdateInterval(100);
const sub = Accelerometer.addListener(({ x, y, z }) => {
  const fuerza = Math.sqrt(x * x + y * y + z * z);
  if (fuerza > 1.8) console.log('¡Sacudida!');
});
// sub.remove() al desmontar`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/accelerometer/',
  },
  {
    id: 'giroscopio',
    title: 'Giroscopio',
    category: 'movimiento',
    icon: { ios: 'gyroscope', android: '360', web: '360' },
    module: 'expo-sensors · Gyroscope',
    summary: 'Velocidad de rotación en cada eje (rad/s).',
    description:
      'El giroscopio no mide la inclinación sino qué tan rápido gira el teléfono alrededor de cada eje. Integrando esa velocidad en el tiempo se obtiene el ángulo girado, que es lo que hace esta demo.',
    uses: ['Fotos 360° y panorámicas', 'Estabilización de video', 'Controles de juego más precisos que el acelerómetro'],
    permissions: [],
    platforms: ALL,
    code: `Gyroscope.setUpdateInterval(50);
const sub = Gyroscope.addListener(({ x, y, z }) => {
  // rad/s → grados girados en este intervalo
  anguloZ.current += z * 0.05 * (180 / Math.PI);
});`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/gyroscope/',
  },
  {
    id: 'podometro',
    title: 'Podómetro',
    category: 'movimiento',
    icon: { ios: 'figure.walk', android: 'directions_walk', web: 'directions_walk' },
    module: 'expo-sensors · Pedometer',
    summary: 'Cuenta los pasos mientras la pantalla está abierta.',
    description:
      'Usa el contador de pasos por hardware del teléfono (bajo consumo). watchStepCount() avisa los pasos desde que se empezó a escuchar. En Android pide el permiso de "actividad física".',
    uses: ['Apps de salud y fitness', 'Gamificación (desafíos de pasos)', 'Detectar si el usuario camina'],
    permissions: ['ACTIVITY_RECOGNITION'],
    platforms: MOBILE,
    code: `await Pedometer.requestPermissionsAsync();
const sub = Pedometer.watchStepCount(({ steps }) => setPasos(steps));`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/pedometer/',
  },
  {
    id: 'barometro',
    title: 'Barómetro',
    category: 'movimiento',
    icon: { ios: 'barometer', android: 'compress', web: 'compress' },
    module: 'expo-sensors · Barometer',
    summary: 'Presión atmosférica (hPa) y altitud estimada.',
    description:
      'Mide la presión del aire. Como baja unos 0,12 hPa por metro, permite estimar la altura relativa (subir un piso se nota). No todos los teléfonos lo traen: la demo avisa si no está disponible.',
    uses: ['Saber en qué piso está el usuario', 'Complementar la altitud del GPS', 'Estaciones meteorológicas'],
    permissions: [],
    platforms: MOBILE,
    code: `const disponible = await Barometer.isAvailableAsync();
const sub = Barometer.addListener(({ pressure }) => setHpa(pressure));`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/barometer/',
  },
  {
    id: 'luz',
    title: 'Sensor de luz',
    category: 'movimiento',
    icon: { ios: 'sun.max.fill', android: 'light_mode', web: 'light_mode' },
    module: 'expo-sensors · LightSensor',
    summary: 'Luz ambiente en lux (solo Android).',
    description:
      'Es el sensor que usa el sistema para el brillo automático. Devuelve la iluminancia en lux: ~10 en una pieza oscura, ~300 en una oficina, miles al sol. iOS no lo expone a las apps.',
    uses: ['Pasar a modo oscuro automáticamente', 'Avisar que falta luz para escanear', 'Medidor de luz para fotografía'],
    permissions: [],
    platforms: ['android'],
    code: `const sub = LightSensor.addListener(({ illuminance }) => setLux(illuminance));`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/light-sensor/',
  },

  // ───────── Seguridad ─────────
  {
    id: 'biometria',
    title: 'Biometría',
    category: 'seguridad',
    icon: { ios: 'faceid', android: 'fingerprint', web: 'fingerprint' },
    module: 'expo-local-authentication',
    summary: 'Huella digital o reconocimiento facial del sistema.',
    description:
      'La app nunca ve la huella ni la cara: le pide al sistema operativo que autentique y solo recibe si salió bien o mal. Antes conviene verificar que haya hardware (hasHardwareAsync) y datos cargados (isEnrolledAsync).',
    uses: ['Desbloquear la app o una sección privada', 'Confirmar pagos y transferencias', 'Reemplazar la contraseña en el login'],
    permissions: ['USE_BIOMETRIC'],
    platforms: MOBILE,
    code: `const hayHardware = await LocalAuthentication.hasHardwareAsync();
const hayHuella = await LocalAuthentication.isEnrolledAsync();

const { success } = await LocalAuthentication.authenticateAsync({
  promptMessage: 'Confirmá que sos vos',
  cancelLabel: 'Cancelar',
});`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/local-authentication/',
  },

  // ───────── Sistema ─────────
  {
    id: 'haptica',
    title: 'Vibración y háptica',
    category: 'sistema',
    icon: { ios: 'iphone.radiowaves.left.and.right', android: 'vibration', web: 'vibration' },
    module: 'expo-haptics',
    summary: 'Golpes suaves, medios, fuertes y avisos de éxito/error.',
    description:
      'La háptica usa el motor de vibración para dar "sensación de toque": impactos cortos y patrones de notificación. Es más fina que Vibration del core, que solo prende el motor por un tiempo.',
    uses: ['Confirmar una acción (me gusta, enviar)', 'Avisar un error en un formulario', 'Dar textura a sliders y selectores'],
    permissions: [],
    platforms: MOBILE,
    code: `await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
await Haptics.selectionAsync();`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/haptics/',
  },
  {
    id: 'bateria',
    title: 'Batería',
    category: 'sistema',
    icon: { ios: 'battery.75percent', android: 'battery_5_bar', web: 'battery_5_bar' },
    module: 'expo-battery',
    summary: 'Nivel, si está cargando y modo ahorro de energía.',
    description:
      'Los hooks useBatteryLevel, useBatteryState y useLowPowerMode se actualizan solos cuando cambia algo (enchufar el cargador, bajar un punto de carga).',
    uses: ['Pausar tareas pesadas con batería baja', 'Avisar antes de una sincronización larga', 'Apps de monitoreo'],
    permissions: [],
    platforms: ALL,
    code: `const nivel = Battery.useBatteryLevel();      // 0 a 1
const estado = Battery.useBatteryState();      // CHARGING, FULL…
const ahorro = Battery.useLowPowerMode();`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/battery/',
  },
  {
    id: 'brillo',
    title: 'Brillo de pantalla',
    category: 'sistema',
    icon: { ios: 'sun.max', android: 'brightness_6', web: 'brightness_6' },
    module: 'expo-brightness',
    summary: 'Sube o baja el brillo mientras la app está abierta.',
    description:
      'setBrightnessAsync() cambia el brillo solo para la app (no toca la configuración del sistema, así que no necesita permisos especiales). Al salir se vuelve al brillo del sistema.',
    uses: ['Máximo brillo al mostrar un QR o una entrada', 'Modo lectura nocturna', 'Linterna de pantalla'],
    permissions: [],
    platforms: MOBILE,
    code: `await Brightness.setBrightnessAsync(1);       // 0 a 1
await Brightness.restoreSystemBrightnessAsync(); // Android`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/brightness/',
  },
  {
    id: 'dispositivo',
    title: 'Info del dispositivo',
    category: 'sistema',
    icon: { ios: 'info.circle.fill', android: 'perm_device_information', web: 'perm_device_information' },
    module: 'expo-device',
    summary: 'Marca, modelo, sistema operativo y memoria.',
    description:
      'expo-device lee datos fijos del equipo sin pedir permisos. Útil para diagnosticar errores o adaptar la app a equipos con poca memoria. isDevice indica si es un teléfono real o un emulador.',
    uses: ['Reportes de errores con el modelo exacto', 'Desactivar animaciones en equipos de gama baja', 'Estadísticas de uso'],
    permissions: [],
    platforms: ALL,
    code: `Device.brand;          // "samsung"
Device.modelName;      // "SM-A546E"
Device.osVersion;      // "15"
Device.totalMemory;    // bytes`,
    docs: 'https://docs.expo.dev/versions/latest/sdk/device/',
  },
];

export const PLATFORM_LABEL: Record<Platform, string> = { android: 'Android', ios: 'iOS', web: 'Web' };

export function getTool(id: string): ToolEntry | undefined {
  return TOOLS.find((tool) => tool.id === id);
}

export function getCategory(id: CategoryId): Category {
  return CATEGORIES.find((category) => category.id === id) ?? CATEGORIES[0];
}

/** Herramientas agrupadas por categoría, en el orden de CATEGORIES (formato de SectionList). */
export function groupByCategory(tools: ToolEntry[]) {
  return CATEGORIES.map((category) => ({
    category,
    data: tools.filter((tool) => tool.category === category.id),
  })).filter((section) => section.data.length > 0);
}

/** Anterior y siguiente en el orden del catálogo, para navegar entre fichas. */
export function getNeighbors(id: string) {
  const index = TOOLS.findIndex((tool) => tool.id === id);
  return { prev: TOOLS[index - 1], next: TOOLS[index + 1] };
}

const normalize = (text: string) => text.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function searchTools(query: string): ToolEntry[] {
  const q = normalize(query.trim());
  if (!q) return TOOLS;
  return TOOLS.filter((tool) => normalize(`${tool.title} ${tool.summary} ${tool.module}`).includes(q));
}
