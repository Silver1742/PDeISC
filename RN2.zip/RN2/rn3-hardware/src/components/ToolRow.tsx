import { useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Icon } from './Icon';
import { Badge } from './ui';

import { PLATFORM_LABEL, type ToolEntry } from '@/data/tools';
import { Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Badges de plataforma y permisos: solo se muestran si hay algo que avisar. */
export function ToolBadges({ tool }: { tool: ToolEntry }) {
  const everywhere = tool.platforms.length === 3;
  return (
    <View style={badgeStyles.row}>
      {everywhere ? (
        <Badge label="Android · iOS · Web" tone="success" />
      ) : (
        <Badge label={tool.platforms.map((p) => PLATFORM_LABEL[p]).join(' · ')} tone="primary" />
      )}
      {tool.permissions.length > 0 ? <Badge label="Pide permiso" tone="warning" /> : <Badge label="Sin permisos" />}
    </View>
  );
}

const badgeStyles = StyleSheet.create({
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs },
});

/** Fila de la lista principal: ícono, nombre, resumen y badges. Navega a la ficha. */
export function ToolRow({ tool }: { tool: ToolEntry }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const router = useRouter();

  return (
    <Pressable
      onPress={() => router.push({ pathname: '/herramienta/[id]', params: { id: tool.id } })}
      accessibilityRole="link"
      accessibilityHint={`Abre la demo de ${tool.title}`}
      style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.surfaceMuted }]}>
      <View style={styles.iconBox}>
        <Icon name={tool.icon} color={colors.primary} size={22} />
      </View>
      <View style={styles.body}>
        <Text style={styles.name}>{tool.title}</Text>
        <Text style={styles.summary} numberOfLines={2}>
          {tool.summary}
        </Text>
        <View style={styles.badges}>
          <ToolBadges tool={tool} />
        </View>
      </View>
      <Icon name={{ ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }} color={colors.textSubtle} size={18} />
    </Pressable>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.md,
      paddingHorizontal: Spacing.lg,
      paddingVertical: Spacing.md,
      backgroundColor: c.surface,
    },
    iconBox: {
      width: 44,
      height: 44,
      borderRadius: Radius.md,
      backgroundColor: c.primarySoft,
      alignItems: 'center',
      justifyContent: 'center',
    },
    body: { flex: 1, gap: 2 },
    name: { color: c.text, fontSize: 16, fontWeight: '700' },
    summary: { color: c.textMuted, fontSize: 13.5, lineHeight: 19 },
    badges: { marginTop: Spacing.xs },
  });
