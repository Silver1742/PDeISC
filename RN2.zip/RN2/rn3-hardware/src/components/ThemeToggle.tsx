import { Pressable, StyleSheet, Text } from 'react-native';

import { Icon, type IconName } from './Icon';

import { Radius, Spacing, useAppTheme, type ThemePreference } from '@/theme';

const META: Record<ThemePreference, { label: string; icon: IconName }> = {
  system: { label: 'Sistema', icon: { ios: 'circle.lefthalf.filled', android: 'contrast', web: 'contrast' } },
  light: { label: 'Claro', icon: { ios: 'sun.max.fill', android: 'light_mode', web: 'light_mode' } },
  dark: { label: 'Oscuro', icon: { ios: 'moon.fill', android: 'dark_mode', web: 'dark_mode' } },
};

type ThemeToggleProps = {
  /** Colores alternativos para usarlo sobre fondos oscuros/rojos (por ejemplo, un header). */
  tone?: 'default' | 'onColor';
};

/** Botón que rota el modo de color: sistema → claro → oscuro. */
export function ThemeToggle({ tone = 'default' }: ThemeToggleProps) {
  const { preference, cyclePreference, colors } = useAppTheme();
  const { label, icon } = META[preference];
  const foreground = tone === 'onColor' ? '#ffffff' : colors.text;

  return (
    <Pressable
      onPress={cyclePreference}
      accessibilityRole="button"
      accessibilityLabel={`Modo de color: ${label}. Tocá para cambiar.`}
      hitSlop={8}
      style={({ pressed }) => [
        styles.button,
        {
          borderColor: tone === 'onColor' ? 'rgba(255,255,255,0.35)' : colors.border,
          backgroundColor: tone === 'onColor' ? 'rgba(255,255,255,0.12)' : colors.surface,
        },
        pressed && styles.pressed,
      ]}>
      <Icon name={icon} color={foreground} size={16} />
      <Text style={[styles.label, { color: foreground }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs + 2,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs + 2,
    borderRadius: Radius.pill,
    borderWidth: StyleSheet.hairlineWidth * 2,
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
  },
  pressed: {
    opacity: 0.7,
    transform: [{ scale: 0.97 }],
  },
});
