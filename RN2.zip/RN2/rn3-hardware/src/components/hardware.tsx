/**
 * Piezas visuales que comparten las demos de hardware:
 * lecturas en grilla, barras por eje, pedido de permiso y aviso de "no disponible".
 */
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { Icon, type IconName } from './Icon';
import { AppButton, Notice } from './ui';

import { Fonts, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

// ─────────────── Lecturas (valor + etiqueta) ───────────────

export type Reading = { label: string; value: string; unit?: string };

export function Readings({ items }: { items: Reading[] }) {
  const styles = useThemedStyles(createStyles);

  return (
    <View style={styles.readings}>
      {items.map((item) => (
        <View key={item.label} style={styles.reading}>
          <Text style={styles.readingLabel}>{item.label}</Text>
          <Text style={styles.readingValue} numberOfLines={1} adjustsFontSizeToFit>
            {item.value}
            {item.unit && <Text style={styles.readingUnit}> {item.unit}</Text>}
          </Text>
        </View>
      ))}
    </View>
  );
}

// ─────────────── Barras X / Y / Z ───────────────

type AxisBarsProps = {
  values: { x: number; y: number; z: number };
  /** Valor que llena media barra (de 0 al borde). */
  range: number;
  unit: string;
  decimals?: number;
};

/** Barra centrada en 0 por eje: crece a la derecha si es positivo y a la izquierda si es negativo. */
export function AxisBars({ values, range, unit, decimals = 2 }: AxisBarsProps) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const axes = [
    { key: 'X', value: values.x, color: colors.primary },
    { key: 'Y', value: values.y, color: colors.text },
    { key: 'Z', value: values.z, color: colors.textMuted },
  ];

  return (
    <View style={styles.axes}>
      {axes.map((axis) => {
        const ratio = Math.max(-1, Math.min(1, axis.value / range));
        return (
          <View key={axis.key} style={styles.axisRow}>
            <Text style={styles.axisKey}>{axis.key}</Text>
            <View style={styles.axisTrack}>
              <View style={styles.axisCenter} />
              <View
                style={[
                  styles.axisFill,
                  { backgroundColor: axis.color, width: `${Math.abs(ratio) * 50}%` },
                  ratio >= 0 ? { left: '50%' } : { right: '50%' },
                ]}
              />
            </View>
            <Text style={styles.axisValue}>
              {axis.value >= 0 ? ' ' : ''}
              {axis.value.toFixed(decimals)} {unit}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

// ─────────────── Permisos y disponibilidad ───────────────

type PermissionRequestProps = {
  icon: IconName;
  title: string;
  message: string;
  /** Si el usuario ya lo rechazó y el sistema no deja volver a preguntar. */
  blocked?: boolean;
  onRequest: () => void;
};

export function PermissionRequest({ icon, title, message, blocked = false, onRequest }: PermissionRequestProps) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <View style={styles.permission}>
      <View style={styles.permissionIcon}>
        <Icon name={icon} color={colors.primary} size={30} />
      </View>
      <Text style={styles.permissionTitle}>{title}</Text>
      <Text style={styles.permissionText}>
        {blocked ? 'El permiso fue rechazado. Habilitalo desde Ajustes → Apps → Hardware RN → Permisos.' : message}
      </Text>
      <AppButton label={blocked ? 'Abrir ajustes' : 'Dar permiso'} onPress={onRequest} />
    </View>
  );
}

export function Loading({ label = 'Consultando el sensor…' }: { label?: string }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <View style={styles.loading}>
      <ActivityIndicator color={colors.primary} />
      <Text style={styles.permissionText}>{label}</Text>
    </View>
  );
}

export function Unavailable({ what }: { what: string }) {
  return (
    <Notice>
      {what} no está disponible en este dispositivo. Algunos teléfonos no traen el sensor, y en la web o el emulador
      casi ninguno funciona: probalo en un celular real (APK o Expo Go).
    </Notice>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    readings: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    reading: {
      flexGrow: 1,
      flexBasis: '45%',
      backgroundColor: c.surfaceMuted,
      borderRadius: Radius.md,
      padding: Spacing.md,
      gap: Spacing.xxs,
    },
    readingLabel: { color: c.textMuted, fontSize: 12, fontWeight: '600' },
    readingValue: { color: c.text, fontSize: 20, fontWeight: '800', fontVariant: ['tabular-nums'] },
    readingUnit: { color: c.textMuted, fontSize: 13, fontWeight: '600' },

    axes: { gap: Spacing.sm },
    axisRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
    axisKey: { width: 16, color: c.text, fontWeight: '800', fontFamily: Fonts.mono },
    axisTrack: {
      flex: 1,
      height: 14,
      borderRadius: Radius.pill,
      backgroundColor: c.surfaceMuted,
      overflow: 'hidden',
    },
    axisCenter: { position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, backgroundColor: c.border },
    axisFill: { position: 'absolute', top: 0, bottom: 0, borderRadius: Radius.pill },
    axisValue: { width: 96, textAlign: 'right', color: c.textMuted, fontFamily: Fonts.mono, fontSize: 12 },

    permission: { alignItems: 'center', gap: Spacing.md, paddingVertical: Spacing.lg },
    permissionIcon: {
      width: 64,
      height: 64,
      borderRadius: Radius.pill,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: c.primarySoft,
    },
    permissionTitle: { color: c.text, fontSize: 17, fontWeight: '700', textAlign: 'center' },
    permissionText: { color: c.textMuted, fontSize: 14, lineHeight: 20, textAlign: 'center' },
    loading: { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xl },
  });
