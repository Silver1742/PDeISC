import { useId } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, LinearGradient, Path, Stop, Text as SvgText } from 'react-native-svg';

import { useAppTheme } from '@/theme';

type BrandLogoProps = {
  size?: number;
  withName?: boolean;
};

/** Isologo de BurgosCorp: monograma "BC" sobre escudo negro con borde rojo (mismo SVG que la versión web). */
export function BrandLogo({ size = 40, withName = false }: BrandLogoProps) {
  const { colors } = useAppTheme();
  const gradientId = `bc-shield-${useId().replace(/:/g, '')}`;

  return (
    <View style={styles.row} accessibilityRole="image" accessibilityLabel="BurgosCorp">
      <Svg width={size} height={size} viewBox="0 0 48 48">
        <Defs>
          <LinearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor="#2e2e33" />
            <Stop offset="1" stopColor="#050505" />
          </LinearGradient>
        </Defs>
        <Path d="M24 2 43 9v14c0 11.5-8 19.8-19 23C13 42.8 5 34.5 5 23V9Z" fill={`url(#${gradientId})`} />
        <Path
          d="M24 5.5 40 11.4V23c0 9.7-6.6 16.8-16 19.8C14.6 39.8 8 32.7 8 23V11.4Z"
          fill="none"
          stroke="#e11d2e"
          strokeWidth={1.75}
        />
        <SvgText x="24" y="30" textAnchor="middle" fontFamily="Georgia" fontSize="17" fontWeight="700" fill="#ffffff">
          BC
        </SvgText>
      </Svg>
      {withName && (
        <Text style={[styles.name, { color: colors.text, fontSize: size * 0.45 }]}>
          Burgos<Text style={{ color: colors.primary }}>Corp</Text>
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  name: {
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});
