/**
 * Primitivas de UI de la app (tarjeta, badge, chip, botón, bloque de código).
 * Todas leen el tema activo, así que funcionan en modo claro y oscuro.
 */
import type { PropsWithChildren, ReactNode } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';

import { Icon, type IconName } from './Icon';

import { Fonts, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

// ─────────────── Card ───────────────

type CardProps = PropsWithChildren<{ title?: string; icon?: IconName; style?: StyleProp<ViewStyle>; right?: ReactNode }>;

export function Card({ title, icon, right, style, children }: CardProps) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <View style={[styles.card, style]}>
      {title && (
        <View style={styles.cardHeader}>
          {icon && <Icon name={icon} color={colors.primary} size={18} />}
          <Text style={styles.cardTitle} accessibilityRole="header">
            {title}
          </Text>
          {right && <View style={styles.cardRight}>{right}</View>}
        </View>
      )}
      {children}
    </View>
  );
}

// ─────────────── Badge ───────────────

type BadgeTone = 'neutral' | 'primary' | 'warning' | 'success';

export function Badge({ label, tone = 'neutral' }: { label: string; tone?: BadgeTone }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const palette: Record<BadgeTone, { bg: string; fg: string }> = {
    neutral: { bg: colors.surfaceMuted, fg: colors.textMuted },
    primary: { bg: colors.primarySoft, fg: colors.primaryText },
    warning: { bg: 'rgba(245, 158, 11, 0.15)', fg: colors.warning },
    success: { bg: 'rgba(34, 197, 94, 0.15)', fg: colors.success },
  };

  return (
    <View style={[styles.badge, { backgroundColor: palette[tone].bg }]}>
      <Text style={[styles.badgeText, { color: palette[tone].fg }]}>{label}</Text>
    </View>
  );
}

// ─────────────── Chip (filtro seleccionable) ───────────────

type ChipProps = { label: string; selected: boolean; onPress: () => void };

export function Chip({ label, selected, onPress }: ChipProps) {
  const styles = useThemedStyles(createStyles);

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      style={({ pressed }) => [styles.chip, selected && styles.chipSelected, pressed && styles.pressed]}>
      <Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text>
    </Pressable>
  );
}

// ─────────────── Botón ───────────────

type ButtonProps = {
  label: string;
  onPress: () => void;
  variant?: 'solid' | 'outline';
  icon?: IconName;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
};

export function AppButton({ label, onPress, variant = 'solid', icon, disabled = false, style }: ButtonProps) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const foreground = variant === 'solid' ? colors.onPrimary : colors.primary;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      style={({ pressed }) => [
        styles.button,
        variant === 'solid'
          ? { backgroundColor: pressed ? colors.primaryPressed : colors.primary }
          : [styles.buttonOutline, pressed && { backgroundColor: colors.primarySoft }],
        pressed && styles.pressed,
        disabled && styles.disabled,
        style,
      ]}>
      {icon && <Icon name={icon} color={foreground} size={16} />}
      <Text style={[styles.buttonText, { color: foreground }]}>{label}</Text>
    </Pressable>
  );
}

// ─────────────── Bloque de código ───────────────

export function CodeBlock({ code }: { code: string }) {
  const styles = useThemedStyles(createStyles);

  return (
    <ScrollView horizontal style={styles.code} contentContainerStyle={styles.codeContent} showsHorizontalScrollIndicator={false}>
      <Text style={styles.codeText} selectable>
        {code}
      </Text>
    </ScrollView>
  );
}

// ─────────────── Aviso ───────────────

export function Notice({ children, tone = 'warning' }: PropsWithChildren<{ tone?: 'warning' | 'info' }>) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const accent = tone === 'warning' ? colors.warning : colors.primary;

  return (
    <View style={[styles.notice, { borderLeftColor: accent }]}>
      <Icon name={{ ios: 'info.circle.fill', android: 'info', web: 'info' }} color={accent} size={18} />
      <Text style={styles.noticeText}>{children}</Text>
    </View>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    card: {
      backgroundColor: c.surface,
      borderRadius: Radius.lg,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: c.border,
      padding: Spacing.lg,
      gap: Spacing.md,
    },
    cardHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
    cardTitle: { color: c.text, fontSize: 16, fontWeight: '700' },
    cardRight: { marginLeft: 'auto' },

    badge: { paddingHorizontal: Spacing.sm, paddingVertical: 3, borderRadius: Radius.pill },
    badgeText: { fontSize: 11, fontWeight: '700', letterSpacing: 0.3 },

    chip: {
      paddingHorizontal: Spacing.md,
      paddingVertical: Spacing.xs + 2,
      borderRadius: Radius.pill,
      borderWidth: 1,
      borderColor: c.border,
      backgroundColor: c.surface,
    },
    chipSelected: { backgroundColor: c.primary, borderColor: c.primary },
    chipText: { color: c.textMuted, fontSize: 13, fontWeight: '600' },
    chipTextSelected: { color: c.onPrimary },

    button: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: Spacing.sm,
      paddingHorizontal: Spacing.lg,
      paddingVertical: Spacing.md - 2,
      borderRadius: Radius.md,
    },
    buttonOutline: { borderWidth: 1.5, borderColor: c.primary },
    buttonText: { fontSize: 15, fontWeight: '700' },
    pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
    disabled: { opacity: 0.4 },

    code: { backgroundColor: '#111111', borderRadius: Radius.md },
    codeContent: { padding: Spacing.md },
    codeText: { color: '#e4e4e7', fontFamily: Fonts.mono, fontSize: 12.5, lineHeight: 19 },

    notice: {
      flexDirection: 'row',
      gap: Spacing.sm,
      alignItems: 'flex-start',
      backgroundColor: c.surfaceMuted,
      borderRadius: Radius.md,
      borderLeftWidth: 4,
      padding: Spacing.md,
    },
    noticeText: { flex: 1, color: c.text, fontSize: 14, lineHeight: 20 },
  });
