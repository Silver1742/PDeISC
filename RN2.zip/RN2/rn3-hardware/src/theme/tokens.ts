/**
 * BurgosCorp · tokens de diseño para React Native.
 * Misma identidad que los proyectos web (rojo corporativo + negro + escala de grises),
 * traducida a valores que entiende StyleSheet (no hay CSS variables en nativo).
 */
import { Platform } from 'react-native';

const palette = {
  red: '#c8102e',
  redHover: '#a50d26',
  redBright: '#ef3b4f',
  redBrightHover: '#f45d6e',
  black: '#111111',
  white: '#ffffff',
  gray900: '#18181b',
  gray800: '#26262b',
  gray700: '#3f3f46',
  gray600: '#52525b',
  gray500: '#71717a',
  gray400: '#a1a1aa',
  gray200: '#e4e4e7',
  gray100: '#f4f4f5',
  gray50: '#fafafa',
} as const;

export type ColorScheme = 'light' | 'dark';

export type ThemeColors = {
  primary: string;
  primaryPressed: string;
  primarySoft: string;
  primaryText: string;
  onPrimary: string;
  background: string;
  surface: string;
  surfaceMuted: string;
  border: string;
  text: string;
  textMuted: string;
  textSubtle: string;
  inverse: string;
  onInverse: string;
  success: string;
  warning: string;
};

export const Colors: Record<ColorScheme, ThemeColors> = {
  light: {
    primary: palette.red,
    primaryPressed: palette.redHover,
    primarySoft: '#fde8eb',
    primaryText: '#8f0b21',
    onPrimary: palette.white,
    background: palette.gray100,
    surface: palette.white,
    surfaceMuted: palette.gray50,
    border: palette.gray200,
    text: palette.gray900,
    textMuted: palette.gray600,
    textSubtle: palette.gray400,
    inverse: palette.black,
    onInverse: palette.white,
    success: '#15803d',
    warning: '#b45309',
  },
  dark: {
    primary: palette.redBright,
    primaryPressed: palette.redBrightHover,
    primarySoft: 'rgba(239, 59, 79, 0.14)',
    primaryText: '#ff8a97',
    onPrimary: palette.white,
    background: '#0b0b0c',
    surface: '#17171a',
    surfaceMuted: '#1f1f23',
    border: '#2a2a30',
    text: palette.gray200,
    textMuted: palette.gray400,
    textSubtle: palette.gray500,
    inverse: palette.white,
    onInverse: palette.black,
    success: '#4ade80',
    warning: '#fbbf24',
  },
};

/** Escala de espaciado en múltiplos de 4 (igual criterio que Bootstrap). */
export const Spacing = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
} as const;

export const Radius = {
  sm: 6,
  md: 10,
  lg: 16,
  xl: 24,
  pill: 999,
} as const;

export const Fonts = {
  sans: Platform.select({ ios: 'System', android: 'sans-serif', default: 'system-ui, Segoe UI, sans-serif' }),
  serif: Platform.select({ ios: 'Georgia', android: 'serif', default: "Georgia, 'Times New Roman', serif" }),
  mono: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'ui-monospace, Consolas, monospace' }),
} as const;

/** Ancho máximo del contenido: en tablet/web no queremos líneas de 1500px. */
export const MaxContentWidth = 720;
