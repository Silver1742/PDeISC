/** Demos de seguridad y sistema: biometría, háptica, batería, brillo e info del dispositivo. */
import * as Battery from 'expo-battery';
import * as Brightness from 'expo-brightness';
import * as Device from 'expo-device';
import * as Haptics from 'expo-haptics';
import * as LocalAuthentication from 'expo-local-authentication';
import { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';

import { Loading, Readings } from '@/components/hardware';
import { Icon } from '@/components/Icon';
import { AppButton, Badge, Notice } from '@/components/ui';
import { useBattery } from '@/hooks/useBattery';
import { Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

const isWeb = Platform.OS === 'web';

// ─────────────── Biometría ───────────────

type BiometricInfo = {
  hasHardware: boolean;
  isEnrolled: boolean;
  types: LocalAuthentication.AuthenticationType[];
  level: LocalAuthentication.SecurityLevel;
};

const TYPE_LABEL: Record<LocalAuthentication.AuthenticationType, string> = {
  [LocalAuthentication.AuthenticationType.FINGERPRINT]: 'Huella',
  [LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION]: 'Rostro',
  [LocalAuthentication.AuthenticationType.IRIS]: 'Iris',
};

const LEVEL_LABEL: Record<LocalAuthentication.SecurityLevel, string> = {
  [LocalAuthentication.SecurityLevel.NONE]: 'Ninguno',
  [LocalAuthentication.SecurityLevel.SECRET]: 'PIN / patrón',
  [LocalAuthentication.SecurityLevel.BIOMETRIC_WEAK]: 'Biometría débil',
  [LocalAuthentication.SecurityLevel.BIOMETRIC_STRONG]: 'Biometría fuerte',
};

type AuthResult = { ok: boolean; message: string; at: Date };

export function BiometricsDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [info, setInfo] = useState<BiometricInfo | null>(null);
  const [result, setResult] = useState<AuthResult | null>(null);
  const [allowPin, setAllowPin] = useState(true);

  useEffect(() => {
    if (isWeb) return;
    Promise.all([
      LocalAuthentication.hasHardwareAsync(),
      LocalAuthentication.isEnrolledAsync(),
      LocalAuthentication.supportedAuthenticationTypesAsync(),
      LocalAuthentication.getEnrolledLevelAsync(),
    ]).then(([hasHardware, isEnrolled, types, level]) => setInfo({ hasHardware, isEnrolled, types, level }));
  }, []);

  if (isWeb) return <Notice>La biometría solo existe en Android e iOS. Probala con la APK.</Notice>;
  if (!info) return <Loading label="Consultando el hardware biométrico…" />;

  async function authenticate() {
    const response = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Confirmá que sos vos',
      cancelLabel: 'Cancelar',
      fallbackLabel: 'Usar PIN',
      disableDeviceFallback: !allowPin,
    });
    const ok = response.success;
    Haptics.notificationAsync(ok ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Error).catch(() => {});
    setResult({ ok, message: ok ? 'Identidad confirmada' : `No autorizado (${response.error})`, at: new Date() });
  }

  const ready = info.hasHardware && info.isEnrolled;
  const lockColor = result ? (result.ok ? colors.success : colors.primary) : colors.textMuted;

  return (
    <View style={styles.stack}>
      <Readings
        items={[
          { label: 'Hardware', value: info.hasHardware ? 'Sí' : 'No' },
          { label: 'Datos cargados', value: info.isEnrolled ? 'Sí' : 'No' },
          { label: 'Tipos', value: info.types.map((t) => TYPE_LABEL[t]).join(' · ') || '—' },
          { label: 'Nivel', value: LEVEL_LABEL[info.level] },
        ]}
      />

      {!ready && (
        <Notice>
          {info.hasHardware
            ? 'El teléfono tiene lector pero no hay huellas ni rostro registrados. Cargalos en Ajustes → Seguridad.'
            : 'Este dispositivo no tiene lector biométrico. Igual podés probar con el PIN o patrón.'}
        </Notice>
      )}

      <View style={styles.vault}>
        <Icon
          name={
            result?.ok
              ? { ios: 'lock.open.fill', android: 'lock_open', web: 'lock_open' }
              : { ios: 'lock.fill', android: 'lock', web: 'lock' }
          }
          color={lockColor}
          size={56}
        />
        <Text style={[styles.vaultText, { color: lockColor }]}>{result ? result.message : 'Zona privada bloqueada'}</Text>
        {result?.ok && <Text style={styles.secret}>🔐 Saldo secreto: $ 1.234.567</Text>}
      </View>

      <Pressable onPress={() => setAllowPin((v) => !v)} accessibilityRole="switch" accessibilityState={{ checked: allowPin }} style={styles.toggleRow}>
        <View style={[styles.checkbox, allowPin && { backgroundColor: colors.primary, borderColor: colors.primary }]}>
          {allowPin && <Icon name={{ ios: 'checkmark', android: 'check', web: 'check' }} color={colors.onPrimary} size={14} />}
        </View>
        <Text style={styles.toggleText}>Permitir PIN / patrón si falla la biometría</Text>
      </Pressable>

      <View style={styles.row}>
        <AppButton
          label="Desbloquear"
          icon={{ ios: 'faceid', android: 'fingerprint', web: 'fingerprint' }}
          onPress={authenticate}
          style={styles.flex}
        />
        {result?.ok && <AppButton variant="outline" label="Bloquear" onPress={() => setResult(null)} style={styles.flex} />}
      </View>
    </View>
  );
}

// ─────────────── Háptica ───────────────

type HapticOption = { label: string; run: () => Promise<void> };

const HAPTIC_GROUPS: { title: string; options: HapticOption[] }[] = [
  {
    title: 'Impacto',
    options: [
      { label: 'Suave', run: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light) },
      { label: 'Medio', run: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium) },
      { label: 'Fuerte', run: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy) },
      { label: 'Rígido', run: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid) },
    ],
  },
  {
    title: 'Notificación',
    options: [
      { label: 'Éxito', run: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success) },
      { label: 'Advertencia', run: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning) },
      { label: 'Error', run: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error) },
    ],
  },
  {
    title: 'Selección',
    options: [{ label: 'Tic de selección', run: () => Haptics.selectionAsync() }],
  },
];

export function HapticsDemo() {
  const styles = useThemedStyles(createStyles);
  const [last, setLast] = useState<string | null>(null);

  return (
    <View style={styles.stack}>
      {isWeb && <Notice>En la web la háptica no hace nada: probalo en el celular (y con el modo silencio desactivado en iPhone).</Notice>}
      {HAPTIC_GROUPS.map((group) => (
        <View key={group.title} style={styles.stack}>
          <Text style={styles.subTitle}>{group.title}</Text>
          <View style={styles.grid}>
            {group.options.map((option) => (
              <AppButton
                key={option.label}
                variant={last === option.label ? 'solid' : 'outline'}
                label={option.label}
                onPress={() => {
                  setLast(option.label);
                  option.run().catch(() => {});
                }}
                style={styles.gridItem}
              />
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

// ─────────────── Batería ───────────────

const STATE_LABEL: Record<Battery.BatteryState, string> = {
  [Battery.BatteryState.UNKNOWN]: 'Desconocido',
  [Battery.BatteryState.UNPLUGGED]: 'Desenchufado',
  [Battery.BatteryState.CHARGING]: 'Cargando ⚡',
  [Battery.BatteryState.FULL]: 'Completa',
  [Battery.BatteryState.NOT_CHARGING]: 'Enchufado, sin cargar',
};

export function BatteryDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const { level, state, lowPower } = useBattery();

  if (level < 0) return <Notice>Este navegador o emulador no informa la batería. Probalo en un celular.</Notice>;

  const percent = Math.round(level * 100);
  const fill = percent <= 20 ? colors.primary : percent <= 50 ? colors.warning : colors.success;

  return (
    <View style={[styles.stack, styles.center]}>
      <View style={styles.battery}>
        <View style={[styles.batteryFill, { width: `${percent}%`, backgroundColor: fill }]} />
        <Text style={styles.batteryText}>{percent}%</Text>
      </View>
      <View style={styles.row}>
        <Badge label={STATE_LABEL[state]} tone={state === Battery.BatteryState.CHARGING ? 'success' : 'neutral'} />
        {lowPower && <Badge label="Ahorro de energía" tone="warning" />}
      </View>
      <Text style={styles.caption}>Enchufá o desenchufá el cargador: el estado cambia solo, sin recargar la pantalla.</Text>
    </View>
  );
}

// ─────────────── Brillo ───────────────

const BRIGHTNESS_STEPS = [0.1, 0.25, 0.5, 0.75, 1];

export function BrightnessDemo() {
  const styles = useThemedStyles(createStyles);
  const [current, setCurrent] = useState<number | null>(null);

  useEffect(() => {
    if (isWeb) return;
    Brightness.getBrightnessAsync().then(setCurrent);
    // Al salir de la demo devolvemos el control al brillo del sistema.
    return () => {
      if (Platform.OS === 'android') Brightness.restoreSystemBrightnessAsync().catch(() => {});
    };
  }, []);

  if (isWeb) return <Notice>La web no puede cambiar el brillo de la pantalla.</Notice>;
  if (current === null) return <Loading label="Leyendo el brillo…" />;

  async function apply(value: number) {
    await Brightness.setBrightnessAsync(value);
    setCurrent(value);
    Haptics.selectionAsync().catch(() => {});
  }

  return (
    <View style={styles.stack}>
      <View style={styles.center}>
        <Text style={styles.bigNumber}>{Math.round(current * 100)}%</Text>
        <Text style={styles.caption}>brillo de la app</Text>
      </View>
      <View style={styles.grid}>
        {BRIGHTNESS_STEPS.map((step) => (
          <AppButton
            key={step}
            variant={Math.abs(current - step) < 0.01 ? 'solid' : 'outline'}
            label={`${step * 100}%`}
            onPress={() => apply(step)}
            style={styles.gridItem}
          />
        ))}
      </View>
      {Platform.OS === 'android' && (
        <AppButton
          variant="outline"
          label="Volver al brillo del sistema"
          onPress={() => Brightness.restoreSystemBrightnessAsync().then(() => Brightness.getBrightnessAsync()).then(setCurrent)}
        />
      )}
    </View>
  );
}

// ─────────────── Dispositivo ───────────────

const DEVICE_TYPE: Record<Device.DeviceType, string> = {
  [Device.DeviceType.UNKNOWN]: 'Desconocido',
  [Device.DeviceType.PHONE]: 'Teléfono',
  [Device.DeviceType.TABLET]: 'Tablet',
  [Device.DeviceType.DESKTOP]: 'Escritorio',
  [Device.DeviceType.TV]: 'TV',
};

export function DeviceDemo() {
  const styles = useThemedStyles(createStyles);
  const [type, setType] = useState<Device.DeviceType | null>(null);

  useEffect(() => {
    Device.getDeviceTypeAsync().then(setType, () => setType(Device.DeviceType.UNKNOWN));
  }, []);

  const memory = Device.totalMemory ? `${(Device.totalMemory / 1024 ** 3).toFixed(1)}` : '—';

  return (
    <View style={styles.stack}>
      <Readings
        items={[
          { label: 'Marca', value: Device.brand ?? '—' },
          { label: 'Modelo', value: Device.modelName ?? '—' },
          { label: 'Sistema', value: `${Device.osName ?? Platform.OS} ${Device.osVersion ?? ''}`.trim() },
          { label: 'Tipo', value: type === null ? '…' : DEVICE_TYPE[type] },
          { label: 'Memoria RAM', value: memory, unit: 'GB' },
          { label: '¿Equipo real?', value: Device.isDevice ? 'Sí' : 'Emulador' },
          { label: 'Fabricante', value: Device.manufacturer ?? '—' },
          { label: 'Año', value: Device.deviceYearClass ? String(Device.deviceYearClass) : '—' },
        ]}
      />
    </View>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    stack: { gap: Spacing.md },
    center: { alignItems: 'center', gap: Spacing.sm },
    row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    flex: { flex: 1 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    gridItem: { flexGrow: 1, flexBasis: '30%' },
    subTitle: { color: c.text, fontWeight: '700' },
    caption: { color: c.textMuted, fontSize: 13, lineHeight: 19, textAlign: 'center' },
    bigNumber: { color: c.primary, fontSize: 56, fontWeight: '800', fontVariant: ['tabular-nums'] },

    vault: {
      alignItems: 'center',
      gap: Spacing.sm,
      padding: Spacing.xl,
      borderRadius: Radius.lg,
      backgroundColor: c.surfaceMuted,
    },
    vaultText: { fontSize: 16, fontWeight: '700', textAlign: 'center' },
    secret: { color: c.text, fontSize: 16, fontWeight: '800' },
    toggleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
    checkbox: {
      width: 22,
      height: 22,
      borderRadius: Radius.sm,
      borderWidth: 2,
      borderColor: c.border,
      alignItems: 'center',
      justifyContent: 'center',
    },
    toggleText: { color: c.text, fontSize: 14, flex: 1 },

    battery: {
      width: 220,
      height: 90,
      borderRadius: Radius.lg,
      borderWidth: 3,
      borderColor: c.text,
      overflow: 'hidden',
      justifyContent: 'center',
      marginVertical: Spacing.md,
    },
    batteryFill: { position: 'absolute', left: 0, top: 0, bottom: 0 },
    batteryText: { color: c.text, fontSize: 32, fontWeight: '800', textAlign: 'center' },
  });
