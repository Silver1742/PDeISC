/** Demos que usan la cámara: fotos, lector de códigos y linterna (las tres con expo-camera). */
import * as Clipboard from 'expo-clipboard';
import { CameraView, useCameraPermissions, type BarcodeScanningResult, type CameraType, type FlashMode } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import { Image } from 'expo-image';
import { useRef, useState, type ReactNode } from 'react';
import { Alert, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Loading, PermissionRequest, Readings } from '@/components/hardware';
import { Icon, type IconName } from '@/components/Icon';
import { AppButton, Badge, Notice } from '@/components/ui';
import { Fonts, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

const CAMERA_ICON: IconName = { ios: 'camera.fill', android: 'photo_camera', web: 'photo_camera' };

/**
 * Pide el permiso de cámara y solo renderiza a los hijos cuando está concedido.
 * Si el usuario lo rechazó "para siempre", el botón lleva a los ajustes del sistema.
 */
function CameraGate({ message, children }: { message: string; children: ReactNode }) {
  const [permission, requestPermission] = useCameraPermissions();

  if (!permission) return <Loading label="Consultando permiso de cámara…" />;
  if (!permission.granted) {
    const blocked = !permission.canAskAgain;
    return (
      <PermissionRequest
        icon={CAMERA_ICON}
        title="Necesitamos la cámara"
        message={message}
        blocked={blocked}
        onRequest={() => (blocked ? Linking.openSettings() : requestPermission())}
      />
    );
  }
  return <>{children}</>;
}

// ─────────────── Cámara ───────────────

const FLASH_NEXT: Record<FlashMode, FlashMode> = { off: 'on', on: 'auto', auto: 'off', screen: 'off' };
const FLASH_ICON: Record<FlashMode, IconName> = {
  off: { ios: 'bolt.slash.fill', android: 'flash_off', web: 'flash_off' },
  on: { ios: 'bolt.fill', android: 'flash_on', web: 'flash_on' },
  auto: { ios: 'bolt.badge.automatic.fill', android: 'flash_auto', web: 'flash_auto' },
  screen: { ios: 'bolt.fill', android: 'flash_on', web: 'flash_on' },
};

type Photo = { uri: string; width: number; height: number };

export function CameraDemo() {
  return (
    <CameraGate message="Para mostrar la vista previa y sacar fotos, la app necesita acceso a la cámara.">
      <CameraPreview />
    </CameraGate>
  );
}

function CameraPreview() {
  const styles = useThemedStyles(createStyles);
  const cameraRef = useRef<CameraView>(null);
  const [facing, setFacing] = useState<CameraType>('back');
  const [flash, setFlash] = useState<FlashMode>('off');
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [selected, setSelected] = useState<Photo | null>(null);

  async function takePhoto() {
    if (!cameraRef.current || busy) return;
    setBusy(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.7 });
      if (photo) {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
        const saved = { uri: photo.uri, width: photo.width, height: photo.height };
        setPhotos((current) => [saved, ...current].slice(0, 12));
        setSelected(saved);
      }
    } catch (error) {
      Alert.alert('No se pudo sacar la foto', String(error));
    } finally {
      setBusy(false);
    }
  }

  return (
    <View style={styles.stack}>
      <View style={styles.viewfinder}>
        <CameraView
          ref={cameraRef}
          style={StyleSheet.absoluteFill}
          facing={facing}
          flash={flash}
          onCameraReady={() => setReady(true)}
        />
        <View style={styles.overlayTop}>
          <Badge label={facing === 'back' ? 'Trasera' : 'Frontal'} tone="primary" />
          <Badge label={`Flash: ${flash}`} />
        </View>
      </View>

      <View style={styles.controls}>
        <RoundButton
          icon={FLASH_ICON[flash]}
          label="Cambiar flash"
          onPress={() => setFlash((current) => FLASH_NEXT[current])}
        />
        <Pressable
          onPress={takePhoto}
          disabled={!ready || busy}
          accessibilityRole="button"
          accessibilityLabel="Sacar foto"
          style={({ pressed }) => [styles.shutter, (pressed || busy) && styles.shutterPressed, !ready && styles.disabled]}>
          <View style={styles.shutterInner} />
        </Pressable>
        <RoundButton
          icon={{ ios: 'arrow.triangle.2.circlepath.camera.fill', android: 'cameraswitch', web: 'cameraswitch' }}
          label="Cambiar de cámara"
          onPress={() => setFacing((current) => (current === 'back' ? 'front' : 'back'))}
        />
      </View>

      {selected && (
        <View style={styles.stack}>
          <Image source={{ uri: selected.uri }} style={[styles.preview, { aspectRatio: selected.width / selected.height }]} contentFit="cover" />
          <Text style={styles.caption}>
            {selected.width} × {selected.height} px · guardada en la caché de la app
          </Text>
        </View>
      )}

      {photos.length > 1 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.thumbs}>
          {photos.map((photo) => (
            <Pressable key={photo.uri} onPress={() => setSelected(photo)} accessibilityLabel="Ver foto">
              <Image
                source={{ uri: photo.uri }}
                style={[styles.thumb, selected?.uri === photo.uri && styles.thumbSelected]}
                contentFit="cover"
              />
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

function RoundButton({ icon, label, onPress }: { icon: IconName; label: string; onPress: () => void }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [styles.round, pressed && styles.pressed]}>
      <Icon name={icon} color={colors.text} size={22} />
    </Pressable>
  );
}

// ─────────────── Lector de códigos ───────────────

type Scan = { type: string; data: string; at: Date };

const BARCODE_TYPES = ['qr', 'ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39', 'pdf417', 'aztec', 'datamatrix'] as const;

export function ScannerDemo() {
  return (
    <CameraGate message="El lector usa la cámara para encontrar y decodificar códigos QR y de barras.">
      <Scanner />
    </CameraGate>
  );
}

function Scanner() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [scan, setScan] = useState<Scan | null>(null);
  const [history, setHistory] = useState<Scan[]>([]);
  const [torch, setTorch] = useState(false);
  // El evento llega muchas veces por segundo: el ref corta en seco antes de que se re-renderice.
  const locked = useRef(false);

  function handleScan({ type, data }: BarcodeScanningResult) {
    if (locked.current) return;
    locked.current = true;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    const result = { type, data, at: new Date() };
    setScan(result);
    setHistory((current) => [result, ...current].slice(0, 5));
  }

  function scanAgain() {
    setScan(null);
    locked.current = false;
  }

  const isUrl = scan ? /^https?:\/\//i.test(scan.data) : false;

  return (
    <View style={styles.stack}>
      <View style={styles.viewfinder}>
        <CameraView
          style={StyleSheet.absoluteFill}
          facing="back"
          enableTorch={torch}
          barcodeScannerSettings={{ barcodeTypes: [...BARCODE_TYPES] }}
          onBarcodeScanned={scan ? undefined : handleScan}
        />
        <View style={styles.scanFrameWrap} pointerEvents="none">
          <View style={[styles.scanFrame, { borderColor: scan ? colors.success : '#ffffff' }]} />
          <Text style={styles.scanHint}>{scan ? '¡Leído!' : 'Apuntá a un código QR o de barras'}</Text>
        </View>
      </View>

      {Platform.OS !== 'web' && (
        <AppButton
          variant="outline"
          label={torch ? 'Apagar linterna' : 'Prender linterna'}
          icon={{ ios: 'flashlight.on.fill', android: 'flashlight_on', web: 'flashlight_on' }}
          onPress={() => setTorch((on) => !on)}
        />
      )}

      {scan && (
        <View style={styles.result}>
          <View style={styles.resultHeader}>
            <Badge label={scan.type.toUpperCase()} tone="success" />
            <Text style={styles.caption}>{scan.at.toLocaleTimeString()}</Text>
          </View>
          <Text style={styles.resultData} selectable>
            {scan.data}
          </Text>
          <View style={styles.row}>
            <AppButton label="Escanear otro" onPress={scanAgain} style={styles.flex} />
            <AppButton
              variant="outline"
              label="Copiar"
              onPress={() => Clipboard.setStringAsync(scan.data).then(() => Alert.alert('Copiado al portapapeles'))}
              style={styles.flex}
            />
          </View>
          {isUrl && (
            <AppButton
              variant="outline"
              label="Abrir link"
              icon={{ ios: 'safari', android: 'open_in_new', web: 'open_in_new' }}
              onPress={() => Linking.openURL(scan.data)}
            />
          )}
        </View>
      )}

      {history.length > 1 && (
        <View style={styles.stack}>
          <Text style={styles.subTitle}>Últimas lecturas</Text>
          {history.slice(1).map((item) => (
            <Text key={item.at.toISOString()} style={styles.historyItem} numberOfLines={1}>
              {item.type} · {item.data}
            </Text>
          ))}
        </View>
      )}
    </View>
  );
}

// ─────────────── Linterna ───────────────

export function FlashlightDemo() {
  if (Platform.OS === 'web') {
    return <Notice>La web no puede controlar el LED del flash. Probalo en el celular.</Notice>;
  }
  return (
    <CameraGate message="El LED del flash depende de la cámara, así que Android/iOS piden ese permiso.">
      <Flashlight />
    </CameraGate>
  );
}

function Flashlight() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [on, setOn] = useState(false);
  const [ready, setReady] = useState(false);

  function toggle() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setOn((current) => !current);
  }

  return (
    <View style={[styles.stack, styles.center]}>
      {/* La cámara tiene que estar montada para manejar el LED, pero no hace falta verla. */}
      <CameraView style={styles.hiddenCamera} facing="back" enableTorch={on} onCameraReady={() => setReady(true)} />
      <Pressable
        onPress={toggle}
        disabled={!ready}
        accessibilityRole="switch"
        accessibilityState={{ checked: on }}
        accessibilityLabel="Linterna"
        style={({ pressed }) => [
          styles.torch,
          { backgroundColor: on ? colors.primary : colors.surfaceMuted, borderColor: on ? colors.primary : colors.border },
          pressed && styles.pressed,
        ]}>
        <Icon
          name={on ? { ios: 'flashlight.on.fill', android: 'flashlight_on', web: 'flashlight_on' } : { ios: 'flashlight.off.fill', android: 'flashlight_off', web: 'flashlight_off' }}
          color={on ? colors.onPrimary : colors.textMuted}
          size={64}
        />
      </Pressable>
      <Readings items={[{ label: 'Estado', value: !ready ? 'Preparando…' : on ? 'Prendida' : 'Apagada' }]} />
    </View>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    stack: { gap: Spacing.md },
    center: { alignItems: 'center' },
    row: { flexDirection: 'row', gap: Spacing.sm },
    flex: { flex: 1 },
    viewfinder: { aspectRatio: 3 / 4, borderRadius: Radius.lg, overflow: 'hidden', backgroundColor: '#000000' },
    overlayTop: { position: 'absolute', top: Spacing.md, left: Spacing.md, right: Spacing.md, flexDirection: 'row', gap: Spacing.sm },

    controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly' },
    round: {
      width: 52,
      height: 52,
      borderRadius: Radius.pill,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: c.surfaceMuted,
      borderWidth: 1,
      borderColor: c.border,
    },
    shutter: {
      width: 76,
      height: 76,
      borderRadius: Radius.pill,
      borderWidth: 4,
      borderColor: c.primary,
      alignItems: 'center',
      justifyContent: 'center',
    },
    shutterInner: { width: 58, height: 58, borderRadius: Radius.pill, backgroundColor: c.primary },
    shutterPressed: { transform: [{ scale: 0.92 }] },
    pressed: { opacity: 0.75 },
    disabled: { opacity: 0.4 },

    preview: { width: '100%', borderRadius: Radius.lg, backgroundColor: c.surfaceMuted },
    caption: { color: c.textMuted, fontSize: 12 },
    thumbs: { gap: Spacing.sm },
    thumb: { width: 64, height: 64, borderRadius: Radius.md, borderWidth: 2, borderColor: 'transparent' },
    thumbSelected: { borderColor: c.primary },

    scanFrameWrap: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
    scanFrame: { width: '65%', aspectRatio: 1, borderWidth: 3, borderRadius: Radius.lg },
    scanHint: {
      color: '#ffffff',
      fontWeight: '700',
      backgroundColor: 'rgba(0,0,0,0.55)',
      paddingHorizontal: Spacing.md,
      paddingVertical: Spacing.xs,
      borderRadius: Radius.pill,
      overflow: 'hidden',
    },
    result: { gap: Spacing.md, padding: Spacing.md, borderRadius: Radius.md, backgroundColor: c.surfaceMuted },
    resultHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    resultData: { color: c.text, fontFamily: Fonts.mono, fontSize: 15 },
    subTitle: { color: c.text, fontWeight: '700' },
    historyItem: { color: c.textMuted, fontFamily: Fonts.mono, fontSize: 12.5 },

    hiddenCamera: { width: 1, height: 1, opacity: 0, position: 'absolute' },
    torch: {
      width: 160,
      height: 160,
      borderRadius: Radius.pill,
      borderWidth: 2,
      alignItems: 'center',
      justifyContent: 'center',
      marginVertical: Spacing.lg,
    },
  });
