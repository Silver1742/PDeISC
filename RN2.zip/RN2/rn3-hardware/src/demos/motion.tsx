/** Demos de expo-sensors: acelerómetro, giroscopio, podómetro, barómetro y sensor de luz. */
import * as Haptics from 'expo-haptics';
import { Accelerometer, Barometer, Gyroscope, LightSensor, Pedometer } from 'expo-sensors';
import { useEffect, useRef, useState } from 'react';
import { Linking, StyleSheet, Text, View } from 'react-native';

import { AxisBars, Loading, PermissionRequest, Readings, Unavailable } from '@/components/hardware';
import { AppButton, Badge } from '@/components/ui';
import { useSensor } from '@/hooks/useSensor';
import { Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

const toDeg = (rad: number) => (rad * 180) / Math.PI;

// ─────────────── Acelerómetro ───────────────

const SHAKE_THRESHOLD = 1.8; // en g: caminar ronda 1.2, una sacudida pasa los 2.

export function AccelerometerDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [shakes, setShakes] = useState(0);
  const [peak, setPeak] = useState(1);
  const lastShake = useRef(0);

  const { available, data } = useSensor(Accelerometer, 60, true, (reading) => {
    const magnitude = Math.sqrt(reading.x ** 2 + reading.y ** 2 + reading.z ** 2);
    setPeak((current) => Math.max(current, magnitude));
    const now = Date.now();
    if (magnitude > SHAKE_THRESHOLD && now - lastShake.current > 800) {
      lastShake.current = now;
      setShakes((n) => n + 1);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
    }
  });

  const x = data?.x ?? 0;
  const y = data?.y ?? 0;
  const z = data?.z ?? 0;
  const force = Math.sqrt(x * x + y * y + z * z);

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El acelerómetro" />;

  // Nivel de burbuja: la burbuja se va hacia el lado más alto (opuesto a la gravedad).
  const pitch = toDeg(Math.atan2(-y, z));
  const roll = toDeg(Math.atan2(x, z));
  const bubbleX = Math.max(-1, Math.min(1, -x)) * (LEVEL / 2 - BUBBLE / 2);
  const bubbleY = Math.max(-1, Math.min(1, y)) * (LEVEL / 2 - BUBBLE / 2);
  const level = Math.abs(x) < 0.03 && Math.abs(y) < 0.03;

  return (
    <View style={styles.stack}>
      <AxisBars values={{ x, y, z }} range={1.5} unit="g" />

      <View style={styles.center}>
        <View style={[styles.level, level && { borderColor: colors.success }]}>
          <View style={styles.crossH} />
          <View style={styles.crossV} />
          <View style={styles.levelTarget} />
          <View
            style={[
              styles.bubble,
              { backgroundColor: level ? colors.success : colors.primary, transform: [{ translateX: bubbleX }, { translateY: bubbleY }] },
            ]}
          />
        </View>
        {level && <Badge label="¡A NIVEL!" tone="success" />}
      </View>

      <Readings
        items={[
          { label: 'Inclinación adelante/atrás', value: pitch.toFixed(0), unit: '°' },
          { label: 'Inclinación lateral', value: roll.toFixed(0), unit: '°' },
          { label: 'Fuerza total', value: force.toFixed(2), unit: 'g' },
          { label: 'Pico', value: peak.toFixed(2), unit: 'g' },
        ]}
      />

      <View style={[styles.shake, shakes > 0 && { borderColor: colors.primary }]}>
        <Text style={styles.shakeCount}>{shakes}</Text>
        <Text style={styles.caption}>sacudidas detectadas (agitá el teléfono, vibra en cada una)</Text>
      </View>
      <AppButton
        variant="outline"
        label="Reiniciar"
        onPress={() => {
          setShakes(0);
          setPeak(1);
        }}
      />
    </View>
  );
}

// ─────────────── Giroscopio ───────────────

const GYRO_INTERVAL = 50;

export function GyroscopeDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [rotation, setRotation] = useState({ x: 0, y: 0, z: 0 });

  // Integramos velocidad × tiempo para saber cuántos grados se giró en cada eje desde que se abrió.
  const { available, data } = useSensor(Gyroscope, GYRO_INTERVAL, true, (speed) => {
    const dt = GYRO_INTERVAL / 1000;
    setRotation((r) => ({ x: r.x + toDeg(speed.x) * dt, y: r.y + toDeg(speed.y) * dt, z: r.z + toDeg(speed.z) * dt }));
  });

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El giroscopio" />;

  const speed = data ?? { x: 0, y: 0, z: 0 };

  return (
    <View style={styles.stack}>
      <Text style={styles.subTitle}>Velocidad de giro</Text>
      <AxisBars values={speed} range={5} unit="rad/s" />

      <View style={styles.center}>
        <View style={[styles.gyroCube, { transform: [{ rotate: `${-rotation.z}deg` }] }]}>
          <View style={[styles.gyroArrow, { borderBottomColor: colors.primary }]} />
          <Text style={styles.gyroLabel}>Z</Text>
        </View>
      </View>

      <Readings
        items={[
          { label: 'Girado en X', value: rotation.x.toFixed(0), unit: '°' },
          { label: 'Girado en Y', value: rotation.y.toFixed(0), unit: '°' },
          { label: 'Girado en Z', value: rotation.z.toFixed(0), unit: '°' },
        ]}
      />
      <Text style={styles.caption}>
        Girá el teléfono sobre la mesa: el cuadrado acompaña el giro en Z. Con el tiempo se “corre” un poco (deriva): por
        eso en la práctica se combina con el acelerómetro y el magnetómetro.
      </Text>
      <AppButton variant="outline" label="Poner en cero" onPress={() => setRotation({ x: 0, y: 0, z: 0 })} />
    </View>
  );
}

// ─────────────── Podómetro ───────────────

const DAILY_GOAL = 100;

export function PedometerDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [available, setAvailable] = useState<boolean | null>(null);
  const [permission, setPermission] = useState<Pedometer.PermissionResponse | null>(null);
  const [steps, setSteps] = useState(0);

  useEffect(() => {
    Pedometer.isAvailableAsync()
      .catch(() => false)
      .then(setAvailable);
    Pedometer.getPermissionsAsync().then(setPermission, () => {});
  }, []);

  const requestPermission = () => Pedometer.requestPermissionsAsync().then(setPermission);

  useEffect(() => {
    if (!available || !permission?.granted) return;
    const subscription = Pedometer.watchStepCount((result) => setSteps(result.steps));
    return () => subscription.remove();
  }, [available, permission?.granted]);

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El contador de pasos" />;
  if (!permission) return <Loading label="Consultando permiso…" />;
  if (!permission.granted) {
    const blocked = !permission.canAskAgain;
    return (
      <PermissionRequest
        icon={{ ios: 'figure.walk', android: 'directions_walk', web: 'directions_walk' }}
        title="Permiso de actividad física"
        message="Android pide este permiso para leer el contador de pasos del teléfono."
        blocked={blocked}
        onRequest={() => (blocked ? Linking.openSettings() : requestPermission())}
      />
    );
  }

  const progress = Math.min(1, steps / DAILY_GOAL);

  return (
    <View style={[styles.stack, styles.center]}>
      <Text style={styles.bigNumber}>{steps}</Text>
      <Text style={styles.caption}>pasos desde que abriste esta pantalla</Text>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${progress * 100}%`, backgroundColor: progress === 1 ? colors.success : colors.primary }]} />
      </View>
      <Text style={styles.caption}>
        Meta de la demo: {DAILY_GOAL} pasos {progress === 1 ? '✅' : ''}
      </Text>
      <Readings
        items={[
          { label: 'Distancia aprox.', value: ((steps * 0.75) / 1000).toFixed(2), unit: 'km' },
          { label: 'Calorías aprox.', value: (steps * 0.04).toFixed(1), unit: 'kcal' },
        ]}
      />
      <Text style={styles.caption}>Caminá con el teléfono en la mano o el bolsillo. El sensor agrupa pasos, así que puede actualizar de a varios.</Text>
    </View>
  );
}

// ─────────────── Barómetro ───────────────

const SEA_LEVEL_HPA = 1013.25;

export function BarometerDemo() {
  const styles = useThemedStyles(createStyles);
  const { available, data } = useSensor(Barometer, 500);
  const [reference, setReference] = useState<number | null>(null);

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El barómetro" />;

  const pressure = data?.pressure ?? 0;
  // Fórmula barométrica internacional: altitud aproximada respecto del nivel del mar.
  const altitude = pressure ? 44330 * (1 - Math.pow(pressure / SEA_LEVEL_HPA, 1 / 5.255)) : 0;
  const relative = reference !== null && pressure ? 44330 * (1 - Math.pow(pressure / reference, 1 / 5.255)) : null;

  return (
    <View style={styles.stack}>
      <View style={styles.center}>
        <Text style={styles.bigNumber}>{pressure.toFixed(1)}</Text>
        <Text style={styles.caption}>hPa</Text>
      </View>
      <Readings
        items={[
          { label: 'Altitud estimada', value: altitude.toFixed(0), unit: 'm' },
          { label: 'Diferencia de altura', value: relative === null ? '—' : relative.toFixed(1), unit: 'm' },
        ]}
      />
      <AppButton label="Marcar altura actual como 0" onPress={() => setReference(pressure)} disabled={!pressure} />
      <Text style={styles.caption}>
        Marcá el cero, subí o bajá un piso por la escalera y mirá la diferencia (≈ 3 m por piso). La altitud absoluta
        depende del clima del día; la diferencia es mucho más confiable.
      </Text>
    </View>
  );
}

// ─────────────── Sensor de luz ───────────────

function describeLux(lux: number) {
  if (lux < 10) return 'Oscuridad';
  if (lux < 100) return 'Luz tenue';
  if (lux < 1000) return 'Interior iluminado';
  if (lux < 10000) return 'Día nublado';
  return 'Pleno sol';
}

export function LightDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const { available, data } = useSensor(LightSensor, 250);

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El sensor de luz (solo Android)" />;

  const lux = data?.illuminance ?? 0;
  // Escala logarítmica: de 1 a 100.000 lux en una barra.
  const ratio = Math.min(1, Math.log10(Math.max(1, lux)) / 5);

  return (
    <View style={[styles.stack, styles.center]}>
      <Text style={styles.bigNumber}>{lux.toFixed(0)}</Text>
      <Text style={styles.caption}>lux · {describeLux(lux)}</Text>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${ratio * 100}%`, backgroundColor: colors.warning }]} />
      </View>
      <Text style={styles.caption}>Tapá con el dedo la parte de arriba del teléfono (al lado de la cámara frontal) o apuntalo a una lámpara.</Text>
    </View>
  );
}

const LEVEL = 200;
const BUBBLE = 36;

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    stack: { gap: Spacing.md },
    center: { alignItems: 'center', gap: Spacing.sm },
    subTitle: { color: c.text, fontWeight: '700' },
    caption: { color: c.textMuted, fontSize: 13, lineHeight: 19, textAlign: 'center' },
    bigNumber: { color: c.primary, fontSize: 56, fontWeight: '800', fontVariant: ['tabular-nums'] },

    level: {
      width: LEVEL,
      height: LEVEL,
      borderRadius: LEVEL / 2,
      borderWidth: 3,
      borderColor: c.border,
      backgroundColor: c.surfaceMuted,
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
    },
    crossH: { position: 'absolute', width: '100%', height: 1, backgroundColor: c.border },
    crossV: { position: 'absolute', height: '100%', width: 1, backgroundColor: c.border },
    levelTarget: {
      position: 'absolute',
      width: BUBBLE + 10,
      height: BUBBLE + 10,
      borderRadius: Radius.pill,
      borderWidth: 2,
      borderColor: c.textSubtle,
    },
    bubble: { width: BUBBLE, height: BUBBLE, borderRadius: BUBBLE / 2, opacity: 0.9 },

    shake: {
      alignItems: 'center',
      padding: Spacing.md,
      borderRadius: Radius.md,
      borderWidth: 2,
      borderColor: c.border,
      gap: Spacing.xs,
    },
    shakeCount: { color: c.text, fontSize: 36, fontWeight: '800' },

    gyroCube: {
      width: 140,
      height: 140,
      borderRadius: Radius.lg,
      backgroundColor: c.surfaceMuted,
      borderWidth: 2,
      borderColor: c.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginVertical: Spacing.md,
    },
    gyroArrow: {
      width: 0,
      height: 0,
      borderLeftWidth: 18,
      borderRightWidth: 18,
      borderBottomWidth: 50,
      borderLeftColor: 'transparent',
      borderRightColor: 'transparent',
    },
    gyroLabel: { color: c.textMuted, fontWeight: '800', marginTop: Spacing.xs },

    progressTrack: { width: '100%', height: 14, borderRadius: Radius.pill, backgroundColor: c.surfaceMuted, overflow: 'hidden' },
    progressFill: { height: '100%', borderRadius: Radius.pill },
  });
