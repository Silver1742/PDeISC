import type { ComponentType } from 'react';

import { CompassDemo, LocationDemo } from './location';
import { AccelerometerDemo, BarometerDemo, GyroscopeDemo, LightDemo, PedometerDemo } from './motion';
import { BatteryDemo, BiometricsDemo, BrightnessDemo, DeviceDemo, HapticsDemo } from './system';
import { CameraDemo, FlashlightDemo, ScannerDemo } from './vision';

/** Registro id de herramienta → demo en vivo. */
export const DEMOS: Record<string, ComponentType> = {
  camara: CameraDemo,
  escaner: ScannerDemo,
  linterna: FlashlightDemo,
  ubicacion: LocationDemo,
  brujula: CompassDemo,
  acelerometro: AccelerometerDemo,
  giroscopio: GyroscopeDemo,
  podometro: PedometerDemo,
  barometro: BarometerDemo,
  luz: LightDemo,
  biometria: BiometricsDemo,
  haptica: HapticsDemo,
  bateria: BatteryDemo,
  brillo: BrightnessDemo,
  dispositivo: DeviceDemo,
};
