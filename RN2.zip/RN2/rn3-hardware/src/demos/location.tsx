/** Demos de ubicación: GPS con expo-location y brújula con el magnetómetro. */
import * as Clipboard from 'expo-clipboard';
import * as Location from 'expo-location';
import { Magnetometer } from 'expo-sensors';
import { useEffect, useRef, useState } from 'react';
import { Alert, Linking, Platform, StyleSheet, Text, View } from 'react-native';

import { Loading, PermissionRequest, Readings, Unavailable } from '@/components/hardware';
import { AppButton, Badge } from '@/components/ui';
import { useSensor } from '@/hooks/useSensor';
import { Fonts, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

// ─────────────── Ubicación y GPS ───────────────

/** Distancia en metros entre dos coordenadas (fórmula de haversine). */
function distanceMeters(a: Location.LocationObjectCoords, b: Location.LocationObjectCoords) {
  const R = 6371e3;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

const fmt = (value: number | null | undefined, decimals: number) =>
  value === null || value === undefined || Number.isNaN(value) ? '—' : value.toFixed(decimals);

export function LocationDemo() {
  const styles = useThemedStyles(createStyles);
  const [permission, requestPermission] = Location.useForegroundPermissions();
  const [position, setPosition] = useState<Location.LocationObject | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [watching, setWatching] = useState(false);
  const [distance, setDistance] = useState(0);
  const [updates, setUpdates] = useState(0);
  const lastCoords = useRef<Location.LocationObjectCoords | null>(null);

  // Seguimiento en vivo: se suscribe mientras `watching` es true y se limpia solo.
  useEffect(() => {
    if (!watching) return;
    let subscription: Location.LocationSubscription | undefined;
    let cancelled = false;

    Location.watchPositionAsync({ accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 1, timeInterval: 1000 }, (next) => {
      setPosition(next);
      setUpdates((n) => n + 1);
      // Ignoramos saltos menores a la precisión: si no, el ruido del GPS suma metros estando quieto.
      if (lastCoords.current) {
        const step = distanceMeters(lastCoords.current, next.coords);
        if (step > Math.max(3, next.coords.accuracy ?? 0)) {
          setDistance((d) => d + step);
          lastCoords.current = next.coords;
        }
      } else {
        lastCoords.current = next.coords;
      }
    }).then((sub) => {
      if (cancelled) sub.remove();
      else subscription = sub;
    });

    return () => {
      cancelled = true;
      subscription?.remove();
    };
  }, [watching]);

  async function locateOnce() {
    setLoading(true);
    try {
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setPosition(current);
      lookupAddress(current.coords);
    } catch (error) {
      Alert.alert('No se pudo obtener la ubicación', '¿Está activado el GPS del teléfono?\n\n' + String(error));
    } finally {
      setLoading(false);
    }
  }

  async function lookupAddress(coords: Location.LocationObjectCoords) {
    try {
      const [place] = await Location.reverseGeocodeAsync(coords);
      setAddress(
        place
          ? [place.street && `${place.street} ${place.streetNumber ?? ''}`.trim(), place.city ?? place.subregion, place.region, place.country]
              .filter(Boolean)
              .join(', ')
          : null,
      );
    } catch {
      setAddress(null); // En web no hay geocodificación inversa: no es un error para el usuario.
    }
  }

  function toggleWatch() {
    if (!watching) {
      setDistance(0);
      setUpdates(0);
      lastCoords.current = null;
    }
    setWatching((w) => !w);
  }

  if (!permission) return <Loading label="Consultando permiso de ubicación…" />;
  if (!permission.granted) {
    const blocked = !permission.canAskAgain;
    return (
      <PermissionRequest
        icon={{ ios: 'location.fill', android: 'location_on', web: 'location_on' }}
        title="Necesitamos tu ubicación"
        message="Solo se usa mientras esta pantalla está abierta, para mostrar tus coordenadas."
        blocked={blocked}
        onRequest={() => (blocked ? Linking.openSettings() : requestPermission())}
      />
    );
  }

  const coords = position?.coords;
  const mapsUrl = coords
    ? Platform.select({
        android: `geo:${coords.latitude},${coords.longitude}?q=${coords.latitude},${coords.longitude}`,
        ios: `maps://?ll=${coords.latitude},${coords.longitude}`,
        default: `https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`,
      })
    : null;

  return (
    <View style={styles.stack}>
      <View style={styles.row}>
        <AppButton label={loading ? 'Buscando…' : 'Mi ubicación'} onPress={locateOnce} disabled={loading} style={styles.flex} />
        <AppButton
          variant={watching ? 'solid' : 'outline'}
          label={watching ? 'Detener' : 'Seguir en vivo'}
          onPress={toggleWatch}
          style={styles.flex}
        />
      </View>

      {watching && (
        <View style={styles.row}>
          <Badge label="● EN VIVO" tone="primary" />
          <Badge label={`${updates} lecturas`} />
          <Badge label={`${distance.toFixed(0)} m recorridos`} tone="success" />
        </View>
      )}

      {coords ? (
        <>
          <Text style={styles.coords} selectable>
            {coords.latitude.toFixed(6)}, {coords.longitude.toFixed(6)}
          </Text>
          <Readings
            items={[
              { label: 'Precisión', value: `± ${fmt(coords.accuracy, 0)}`, unit: 'm' },
              { label: 'Altitud', value: fmt(coords.altitude, 0), unit: 'm' },
              { label: 'Velocidad', value: fmt(coords.speed !== null && coords.speed >= 0 ? coords.speed * 3.6 : null, 1), unit: 'km/h' },
              { label: 'Rumbo', value: fmt(coords.heading !== null && coords.heading >= 0 ? coords.heading : null, 0), unit: '°' },
            ]}
          />
          {address && <Text style={styles.address}>📍 {address}</Text>}
          <Text style={styles.caption}>Última lectura: {new Date(position.timestamp).toLocaleTimeString()}</Text>
          <View style={styles.row}>
            <AppButton
              variant="outline"
              label="Ver en el mapa"
              onPress={() => mapsUrl && Linking.openURL(mapsUrl)}
              style={styles.flex}
            />
            <AppButton
              variant="outline"
              label="Copiar"
              onPress={() => Clipboard.setStringAsync(`${coords.latitude}, ${coords.longitude}`)}
              style={styles.flex}
            />
          </View>
        </>
      ) : (
        <Text style={styles.caption}>
          Tocá “Mi ubicación”. Al aire libre el GPS llega a 3–5 m de precisión; adentro usa Wi-Fi y antenas y empeora.
        </Text>
      )}
    </View>
  );
}

// ─────────────── Brújula ───────────────

const DIRECTIONS = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];

export function CompassDemo() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const { available, data } = useSensor(Magnetometer, 100);

  if (available === null) return <Loading />;
  if (!available) return <Unavailable what="El magnetómetro" />;

  const x = data?.x ?? 0;
  const y = data?.y ?? 0;
  const z = data?.z ?? 0;
  // Con el teléfono plano y la pantalla hacia arriba, el ángulo del vector (x, y) da el norte magnético.
  const angle = (Math.atan2(y, x) * 180) / Math.PI;
  const heading = Math.round((90 - angle + 360) % 360);
  const direction = DIRECTIONS[Math.round(heading / 45) % 8];
  const strength = Math.sqrt(x * x + y * y + z * z);

  return (
    <View style={[styles.stack, styles.center]}>
      <View style={styles.compass}>
        <View style={[styles.rose, { transform: [{ rotate: `${-heading}deg` }] }]}>
          {['N', 'E', 'S', 'O'].map((label, i) => (
            <View key={label} style={[styles.cardinalWrap, { transform: [{ rotate: `${i * 90}deg` }] }]}>
              <Text style={[styles.cardinal, { transform: [{ rotate: `${-i * 90}deg` }] }, label === 'N' && { color: colors.primary }]}>
                {label}
              </Text>
            </View>
          ))}
          <View style={styles.needleNorth} />
          <View style={styles.needleSouth} />
        </View>
        <View style={styles.marker} />
      </View>
      <Text style={styles.heading}>
        {heading}° <Text style={{ color: colors.primary }}>{direction}</Text>
      </Text>
      <Readings
        items={[
          { label: 'Campo total', value: strength.toFixed(0), unit: 'µT' },
          { label: 'Eje Z', value: z.toFixed(1), unit: 'µT' },
        ]}
      />
      <Text style={styles.caption}>
        Apoyá el teléfono plano. La Tierra da entre 25 y 65 µT: si ves mucho más, hay un imán o metal cerca. Para calibrar,
        mové el teléfono en forma de 8.
      </Text>
    </View>
  );
}

const ROSE = 220;

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    stack: { gap: Spacing.md },
    center: { alignItems: 'center' },
    row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    flex: { flex: 1 },
    coords: { color: c.text, fontSize: 22, fontWeight: '800', fontFamily: Fonts.mono, textAlign: 'center' },
    address: { color: c.text, fontSize: 15, lineHeight: 21 },
    caption: { color: c.textMuted, fontSize: 13, lineHeight: 19 },

    compass: { width: ROSE, height: ROSE, alignItems: 'center', justifyContent: 'center', marginVertical: Spacing.md },
    rose: {
      width: ROSE,
      height: ROSE,
      borderRadius: ROSE / 2,
      borderWidth: 3,
      borderColor: c.border,
      backgroundColor: c.surfaceMuted,
      alignItems: 'center',
      justifyContent: 'center',
    },
    cardinalWrap: { position: 'absolute', top: 0, bottom: 0, alignItems: 'center', paddingTop: Spacing.sm },
    cardinal: { color: c.textMuted, fontSize: 18, fontWeight: '800' },
    needleNorth: {
      position: 'absolute',
      top: ROSE / 2 - 80,
      width: 0,
      height: 0,
      borderLeftWidth: 10,
      borderRightWidth: 10,
      borderBottomWidth: 80,
      borderLeftColor: 'transparent',
      borderRightColor: 'transparent',
      borderBottomColor: c.primary,
    },
    needleSouth: {
      position: 'absolute',
      top: ROSE / 2,
      width: 0,
      height: 0,
      borderLeftWidth: 10,
      borderRightWidth: 10,
      borderTopWidth: 80,
      borderLeftColor: 'transparent',
      borderRightColor: 'transparent',
      borderTopColor: c.textSubtle,
    },
    marker: {
      position: 'absolute',
      top: -10,
      width: 4,
      height: 22,
      borderRadius: Radius.pill,
      backgroundColor: c.text,
    },
    heading: { color: c.text, fontSize: 40, fontWeight: '800', fontVariant: ['tabular-nums'] },
  });
