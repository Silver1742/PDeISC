import { Link, Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Icon } from '@/components/Icon';
import { ThemeToggle } from '@/components/ThemeToggle';
import { ToolBadges } from '@/components/ToolRow';
import { AppButton, Card, CodeBlock } from '@/components/ui';
import { getCategory, getNeighbors, getTool, type ToolEntry } from '@/data/tools';
import { DEMOS } from '@/demos';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Ficha de una herramienta: demo en vivo primero, después qué es, permisos y código. */
export default function HerramientaScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const tool = getTool(id);
  const styles = useThemedStyles(createStyles);

  if (!tool) {
    return (
      <View style={styles.notFound}>
        <Stack.Screen options={{ title: 'No encontrado' }} />
        <Text style={styles.notFoundTitle}>No existe “{id}”</Text>
        <Link href="/" style={styles.link}>
          Volver a las herramientas
        </Link>
      </View>
    );
  }

  // El `key` desmonta la demo anterior (y libera cámara/sensores) al pasar a otra ficha.
  return <ToolDetail key={tool.id} tool={tool} />;
}

function ToolDetail({ tool }: { tool: ToolEntry }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const Demo = DEMOS[tool.id];
  const category = getCategory(tool.category);
  const { prev, next } = getNeighbors(tool.id);

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <Stack.Screen options={{ title: tool.title, headerRight: () => <ThemeToggle /> }} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.column}>
          <View style={styles.hero}>
            <View style={styles.heroStripe} />
            <View style={styles.heroTop}>
              <Text style={styles.heroKicker}>{category.title.toUpperCase()}</Text>
              <Icon name={tool.icon} color="#ef3b4f" size={28} />
            </View>
            <Text style={styles.heroTitle}>{tool.title}</Text>
            <Text style={styles.heroModule}>{tool.module}</Text>
            <Text style={styles.heroSummary}>{tool.summary}</Text>
            <ToolBadges tool={tool} />
          </View>

          {Demo && (
            <Card title="Demo en vivo" icon={{ ios: 'play.circle.fill', android: 'play_circle', web: 'play_circle' }} style={styles.demoCard}>
              <Demo />
            </Card>
          )}

          <Card title="¿Cómo funciona?" icon={{ ios: 'lightbulb.fill', android: 'lightbulb', web: 'lightbulb' }}>
            <Text style={styles.paragraph}>{tool.description}</Text>
            <View style={styles.bullets}>
              {tool.uses.map((use) => (
                <View key={use} style={styles.bulletRow}>
                  <View style={styles.bulletDot} />
                  <Text style={styles.bulletText}>{use}</Text>
                </View>
              ))}
            </View>
          </Card>

          <Card title="Permisos" icon={{ ios: 'hand.raised.fill', android: 'admin_panel_settings', web: 'admin_panel_settings' }}>
            {tool.permissions.length > 0 ? (
              <>
                <Text style={styles.paragraph}>
                  Se piden en tiempo de ejecución, la primera vez que abrís la demo. Están declarados en app.json para que
                  queden en el AndroidManifest de la APK.
                </Text>
                {tool.permissions.map((permission) => (
                  <Text key={permission} style={styles.permission}>
                    android.permission.{permission}
                  </Text>
                ))}
              </>
            ) : (
              <Text style={styles.paragraph}>No necesita ningún permiso: el sistema lo deja usar libremente.</Text>
            )}
          </Card>

          <Card title="Código" icon={{ ios: 'chevron.left.forwardslash.chevron.right', android: 'code', web: 'code' }}>
            <CodeBlock code={tool.code} />
          </Card>

          <AppButton
            variant="outline"
            label="Documentación oficial"
            icon={{ ios: 'arrow.up.right.square', android: 'open_in_new', web: 'open_in_new' }}
            onPress={() => Linking.openURL(tool.docs)}
          />

          <View style={styles.pager}>
            {prev ? <PagerLink tool={prev} direction="previous" /> : <View style={styles.pagerSpacer} />}
            {next ? <PagerLink tool={next} direction="next" /> : <View style={styles.pagerSpacer} />}
          </View>
          <Text style={[styles.footer, { color: colors.textSubtle }]}>Fuente: docs.expo.dev</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function PagerLink({ tool, direction }: { tool: ToolEntry; direction: 'previous' | 'next' }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const router = useRouter();
  const isNext = direction === 'next';

  return (
    <Pressable
      onPress={() => router.replace({ pathname: '/herramienta/[id]', params: { id: tool.id } })}
      accessibilityRole="link"
      style={({ pressed }) => [styles.pagerItem, isNext && styles.pagerItemNext, pressed && { backgroundColor: colors.surfaceMuted }]}>
      <Text style={styles.pagerLabel}>{isNext ? 'Siguiente' : 'Anterior'}</Text>
      <View style={[styles.pagerRow, isNext && { flexDirection: 'row-reverse' }]}>
        <Icon
          name={
            isNext
              ? { ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }
              : { ios: 'chevron.left', android: 'chevron_left', web: 'chevron_left' }
          }
          color={colors.primary}
          size={16}
        />
        <Text style={styles.pagerName} numberOfLines={1}>
          {tool.title}
        </Text>
      </View>
    </Pressable>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },

    hero: {
      overflow: 'hidden',
      borderRadius: Radius.xl,
      padding: Spacing.xl,
      paddingLeft: Spacing.xl + Spacing.sm,
      backgroundColor: '#111111',
      experimental_backgroundImage: 'linear-gradient(135deg, #2e2e33 0%, #050505 100%)',
      gap: Spacing.sm,
    },
    heroStripe: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 6, backgroundColor: '#e11d2e' },
    heroTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    heroKicker: { color: '#ef3b4f', fontSize: 11, fontWeight: '800', letterSpacing: 2 },
    heroTitle: { color: '#ffffff', fontSize: 28, fontWeight: '800' },
    heroModule: { color: '#a1a1aa', fontSize: 13, fontFamily: Fonts.mono },
    heroSummary: { color: '#d4d4d8', fontSize: 15, lineHeight: 22, marginBottom: Spacing.xs },

    demoCard: { borderColor: c.primary, borderWidth: 1.5 },
    paragraph: { color: c.text, fontSize: 15, lineHeight: 22 },
    bullets: { gap: Spacing.sm },
    bulletRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start' },
    bulletDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: c.primary, marginTop: 8 },
    bulletText: { flex: 1, color: c.textMuted, fontSize: 14.5, lineHeight: 21 },
    permission: { color: c.primary, fontFamily: Fonts.mono, fontSize: 13, fontWeight: '700' },

    pager: { flexDirection: 'row', gap: Spacing.md },
    pagerItem: { flex: 1, padding: Spacing.md, borderRadius: Radius.md, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, gap: 2 },
    pagerItemNext: { alignItems: 'flex-end' },
    pagerSpacer: { flex: 1 },
    pagerLabel: { color: c.textSubtle, fontSize: 12 },
    pagerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    pagerName: { color: c.text, fontWeight: '700', fontSize: 15, flexShrink: 1 },
    footer: { textAlign: 'center', fontSize: 12 },

    notFound: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, backgroundColor: c.background },
    notFoundTitle: { color: c.text, fontSize: 20, fontWeight: '700' },
    link: { color: c.primary, fontWeight: '700' },
  });
