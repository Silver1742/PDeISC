import { Tabs } from 'expo-router/js-tabs';

import { Icon } from '@/components/Icon';
import { useAppTheme } from '@/theme';

export default function TabsLayout() {
  const { colors } = useAppTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSubtle,
        tabBarLabelStyle: { fontWeight: '600' },
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Herramientas',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'square.grid.2x2.fill', android: 'widgets', web: 'widgets' }} color={color} size={size} />
          ),
        }}
      />
      <Tabs.Screen
        name="panel"
        options={{
          title: 'Panel en vivo',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'waveform.path.ecg', android: 'monitor_heart', web: 'monitor_heart' }} color={color} size={size} />
          ),
        }}
      />
      <Tabs.Screen
        name="acerca"
        options={{
          title: 'Acerca',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'info.circle.fill', android: 'info', web: 'info' }} color={color} size={size} />
          ),
        }}
      />
    </Tabs>
  );
}
