import { useFocusEffect, useRouter } from 'expo-router';
import { Accelerometer, Barometer, Gyroscope, LightSensor, Magnetometer } from 'expo-sensors';
import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AxisBars, Readings } from '@/components/hardware';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AppButton, Badge, Card } from '@/components/ui';
import { useBattery } from '@/hooks/useBattery';
import { useSensor } from '@/hooks/useSensor';
import { MaxContentWidth, Spacing, useThemedStyles, type ThemeColors } from '@/theme';

const DIRECTIONS = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];

/**
 * Todos los sensores a la vez, sin pedir permisos.
 * Solo escuchan mientras esta pestaña está enfocada (y no en pausa) para no gastar batería de fondo.
 */
export default function PanelScreen() {
  const styles = useThemedStyles(createStyles);
  const router = useRouter();
  const [focused, setFocused] = useState(false);
  const [paused, setPaused] = useState(false);

  useFocusEffect(
    useCallback(() => {
      setFocused(true);
      return () => setFocused(false);
    }, []),
  );

  const live = focused && !paused;
  const accel = useSensor(Accelerometer, 100, live);
  const gyro = useSensor(Gyroscope, 100, live);
  const magnet = useSensor(Magnetometer, 200, live);
  const baro = useSensor(Barometer, 1000, live);
  const light = useSensor(LightSensor, 500, live);
  const battery = useBattery().level;

  const heading = magnet.data ? Math.round((90 - (Math.atan2(magnet.data.y, magnet.data.x) * 180) / Math.PI + 360) % 360) : null;

  const sensors = [
    { name: 'Acelerómetro', available: accel.available },
    { name: 'Giroscopio', available: gyro.available },
    { name: 'Magnetómetro', available: magnet.available },
    { name: 'Barómetro', available: baro.available },
    { name: 'Luz', available: light.available },
  ];

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.column}>
          <View style={styles.header}>
            <View style={styles.flex}>
              <Text style={styles.kicker}>{live ? '● EN VIVO' : 'EN PAUSA'}</Text>
              <Text style={styles.title}>Panel de sensores</Text>
            </View>
            <ThemeToggle />
          </View>

          <View style={styles.badges}>
            {sensors.map((sensor) => (
              <Badge
                key={sensor.name}
                label={`${sensor.name} ${sensor.available === null ? '…' : sensor.available ? '✓' : '✗'}`}
                tone={sensor.available ? 'success' : 'neutral'}
              />
            ))}
          </View>

          <AppButton
            variant="outline"
            label={paused ? 'Reanudar' : 'Pausar sensores'}
            icon={paused ? { ios: 'play.fill', android: 'play_arrow', web: 'play_arrow' } : { ios: 'pause.fill', android: 'pause', web: 'pause' }}
            onPress={() => setPaused((p) => !p)}
          />

          <Card title="Acelerómetro" icon={{ ios: 'move.3d', android: 'vibration', web: 'vibration' }}>
            {accel.available === false ? <Text style={styles.muted}>No disponible</Text> : <AxisBars values={accel.data ?? { x: 0, y: 0, z: 0 }} range={1.5} unit="g" />}
          </Card>

          <Card title="Giroscopio" icon={{ ios: 'gyroscope', android: '360', web: '360' }}>
            {gyro.available === false ? <Text style={styles.muted}>No disponible</Text> : <AxisBars values={gyro.data ?? { x: 0, y: 0, z: 0 }} range={5} unit="rad/s" />}
          </Card>

          <Card title="Ambiente" icon={{ ios: 'globe.americas.fill', android: 'public', web: 'public' }}>
            <Readings
              items={[
                { label: 'Rumbo', value: heading === null ? '—' : `${heading}° ${DIRECTIONS[Math.round(heading / 45) % 8]}` },
                { label: 'Presión', value: baro.data ? baro.data.pressure.toFixed(1) : '—', unit: 'hPa' },
                { label: 'Luz', value: light.data ? light.data.illuminance.toFixed(0) : '—', unit: 'lux' },
                { label: 'Batería', value: battery >= 0 ? `${Math.round(battery * 100)}` : '—', unit: '%' },
              ]}
            />
          </Card>

          <AppButton label="Ver todas las herramientas" onPress={() => router.navigate('/')} />
          <Text style={styles.muted}>
            Cámara, GPS, podómetro y biometría piden permiso: están en la pestaña Herramientas.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },
    header: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingTop: Spacing.md },
    flex: { flex: 1 },
    kicker: { color: c.primary, fontSize: 12, fontWeight: '800', letterSpacing: 2 },
    title: { color: c.text, fontSize: 28, fontWeight: '800', letterSpacing: -0.5 },
    badges: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs },
    muted: { color: c.textMuted, fontSize: 13, textAlign: 'center' },
  });
