import Constants from 'expo-constants';
import { Linking, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from '@/components/BrandLogo';
import { AppButton, Card, Chip, CodeBlock } from '@/components/ui';
import { CATEGORIES, TOOLS } from '@/data/tools';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors, type ThemePreference } from '@/theme';

const THEME_OPTIONS: { value: ThemePreference; label: string }[] = [
  { value: 'system', label: 'Sistema' },
  { value: 'light', label: 'Claro' },
  { value: 'dark', label: 'Oscuro' },
];

const withPermission = TOOLS.filter((tool) => tool.permissions.length > 0).length;

export default function AcercaScreen() {
  const styles = useThemedStyles(createStyles);
  const { preference, setPreference } = useAppTheme();

  const stats = [
    { value: TOOLS.length, label: 'Herramientas' },
    { value: CATEGORIES.length, label: 'Categorías' },
    { value: withPermission, label: 'Piden permiso' },
  ];

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.column}>
          <View style={styles.brand}>
            <BrandLogo size={64} />
            <Text style={styles.title}>Hardware RN</Text>
            <Text style={styles.subtitle}>
              v{Constants.expoConfig?.version ?? '1.0.0'} · Expo · TypeScript · EAS
            </Text>
          </View>

          <View style={styles.stats}>
            {stats.map((stat) => (
              <View key={stat.label} style={styles.stat}>
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>

          <Card title="Apariencia" icon={{ ios: 'circle.lefthalf.filled', android: 'contrast', web: 'contrast' }}>
            <View style={styles.row}>
              {THEME_OPTIONS.map((option) => (
                <Chip key={option.value} label={option.label} selected={preference === option.value} onPress={() => setPreference(option.value)} />
              ))}
            </View>
          </Card>

          <Card title="¿Cómo habla JS con el hardware?" icon={{ ios: 'cpu.fill', android: 'memory', web: 'memory' }}>
            <Text style={styles.paragraph}>
              Cada paquete de Expo (<Text style={styles.code}>expo-camera</Text>, <Text style={styles.code}>expo-sensors</Text>…) es
              un <Text style={styles.strong}>módulo nativo</Text>: código Kotlin/Swift que usa la API del sistema y le expone a
              JavaScript funciones y eventos.
            </Text>
            <Text style={styles.paragraph}>
              Los sensores “baratos” (acelerómetro, giroscopio) se usan libremente. Lo que toca la privacidad (cámara,
              ubicación, actividad física) pasa por un <Text style={styles.strong}>permiso en tiempo de ejecución</Text>, y
              además tiene que estar declarado en <Text style={styles.code}>app.json</Text> para que llegue al
              AndroidManifest de la APK.
            </Text>
          </Card>

          <Card title="Generar la APK con EAS" icon={{ ios: 'shippingbox.fill', android: 'android', web: 'android' }}>
            <Text style={styles.paragraph}>
              El perfil <Text style={styles.code}>preview</Text> de <Text style={styles.code}>eas.json</Text> compila una APK
              instalable (en vez del .aab que pide Play Store):
            </Text>
            <CodeBlock code={'npm install -g eas-cli\neas login\neas build -p android --profile preview'} />
            <Text style={styles.paragraph}>
              Al terminar, EAS muestra un link y un QR: abrilo desde el celular, descargá la APK e instalala (Android pide
              permitir “instalar apps desconocidas”).
            </Text>
          </Card>

          <AppButton
            label="Documentación de Expo SDK"
            icon={{ ios: 'book.fill', android: 'menu_book', web: 'menu_book' }}
            onPress={() => Linking.openURL('https://docs.expo.dev/versions/latest/')}
          />
          <AppButton
            variant="outline"
            label="Guía de EAS Build (APK)"
            icon={{ ios: 'arrow.up.right.square', android: 'open_in_new', web: 'open_in_new' }}
            onPress={() => Linking.openURL('https://docs.expo.dev/build-reference/apk/')}
          />
          <Text style={styles.footer}>BurgosCorp · Uriel Burgos</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },
    brand: { alignItems: 'center', gap: Spacing.xs, paddingVertical: Spacing.lg },
    title: { color: c.text, fontSize: 26, fontWeight: '800', marginTop: Spacing.sm },
    subtitle: { color: c.textMuted, fontSize: 14, fontFamily: Fonts.mono },

    stats: { flexDirection: 'row', gap: Spacing.sm },
    stat: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: Spacing.lg,
      paddingHorizontal: Spacing.xs,
      borderRadius: Radius.lg,
      backgroundColor: c.surface,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: c.border,
    },
    statValue: { color: c.primary, fontSize: 28, fontWeight: '800' },
    statLabel: { color: c.textMuted, fontSize: 12, textAlign: 'center' },

    row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    paragraph: { color: c.text, fontSize: 15, lineHeight: 22 },
    strong: { fontWeight: '800' },
    code: { fontFamily: Fonts.mono, color: c.primary, fontSize: 13.5 },
    footer: { color: c.textSubtle, fontSize: 12, textAlign: 'center' },
  });
