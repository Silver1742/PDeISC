import { useMemo, useState } from 'react';
import { SectionList, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from '@/components/BrandLogo';
import { Icon } from '@/components/Icon';
import { ThemeToggle } from '@/components/ThemeToggle';
import { ToolRow } from '@/components/ToolRow';
import { groupByCategory, searchTools, TOOLS } from '@/data/tools';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Lista de todas las herramientas de hardware, agrupadas por categoría y con buscador. */
export default function HerramientasScreen() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [query, setQuery] = useState('');

  const sections = useMemo(() => groupByCategory(searchTools(query)), [query]);
  const visible = sections.reduce((total, section) => total + section.data.length, 0);

  const header = (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <BrandLogo size={30} withName />
        <ThemeToggle />
      </View>
      <Text style={styles.kicker}>HARDWARE · EXPO</Text>
      <Text style={styles.title} accessibilityRole="header">
        El teléfono por dentro
      </Text>
      <Text style={styles.description}>
        Cámara, lector de códigos, GPS, sensores de movimiento, biometría y más. Cada herramienta tiene una demo en vivo,
        los permisos que pide y el código para usarla.
      </Text>

      <View style={styles.search}>
        <Icon name={{ ios: 'magnifyingglass', android: 'search', web: 'search' }} color={colors.textSubtle} size={18} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Buscar: cámara, gps, huella…"
          placeholderTextColor={colors.textSubtle}
          style={styles.searchInput}
          autoCorrect={false}
          autoCapitalize="none"
          clearButtonMode="while-editing"
          returnKeyType="search"
          accessibilityLabel="Buscar herramienta"
        />
      </View>
      <Text style={styles.count}>
        {visible} de {TOOLS.length} herramientas
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <SectionList
        sections={sections}
        keyExtractor={(tool) => tool.id}
        renderItem={({ item, index, section }) => (
          <View style={[styles.item, index === 0 && styles.itemFirst, index === section.data.length - 1 && styles.itemLast]}>
            {index > 0 && <View style={styles.separator} />}
            <ToolRow tool={item} />
          </View>
        )}
        renderSectionHeader={({ section }) => (
          <View style={styles.sectionHeader}>
            <Icon name={section.category.icon} color={colors.primary} size={16} />
            <Text style={styles.sectionTitle}>{section.category.title}</Text>
          </View>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>Sin resultados</Text>
            <Text style={styles.emptyBody}>Probá con otra palabra.</Text>
          </View>
        }
        stickySectionHeadersEnabled={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    listContent: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xxl, width: '100%', maxWidth: MaxContentWidth, alignSelf: 'center' },

    header: { paddingTop: Spacing.md, gap: Spacing.sm },
    headerTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm },
    kicker: { color: c.primary, fontSize: 12, fontWeight: '800', letterSpacing: 2 },
    title: { color: c.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.5 },
    description: { color: c.textMuted, fontSize: 15, lineHeight: 21 },
    search: {
      marginTop: Spacing.sm,
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.sm,
      paddingHorizontal: Spacing.md,
      borderRadius: Radius.md,
      backgroundColor: c.surface,
      borderWidth: 1,
      borderColor: c.border,
    },
    searchInput: { flex: 1, paddingVertical: Spacing.md - 2, color: c.text, fontSize: 15 },
    count: { color: c.textSubtle, fontSize: 12, fontFamily: Fonts.mono },

    sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingTop: Spacing.xl, paddingBottom: Spacing.sm },
    sectionTitle: { color: c.text, fontSize: 13, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },

    item: { backgroundColor: c.surface, borderLeftWidth: StyleSheet.hairlineWidth, borderRightWidth: StyleSheet.hairlineWidth, borderColor: c.border, overflow: 'hidden' },
    itemFirst: { borderTopWidth: StyleSheet.hairlineWidth, borderTopLeftRadius: Radius.lg, borderTopRightRadius: Radius.lg },
    itemLast: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomLeftRadius: Radius.lg, borderBottomRightRadius: Radius.lg },
    separator: { height: StyleSheet.hairlineWidth, backgroundColor: c.border, marginLeft: Spacing.lg + 44 + Spacing.md },

    empty: { alignItems: 'center', paddingVertical: Spacing.xxxl, gap: Spacing.xs },
    emptyTitle: { color: c.text, fontSize: 17, fontWeight: '700' },
    emptyBody: { color: c.textMuted, fontSize: 14, textAlign: 'center' },
  });
