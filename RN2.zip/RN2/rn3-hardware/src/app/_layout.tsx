import { Stack, ThemeProvider } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AppThemeProvider, buildNavigationTheme, useAppTheme } from '@/theme';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AppThemeProvider>
        <ThemedStack />
      </AppThemeProvider>
    </SafeAreaProvider>
  );
}

/**
 * Stack raíz: el grupo (tabs) con las tres pestañas y, encima, la ficha de cada herramienta.
 * Separado del layout para poder leer el tema que provee AppThemeProvider.
 */
function ThemedStack() {
  const { scheme, colors } = useAppTheme();

  return (
    <ThemeProvider value={buildNavigationTheme(scheme, colors)}>
      <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: colors.surface },
          headerTintColor: colors.primary,
          headerTitleStyle: { color: colors.text, fontWeight: '700' },
          headerBackButtonDisplayMode: 'minimal',
          contentStyle: { backgroundColor: colors.background },
        }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false, title: 'Herramientas' }} />
        <Stack.Screen name="herramienta/[id]" options={{ title: '' }} />
      </Stack>
    </ThemeProvider>
  );
}
