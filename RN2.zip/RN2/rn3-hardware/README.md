# RN3 · Hardware del teléfono con Expo

App en **Expo + TypeScript** que usa las herramientas físicas del celular: **cámara, lector de códigos, GPS, acelerómetro, giroscopio, biometría** y más. Cada herramienta tiene una **demo en vivo**, explica cómo funciona, qué **permisos** pide y el **código** para usarla. Diseño BurgosCorp (rojo, negro y gris) con modo claro/oscuro. Se compila como **APK con EAS Build**.

## Qué incluye

**15 herramientas** en 5 categorías:

| Categoría | Herramienta | Módulo | Demo |
|---|---|---|---|
| Cámara y visión | **Cámara** | `expo-camera` | Vista previa, foto, frontal/trasera, flash, galería de la sesión |
| | **Lector de códigos** | `expo-camera` | QR, EAN-13, Code 128, PDF417…; copiar y abrir links; linterna |
| | **Linterna** | `expo-camera` | LED del flash con `enableTorch` |
| Ubicación | **Ubicación y GPS** | `expo-location` | Coordenadas, precisión, altitud, velocidad, dirección postal, seguimiento en vivo con metros recorridos, abrir en el mapa |
| | **Brújula** | `Magnetometer` | Rosa de los vientos que gira con el rumbo |
| Movimiento | **Acelerómetro** | `Accelerometer` | Barras X/Y/Z, nivel de burbuja, inclinación y detector de sacudidas con vibración |
| | **Giroscopio** | `Gyroscope` | Velocidad de giro y ángulo acumulado por eje |
| | **Podómetro** | `Pedometer` | Pasos, distancia y calorías aproximadas |
| | **Barómetro** | `Barometer` | Presión, altitud estimada y diferencia de altura (pisos) |
| | **Sensor de luz** | `LightSensor` | Lux con escala logarítmica (solo Android) |
| Seguridad | **Biometría** | `expo-local-authentication` | Huella / rostro para desbloquear una “zona privada” |
| Sistema | **Vibración y háptica** | `expo-haptics` | Impactos, notificaciones y selección |
| | **Batería** | `expo-battery` | Nivel, cargando y ahorro de energía en vivo |
| | **Brillo** | `expo-brightness` | Cambia el brillo de la app |
| | **Info del dispositivo** | `expo-device` | Marca, modelo, SO, RAM, emulador o real |

| Pestaña | Contenido |
|---|---|
| **Herramientas** | `SectionList` por categoría con buscador (ignora tildes) |
| **Panel en vivo** | Todos los sensores sin permisos a la vez; solo escuchan con la pestaña abierta |
| **Acerca** | Estadísticas, selector de tema, cómo funcionan los módulos nativos y cómo generar la APK |

## Generar la APK (EAS Build)

`eas.json` ya tiene el perfil **`preview`** configurado con `"buildType": "apk"`.

```bash
npm install
npm install -g eas-cli
eas login                              # cuenta de expo.dev (gratis)
eas init                               # la primera vez: vincula el proyecto y escribe el projectId en app.json
eas build -p android --profile preview
```

1. La compilación corre en los servidores de Expo (10–20 min en la cola gratuita). Si pregunta por el **keystore**, respondé que sí: EAS lo genera y lo guarda.
2. Al terminar muestra un **link y un QR**: abrilo desde el celular y descargá la `.apk` (también queda en expo.dev → Builds).
3. Instalala: Android pide habilitar **“Instalar apps desconocidas”** para el navegador o el gestor de archivos.

| Perfil | Resultado | Para qué |
|---|---|---|
| `preview` | `.apk` | Instalar directo en el celular (esta entrega) |
| `production` | `.aab` | Subir a Google Play |
| `development` | dev client | Desarrollo con módulos nativos propios |

## Correrlo en desarrollo

```bash
npm install
npx expo start      # o: npx expo start --tunnel
```

Escaneá el QR con **Expo Go**. Todos los módulos usados vienen incluidos en Expo Go, así que no hace falta compilar para probar. En la **web** (`w`) funcionan la cámara, el lector y el GPS; el resto muestra un aviso de “no disponible”.

Verificar: `npm run typecheck` · `npm run lint`.

## Estructura

```
src/
├── app/                       # Rutas (Expo Router)
│   ├── _layout.tsx            # Providers + Stack raíz
│   ├── (tabs)/
│   │   ├── index.tsx          # Lista de herramientas
│   │   ├── panel.tsx          # Panel de sensores en vivo
│   │   └── acerca.tsx
│   └── herramienta/[id].tsx   # Ficha + demo (ruta dinámica)
├── data/tools.ts              # Catálogo tipado: descripción, permisos, código, docs
├── demos/                     # Una demo por herramienta
│   ├── vision.tsx             # Cámara, lector, linterna
│   ├── location.tsx           # GPS, brújula
│   ├── motion.tsx             # Acelerómetro, giroscopio, podómetro, barómetro, luz
│   ├── system.tsx             # Biometría, háptica, batería, brillo, dispositivo
│   └── index.ts               # Registro id → demo
├── hooks/
│   ├── useSensor.ts           # Suscripción genérica a expo-sensors (con limpieza)
│   └── useBattery(.web).ts    # Batería con respaldo para web
├── components/                # UI reutilizable (Card, AxisBars, PermissionRequest…)
└── theme/                     # Tokens + ThemeContext (claro / oscuro / sistema)
```

## Decisiones técnicas

- **Permisos en dos lugares:** se piden en tiempo de ejecución (`useCameraPermissions`, `useForegroundPermissions`…) y además se declaran en `app.json` (plugins de `expo-camera`, `expo-location`, `expo-sensors`, `expo-local-authentication` y `android.permissions`) para que queden en el AndroidManifest de la APK. Si el usuario los rechaza “para siempre”, el botón lleva a los Ajustes.
- **`RECORD_AUDIO` bloqueado:** la app no graba video, así que no pide micrófono.
- **Sensores con limpieza:** `useSensor` se desuscribe al desmontar; el panel solo escucha con la pestaña enfocada (`useFocusEffect`) y se puede pausar. Un sensor escuchando de fondo gasta batería.
- **Lecturas acumuladas en el listener** (picos, sacudidas, ángulo del giroscopio) con `useEffectEvent`, sin `setState` dentro de efectos.
- **Lector sin lecturas duplicadas:** un `ref` bloquea el evento apenas llega el primer código, antes del re-render.
- **Datos separados de la UI:** agregar una herramienta = una entrada en `TOOLS` + una demo en `DEMOS`.
- **TypeScript `strict`**, rutas tipadas y React Compiler.

**Stack:** Expo SDK 57 · React Native 0.86 · React 19 · TypeScript · Expo Router · EAS Build

Documentación: [docs.expo.dev/versions/latest](https://docs.expo.dev/versions/latest/) · [Build APKs](https://docs.expo.dev/build-reference/apk/)
