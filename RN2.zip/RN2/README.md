# RN2 · Hardware del dispositivo con Expo

Proyecto de la cursada con la identidad de **BurgosCorp** (rojo, negro y gris) y modo claro/oscuro.

| Carpeta | Actividad |
|---|---|
| [`rn3-hardware`](rn3-hardware) | **3.** App que usa las herramientas del teléfono (cámara, lector de códigos, GPS, acelerómetro, giroscopio, biometría y más) y se compila como **APK con EAS**. |

## Cómo correrlo

```bash
cd rn3-hardware
npm install
npx expo start      # o: npx expo start --tunnel
```

## Cómo generar la APK

```bash
cd rn3-hardware
eas login
eas init
eas build -p android --profile preview
```

El detalle (y qué hacer con el link de descarga) está en el [README del proyecto](rn3-hardware/README.md).

**Stack:** Expo SDK 57 · React Native 0.86 · React 19 · TypeScript · Expo Router · EAS Build
